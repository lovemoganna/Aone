export { matchers } from './matchers.js';

export const nodes = [
	() => import('./nodes/0'),
	() => import('./nodes/1'),
	() => import('./nodes/2'),
	() => import('./nodes/3'),
	() => import('./nodes/4'),
	() => import('./nodes/5'),
	() => import('./nodes/6'),
	() => import('./nodes/7'),
	() => import('./nodes/8'),
	() => import('./nodes/9'),
	() => import('./nodes/10'),
	() => import('./nodes/11'),
	() => import('./nodes/12'),
	() => import('./nodes/13'),
	() => import('./nodes/14'),
	() => import('./nodes/15'),
	() => import('./nodes/16'),
	() => import('./nodes/17'),
	() => import('./nodes/18'),
	() => import('./nodes/19'),
	() => import('./nodes/20'),
	() => import('./nodes/21'),
	() => import('./nodes/22')
];

export const server_loads = [];

export const dictionary = {
		"/": [2],
		"/api-spec": [3],
		"/api-viewer": [4],
		"/charts": [5],
		"/code-formatter": [6],
		"/css-lab": [7],
		"/curl-converter": [8],
		"/developer-utilities": [9],
		"/diagram-editor": [10],
		"/diff-viewer": [11],
		"/json-editor": [12],
		"/mock-generator": [13],
		"/multi-agent": [14],
		"/prompt-hub": [15],
		"/regex-tester": [16],
		"/secret-scanner": [17],
		"/snippets": [18],
		"/sql-architect": [19],
		"/svg-studio": [20],
		"/table-editor": [21],
		"/yaml-editor": [22]
	};

export const hooks = {
	handleError: (({ error }) => { console.error(error) }),
	
	reroute: (() => {}),
	transport: {}
};

export const decoders = Object.fromEntries(Object.entries(hooks.transport).map(([k, v]) => [k, v.decode]));
export const encoders = Object.fromEntries(Object.entries(hooks.transport).map(([k, v]) => [k, v.encode]));

export const hash = false;

export const decode = (type, value) => decoders[type](value);

export { default as root } from '../root.js';