
// this file is generated — do not edit it


declare module "svelte/elements" {
	export interface HTMLAttributes<T> {
		'data-sveltekit-keepfocus'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-noscroll'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-preload-code'?:
			| true
			| ''
			| 'eager'
			| 'viewport'
			| 'hover'
			| 'tap'
			| 'off'
			| undefined
			| null;
		'data-sveltekit-preload-data'?: true | '' | 'hover' | 'tap' | 'off' | undefined | null;
		'data-sveltekit-reload'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-replacestate'?: true | '' | 'off' | undefined | null;
	}
}

export {};


declare module "$app/types" {
	export interface AppTypes {
		RouteId(): "/" | "/api-spec" | "/api-viewer" | "/api" | "/api/generate" | "/api/lint" | "/charts" | "/code-formatter" | "/css-lab" | "/curl-converter" | "/developer-utilities" | "/developer-utilities/components" | "/diagram-editor" | "/diagram-editor/components" | "/diagram-editor/components/modals" | "/diagram-editor/lib" | "/diagram-editor/lib/ai" | "/diff-viewer" | "/json-editor" | "/json-editor/components" | "/mock-generator" | "/multi-agent" | "/multi-agent/components" | "/prompt-hub" | "/prompt-hub/components" | "/prompt-hub/components/modals" | "/prompt-hub/lib" | "/regex-tester" | "/secret-scanner" | "/snippets" | "/sql-architect" | "/svg-studio" | "/table-editor" | "/table-editor/components" | "/table-editor/lib" | "/yaml-editor" | "/yaml-editor/components";
		RouteParams(): {
			
		};
		LayoutParams(): {
			"/": Record<string, never>;
			"/api-spec": Record<string, never>;
			"/api-viewer": Record<string, never>;
			"/api": Record<string, never>;
			"/api/generate": Record<string, never>;
			"/api/lint": Record<string, never>;
			"/charts": Record<string, never>;
			"/code-formatter": Record<string, never>;
			"/css-lab": Record<string, never>;
			"/curl-converter": Record<string, never>;
			"/developer-utilities": Record<string, never>;
			"/developer-utilities/components": Record<string, never>;
			"/diagram-editor": Record<string, never>;
			"/diagram-editor/components": Record<string, never>;
			"/diagram-editor/components/modals": Record<string, never>;
			"/diagram-editor/lib": Record<string, never>;
			"/diagram-editor/lib/ai": Record<string, never>;
			"/diff-viewer": Record<string, never>;
			"/json-editor": Record<string, never>;
			"/json-editor/components": Record<string, never>;
			"/mock-generator": Record<string, never>;
			"/multi-agent": Record<string, never>;
			"/multi-agent/components": Record<string, never>;
			"/prompt-hub": Record<string, never>;
			"/prompt-hub/components": Record<string, never>;
			"/prompt-hub/components/modals": Record<string, never>;
			"/prompt-hub/lib": Record<string, never>;
			"/regex-tester": Record<string, never>;
			"/secret-scanner": Record<string, never>;
			"/snippets": Record<string, never>;
			"/sql-architect": Record<string, never>;
			"/svg-studio": Record<string, never>;
			"/table-editor": Record<string, never>;
			"/table-editor/components": Record<string, never>;
			"/table-editor/lib": Record<string, never>;
			"/yaml-editor": Record<string, never>;
			"/yaml-editor/components": Record<string, never>
		};
		Pathname(): "/" | "/api-spec" | "/api-spec/" | "/api-viewer" | "/api-viewer/" | "/api" | "/api/" | "/api/generate" | "/api/generate/" | "/api/lint" | "/api/lint/" | "/charts" | "/charts/" | "/code-formatter" | "/code-formatter/" | "/css-lab" | "/css-lab/" | "/curl-converter" | "/curl-converter/" | "/developer-utilities" | "/developer-utilities/" | "/developer-utilities/components" | "/developer-utilities/components/" | "/diagram-editor" | "/diagram-editor/" | "/diagram-editor/components" | "/diagram-editor/components/" | "/diagram-editor/components/modals" | "/diagram-editor/components/modals/" | "/diagram-editor/lib" | "/diagram-editor/lib/" | "/diagram-editor/lib/ai" | "/diagram-editor/lib/ai/" | "/diff-viewer" | "/diff-viewer/" | "/json-editor" | "/json-editor/" | "/json-editor/components" | "/json-editor/components/" | "/mock-generator" | "/mock-generator/" | "/multi-agent" | "/multi-agent/" | "/multi-agent/components" | "/multi-agent/components/" | "/prompt-hub" | "/prompt-hub/" | "/prompt-hub/components" | "/prompt-hub/components/" | "/prompt-hub/components/modals" | "/prompt-hub/components/modals/" | "/prompt-hub/lib" | "/prompt-hub/lib/" | "/regex-tester" | "/regex-tester/" | "/secret-scanner" | "/secret-scanner/" | "/snippets" | "/snippets/" | "/sql-architect" | "/sql-architect/" | "/svg-studio" | "/svg-studio/" | "/table-editor" | "/table-editor/" | "/table-editor/components" | "/table-editor/components/" | "/table-editor/lib" | "/table-editor/lib/" | "/yaml-editor" | "/yaml-editor/" | "/yaml-editor/components" | "/yaml-editor/components/";
		ResolvedPathname(): `${"" | `/${string}`}${ReturnType<AppTypes['Pathname']>}`;
		Asset(): "/favicon.svg" | "/robots.txt" | string & {};
	}
}