import{m as p,E as t}from"./DODkVri7.js";import{B as c}from"./Bo1sWiaW.js";function E(r,s,...a){var e=new c(r);p(()=>{const n=s()??null;e.ensure(n,n&&(o=>n(o,...a)))},t)}export{E as s};
