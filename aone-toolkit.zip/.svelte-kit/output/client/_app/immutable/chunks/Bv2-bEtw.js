import{k as s,l as c,m,E as i}from"./DODkVri7.js";import{B as p}from"./Bo1sWiaW.js";function l(n,r,o){s&&c();var e=new p(n);m(()=>{var a=r()??null;e.ensure(a,a&&(t=>o(t,a)))},i)}export{l as c};
