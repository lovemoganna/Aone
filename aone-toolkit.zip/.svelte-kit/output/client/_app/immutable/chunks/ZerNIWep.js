import{a as t,f as _,c as h,s as D}from"./CxxMvMXs.js";import{t as g,c as d,s as E,K as F,b as i,f as p}from"./DODkVri7.js";import{s as x}from"./7DIJ8hBu.js";import{p as k,i as c}from"./Bo1sWiaW.js";import{s as u,f as G}from"./DE51p1_m.js";var H=_('<h3 class="font-semibold text-slate-900 dark:text-slate-100"> </h3>'),I=_('<div class="px-4 py-3 border-b border-slate-200 dark:border-slate-700"><!></div>'),J=_("<div><!> <div><!></div></div>");function S(w,a){let P=k(a,"padding",3,"md"),y=k(a,"class",3,"");const C={none:"",sm:"p-3",md:"p-4",lg:"p-6"};var s=J(),b=d(s);{var K=l=>{var v=I(),j=d(v);{var q=e=>{var r=h(),n=p(r);x(n,()=>a.header),t(e,r)},z=e=>{var r=h(),n=p(r);{var A=f=>{var m=H(),B=d(m,!0);i(m),g(()=>D(B,a.title)),t(f,m)};c(n,f=>{a.title&&f(A)},!0)}t(e,r)};c(j,e=>{a.header?e(q):e(z,!1)})}i(v),t(l,v)};c(b,l=>{(a.title||a.header)&&l(K)})}var o=E(b,2),N=d(o);x(N,()=>a.children??F),i(o),i(s),g(()=>{u(s,1,`
  bg-white dark:bg-slate-800 
  rounded-lg border border-slate-200 dark:border-slate-700 
  shadow-soft
  ${y()??""}
`),u(o,1,G(C[P()]))}),t(w,s)}export{S as P};
