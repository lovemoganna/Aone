import { a3 as attr, ac as attributes, a1 as stringify, a6 as bind_props } from "./index2.js";
import { e as escape_html } from "./context.js";
function Input($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      label,
      error,
      hint,
      value = void 0,
      class: className = "",
      id,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    const randomId = `input-${Math.random().toString(36).slice(2, 9)}`;
    let inputId = id || randomId;
    $$renderer2.push(`<div class="w-full">`);
    if (label) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<label${attr("for", inputId)} class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">${escape_html(label)}</label>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> <input${attributes(
      {
        id: inputId,
        class: ` w-full px-3 py-2 rounded-lg border bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 transition-all duration-200 ${stringify(error ? "border-red-500 focus:border-red-500 focus:ring-red-500/20" : "border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 focus:border-primary-500 dark:focus:border-primary-500 focus:ring-primary-500/20")} focus:outline-none focus:ring-2 ${stringify(className)} `,
        value,
        ...restProps
      },
      void 0,
      void 0,
      void 0,
      4
    )}/> `);
    if (error) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<p class="mt-1.5 text-sm text-red-500">${escape_html(error)}</p>`);
    } else {
      $$renderer2.push("<!--[!-->");
      if (hint) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<p class="mt-1.5 text-sm text-slate-500 dark:text-slate-400">${escape_html(hint)}</p>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]-->`);
    }
    $$renderer2.push(`<!--]--></div>`);
    bind_props($$props, { value });
  });
}
export {
  Input as I
};
