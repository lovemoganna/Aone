import { a0 as attr_class, a8 as clsx, a1 as stringify } from "./index2.js";
import { e as escape_html } from "./context.js";
function Panel($$renderer, $$props) {
  let {
    title,
    padding = "md",
    class: className = "",
    children,
    header
  } = $$props;
  const paddingClasses = { none: "", sm: "p-3", md: "p-4", lg: "p-6" };
  $$renderer.push(`<div${attr_class(` bg-white dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 shadow-soft ${stringify(className)} `)}>`);
  if (title || header) {
    $$renderer.push("<!--[-->");
    $$renderer.push(`<div class="px-4 py-3 border-b border-slate-200 dark:border-slate-700">`);
    if (header) {
      $$renderer.push("<!--[-->");
      header($$renderer);
      $$renderer.push(`<!---->`);
    } else {
      $$renderer.push("<!--[!-->");
      if (title) {
        $$renderer.push("<!--[-->");
        $$renderer.push(`<h3 class="font-semibold text-slate-900 dark:text-slate-100">${escape_html(title)}</h3>`);
      } else {
        $$renderer.push("<!--[!-->");
      }
      $$renderer.push(`<!--]-->`);
    }
    $$renderer.push(`<!--]--></div>`);
  } else {
    $$renderer.push("<!--[!-->");
  }
  $$renderer.push(`<!--]--> <div${attr_class(clsx(paddingClasses[padding]))}>`);
  children?.($$renderer);
  $$renderer.push(`<!----></div></div>`);
}
export {
  Panel as P
};
