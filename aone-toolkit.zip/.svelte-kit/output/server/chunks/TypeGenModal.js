import { a3 as attr } from "./index2.js";
import { e as escape_html } from "./context.js";
import { B as Button } from "./Button.js";
function TypeGenModal($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { isOpen, jsonData, onClose } = $$props;
    let tsOutput = "";
    let interfaceName = "RootObject";
    function copyToClipboard() {
      navigator.clipboard.writeText(tsOutput);
      onClose();
    }
    if (isOpen) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"><div class="bg-white dark:bg-slate-900 rounded-lg shadow-xl w-full max-w-2xl max-h-[80vh] flex flex-col"><div class="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between"><h3 class="text-lg font-semibold text-slate-900 dark:text-white">Generate TypeScript Interfaces</h3> <button class="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-x"><path d="M18 6 6 18"></path><path d="m6 6 18 18"></path></svg></button></div> <div class="p-4 space-y-4 flex-1 overflow-hidden flex flex-col"><div class="flex items-center gap-2"><label class="text-sm font-medium">Root Interface Name:</label> <input${attr("value", interfaceName)} class="px-2 py-1 border rounded bg-slate-50 dark:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-primary-500"/></div> <div class="flex-1 border rounded-lg overflow-hidden bg-slate-50 dark:bg-slate-950 p-4 overflow-y-auto"><pre class="font-mono text-sm text-slate-800 dark:text-slate-200">${escape_html(tsOutput)}</pre></div></div> <div class="p-4 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">`);
      Button($$renderer2, {
        variant: "secondary",
        onclick: onClose,
        children: ($$renderer3) => {
          $$renderer3.push(`<!---->Close`);
        },
        $$slots: { default: true }
      });
      $$renderer2.push(`<!----> `);
      Button($$renderer2, {
        onclick: copyToClipboard,
        children: ($$renderer3) => {
          $$renderer3.push(`<!---->Copy &amp; Close`);
        },
        $$slots: { default: true }
      });
      $$renderer2.push(`<!----></div></div></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
  });
}
export {
  TypeGenModal as T
};
