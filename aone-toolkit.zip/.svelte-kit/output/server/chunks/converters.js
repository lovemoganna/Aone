function toMarkdown(data) {
  if (data.length === 0) return "";
  const maxCols = Math.max(...data.map((row) => row.length));
  const colWidths = [];
  for (let col = 0; col < maxCols; col++) {
    colWidths[col] = Math.max(3, ...data.map((row) => (row[col] || "").length));
  }
  const lines = [];
  data.forEach((row, rowIndex) => {
    const cells = [];
    for (let col = 0; col < maxCols; col++) {
      const cell = row[col] || "";
      cells.push(cell.padEnd(colWidths[col]));
    }
    lines.push("| " + cells.join(" | ") + " |");
    if (rowIndex === 0) {
      const separators = colWidths.map((w) => "-".repeat(w));
      lines.push("| " + separators.join(" | ") + " |");
    }
  });
  return lines.join("\n");
}
function toCSV(data, delimiter = ",") {
  return data.map((row) => {
    return row.map((cell) => {
      if (cell.includes(delimiter) || cell.includes('"') || cell.includes("\n")) {
        return '"' + cell.replace(/"/g, '""') + '"';
      }
      return cell;
    }).join(delimiter);
  }).join("\n");
}
function toHTML(data) {
  if (data.length === 0) return "<table></table>";
  const lines = ["<table>"];
  data.forEach((row, rowIndex) => {
    lines.push("  <tr>");
    const tag = rowIndex === 0 ? "th" : "td";
    row.forEach((cell) => {
      const escaped = escapeHTML(cell);
      lines.push(`    <${tag}>${escaped}</${tag}>`);
    });
    lines.push("  </tr>");
  });
  lines.push("</table>");
  return lines.join("\n");
}
function toOrgMode(data) {
  if (data.length === 0) return "";
  const maxCols = Math.max(...data.map((row) => row.length));
  const colWidths = [];
  for (let col = 0; col < maxCols; col++) {
    colWidths[col] = Math.max(1, ...data.map((row) => (row[col] || "").length));
  }
  const lines = [];
  data.forEach((row, rowIndex) => {
    const cells = [];
    for (let col = 0; col < maxCols; col++) {
      const cell = row[col] || "";
      cells.push(cell.padEnd(colWidths[col]));
    }
    lines.push("| " + cells.join(" | ") + " |");
    if (rowIndex === 0) {
      const separators = colWidths.map((w) => "-".repeat(w + 2));
      lines.push("|" + separators.join("+") + "|");
    }
  });
  return lines.join("\n");
}
function escapeHTML(str) {
  const escapeMap = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  };
  return str.replace(/[&<>"']/g, (char) => escapeMap[char] || char);
}
function toJSON(data) {
  return JSON.stringify(data, null, 2);
}
function toSQL(data, tableName = "table_name") {
  if (data.length <= 1) return "";
  const headers = data[0];
  const rows = data.slice(1);
  const columns = headers.map((h) => `"${h}"`).join(", ");
  const values = rows.map((row) => {
    const rowValues = row.map((cell) => {
      if (cell === null || cell === void 0) return "NULL";
      const escaped = cell.replace(/'/g, "''");
      return `'${escaped}'`;
    }).join(", ");
    return `(${rowValues})`;
  }).join(",\n");
  return `INSERT INTO "${tableName}" (${columns}) VALUES
${values};`;
}
function getTableStats(data) {
  const rows = data.length;
  const cols = data.length > 0 ? Math.max(...data.map((row) => row.length)) : 0;
  const cells = data.reduce((sum, row) => sum + row.length, 0);
  return { rows, cols, cells };
}
export {
  toSQL as a,
  toCSV as b,
  toJSON as c,
  toOrgMode as d,
  toHTML as e,
  getTableStats as g,
  toMarkdown as t
};
