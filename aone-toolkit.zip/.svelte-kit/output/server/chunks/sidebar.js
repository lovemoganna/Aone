import { w as writable } from "./index.js";
function createThemeStore() {
  const getInitialTheme = () => {
    return "light";
  };
  const { subscribe, set, update } = writable(getInitialTheme());
  return {
    subscribe,
    toggle: () => {
      update((current) => {
        const next = current === "light" ? "dark" : "light";
        return next;
      });
    },
    set: (theme2) => {
      set(theme2);
    },
    init: () => {
    }
  };
}
createThemeStore();
function createSidebarStore() {
  const getInitialState = () => {
    return false;
  };
  const { subscribe, set, update } = writable(getInitialState());
  return {
    subscribe,
    toggle: () => {
      update((current) => {
        const next = !current;
        return next;
      });
    },
    collapse: () => {
      set(true);
    },
    expand: () => {
      set(false);
    }
  };
}
const sidebarCollapsed = createSidebarStore();
export {
  sidebarCollapsed as s
};
