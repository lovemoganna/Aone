import { Z as sanitize_props, _ as spread_props, $ as slot, a0 as attr_class, a1 as stringify, a2 as store_get, a3 as attr, a4 as ensure_array_like, a5 as unsubscribe_stores, a6 as bind_props, a7 as head } from "../../chunks/index2.js";
import { g as getContext, e as escape_html } from "../../chunks/context.js";
import "clsx";
import "@sveltejs/kit/internal";
import "../../chunks/exports.js";
import "../../chunks/utils.js";
import "@sveltejs/kit/internal/server";
import { g as goto } from "../../chunks/client.js";
import { s as sidebarCollapsed } from "../../chunks/sidebar.js";
import { t as tools } from "../../chunks/config.js";
import { I as Icon } from "../../chunks/Icon.js";
import { C as Chevron_left, S as Sun } from "../../chunks/sun.js";
import { B as Brain_circuit } from "../../chunks/brain-circuit.js";
import { C as Code } from "../../chunks/code.js";
import { T as Table } from "../../chunks/table.js";
import { F as File_text, X } from "../../chunks/x.js";
import { B as Button } from "../../chunks/Button.js";
import { S as Search } from "../../chunks/search.js";
import { C as Clock } from "../../chunks/clock.js";
import { C as Copy } from "../../chunks/copy.js";
import { T as Trash_2 } from "../../chunks/trash-2.js";
const getStores = () => {
  const stores$1 = getContext("__svelte__");
  return {
    /** @type {typeof page} */
    page: {
      subscribe: stores$1.page.subscribe
    },
    /** @type {typeof navigating} */
    navigating: {
      subscribe: stores$1.navigating.subscribe
    },
    /** @type {typeof updated} */
    updated: stores$1.updated
  };
};
const page = {
  subscribe(fn) {
    const store = getStores().page;
    return store.subscribe(fn);
  }
};
function Clipboard($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "rect",
      {
        "width": "8",
        "height": "4",
        "x": "8",
        "y": "2",
        "rx": "1",
        "ry": "1"
      }
    ],
    [
      "path",
      {
        "d": "M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"
      }
    ]
  ];
  Icon($$renderer, spread_props([
    { name: "clipboard" },
    $$sanitized_props,
    {
      /**
       * @component @name Clipboard
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cmVjdCB3aWR0aD0iOCIgaGVpZ2h0PSI0IiB4PSI4IiB5PSIyIiByeD0iMSIgcnk9IjEiIC8+CiAgPHBhdGggZD0iTTE2IDRoMmEyIDIgMCAwIDEgMiAydjE0YTIgMiAwIDAgMS0yIDJINmEyIDIgMCAwIDEtMi0yVjZhMiAyIDAgMCAxIDItMmgyIiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/clipboard
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function House($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "path",
      { "d": "M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8" }
    ],
    [
      "path",
      {
        "d": "M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"
      }
    ]
  ];
  Icon($$renderer, spread_props([
    { name: "house" },
    $$sanitized_props,
    {
      /**
       * @component @name House
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTUgMjF2LThhMSAxIDAgMCAwLTEtMWgtNGExIDEgMCAwIDAtMSAxdjgiIC8+CiAgPHBhdGggZD0iTTMgMTBhMiAyIDAgMCAxIC43MDktMS41MjhsNy02YTIgMiAwIDAgMSAyLjU4MiAwbDcgNkEyIDIgMCAwIDEgMjEgMTB2OWEyIDIgMCAwIDEtMiAySDVhMiAyIDAgMCAxLTItMnoiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/house
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Layout_dashboard($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "rect",
      { "width": "7", "height": "9", "x": "3", "y": "3", "rx": "1" }
    ],
    [
      "rect",
      { "width": "7", "height": "5", "x": "14", "y": "3", "rx": "1" }
    ],
    [
      "rect",
      { "width": "7", "height": "9", "x": "14", "y": "12", "rx": "1" }
    ],
    [
      "rect",
      { "width": "7", "height": "5", "x": "3", "y": "16", "rx": "1" }
    ]
  ];
  Icon($$renderer, spread_props([
    { name: "layout-dashboard" },
    $$sanitized_props,
    {
      /**
       * @component @name LayoutDashboard
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cmVjdCB3aWR0aD0iNyIgaGVpZ2h0PSI5IiB4PSIzIiB5PSIzIiByeD0iMSIgLz4KICA8cmVjdCB3aWR0aD0iNyIgaGVpZ2h0PSI1IiB4PSIxNCIgeT0iMyIgcng9IjEiIC8+CiAgPHJlY3Qgd2lkdGg9IjciIGhlaWdodD0iOSIgeD0iMTQiIHk9IjEyIiByeD0iMSIgLz4KICA8cmVjdCB3aWR0aD0iNyIgaGVpZ2h0PSI1IiB4PSIzIiB5PSIxNiIgcng9IjEiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/layout-dashboard
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Menu($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    ["path", { "d": "M4 5h16" }],
    ["path", { "d": "M4 12h16" }],
    ["path", { "d": "M4 19h16" }]
  ];
  Icon($$renderer, spread_props([
    { name: "menu" },
    $$sanitized_props,
    {
      /**
       * @component @name Menu
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNNCA1aDE2IiAvPgogIDxwYXRoIGQ9Ik00IDEyaDE2IiAvPgogIDxwYXRoIGQ9Ik00IDE5aDE2IiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/menu
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Sidebar($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    $$renderer2.push(`<aside${attr_class(`fixed top-0 left-0 z-30 h-screen transition-all duration-300 ease-in-out border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 ${stringify(store_get($$store_subs ??= {}, "$sidebarCollapsed", sidebarCollapsed) ? "w-16" : "w-60")}`)}><div class="h-16 flex items-center justify-between px-4 border-b border-slate-200 dark:border-slate-800"><a href="/" class="flex items-center gap-2 overflow-hidden whitespace-nowrap"><div class="w-8 h-8 rounded-lg bg-gradient-to-br from-primary-500 to-violet-600 flex items-center justify-center shrink-0 shadow-lg shadow-primary-500/20"><span class="text-white font-bold text-lg">A</span></div> <span${attr_class(`font-bold text-xl text-slate-800 dark:text-slate-100 transition-opacity duration-200 ${stringify(store_get($$store_subs ??= {}, "$sidebarCollapsed", sidebarCollapsed) ? "opacity-0 w-0" : "opacity-100")}`)}>Aone</span></a> <button class="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">`);
    if (store_get($$store_subs ??= {}, "$sidebarCollapsed", sidebarCollapsed)) {
      $$renderer2.push("<!--[-->");
      Menu($$renderer2, { size: 20 });
    } else {
      $$renderer2.push("<!--[!-->");
      Chevron_left($$renderer2, { size: 20 });
    }
    $$renderer2.push(`<!--]--></button></div> <nav class="p-3 space-y-1 h-[calc(100vh-4rem)] overflow-y-auto overflow-x-hidden scrollbar-thin"><a href="/"${attr_class(`flex items-center gap-3 px-3 py-2 rounded-lg transition-all duration-200 group relative ${stringify(store_get($$store_subs ??= {}, "$page", page).url.pathname === "/" ? "bg-primary-50 dark:bg-primary-900/10 text-primary-600 dark:text-primary-400" : "text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-slate-200")}`)}${attr("title", store_get($$store_subs ??= {}, "$sidebarCollapsed", sidebarCollapsed) ? "Dashboard" : "")}>`);
    Layout_dashboard($$renderer2, { size: 20, class: "shrink-0" });
    $$renderer2.push(`<!----> <span${attr_class(`whitespace-nowrap font-medium transition-opacity duration-200 ${stringify(store_get($$store_subs ??= {}, "$sidebarCollapsed", sidebarCollapsed) ? "opacity-0 w-0" : "opacity-100")}`)}>Dashboard</span> `);
    if (store_get($$store_subs ??= {}, "$sidebarCollapsed", sidebarCollapsed)) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="absolute left-full ml-2 px-2 py-1 bg-slate-800 text-white text-xs rounded opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50">Dashboard</div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--></a> <div class="my-2 border-t border-slate-100 dark:border-slate-800"></div> <!--[-->`);
    const each_array = ensure_array_like(tools);
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      let tool = each_array[$$index];
      const isActive = store_get($$store_subs ??= {}, "$page", page).url.pathname.startsWith(tool.href);
      $$renderer2.push(`<a${attr("href", tool.href)}${attr_class(`flex items-center gap-3 px-3 py-2 rounded-lg transition-all duration-200 group relative ${stringify(isActive ? "bg-primary-50 dark:bg-primary-900/10 text-primary-600 dark:text-primary-400" : "text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-slate-200")}`)}${attr("title", store_get($$store_subs ??= {}, "$sidebarCollapsed", sidebarCollapsed) ? tool.name : "")}><div class="shrink-0">`);
      if (tool.icon === "yaml") {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h-5"><path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Z"></path></svg>`);
      } else {
        $$renderer2.push("<!--[!-->");
        if (tool.icon === "table") {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h-5"><path stroke-linecap="round" stroke-linejoin="round" d="M3.375 19.5h17.25m-17.25 0a1.125 1.125 0 0 1-1.125-1.125M3.375 19.5h7.5c.621 0 1.125-.504 1.125-1.125m-9.75 0V5.625m0 12.75v-1.5c0-.621.504-1.125 1.125-1.125m18.375 2.625V5.625m0 12.75c0 .621-.504 1.125-1.125 1.125m1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125m0 3.75h-7.5A1.125 1.125 0 0 1 12 18.375m9.75-12.75c0-.621-.504-1.125-1.125-1.125H3.375c-.621 0-1.125.504-1.125 1.125m19.5 0v1.5c0 .621-.504 1.125-1.125 1.125M2.25 5.625v1.5c0 .621.504 1.125 1.125 1.125m0 0h17.25m-17.25 0h7.5c.621 0 1.125.504 1.125 1.125M3.375 8.25c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125m17.25-3.75h-7.5c-.621 0-1.125.504-1.125 1.125m8.625-1.125c.621 0 1.125.504 1.125 1.125v1.5c0 .621-.504 1.125-1.125 1.125m-17.25 0h7.5m-7.5 0c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125M12 10.875v-1.5m0 1.5c0 .621-.504 1.125-1.125 1.125M12 10.875c0 .621.504 1.125 1.125 1.125m-2.25 0c.621 0 1.125.504 1.125 1.125M13.125 12h7.5m-7.5 0c-.621 0-1.125.504-1.125 1.125M20.625 12c.621 0 1.125.504 1.125 1.125v1.5c0 .621-.504 1.125-1.125 1.125m-17.25 0h7.5M12 14.625v-1.5m0 1.5c0 .621-.504 1.125-1.125 1.125M12 14.625c0 .621.504 1.125 1.125 1.125m-2.25 0c.621 0 1.125.504 1.125 1.125m0 1.5v-1.5m0 0c0-.621.504-1.125 1.125-1.125m0 0h7.5"></path></svg>`);
        } else {
          $$renderer2.push("<!--[!-->");
          if (tool.icon === "json") {
            $$renderer2.push("<!--[-->");
            $$renderer2.push(`<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h-5"><path stroke-linecap="round" stroke-linejoin="round" d="M17.25 6.75 22.5 12l-5.25 5.25m-10.5 0L1.5 12l5.25-5.25m7.5-3-4.5 16.5"></path></svg>`);
          } else {
            $$renderer2.push("<!--[!-->");
            if (tool.icon === "diagram") {
              $$renderer2.push("<!--[-->");
              $$renderer2.push(`<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h-5"><path stroke-linecap="round" stroke-linejoin="round" d="M7.5 14.25v2.25m3-4.5v4.5m3-6.75v6.75m3-9v9M6 20.25h12A2.25 2.25 0 0 0 20.25 18V6A2.25 2.25 0 0 0 18 3.75H6A2.25 2.25 0 0 0 3.75 6v12A2.25 2.25 0 0 0 6 20.25Z"></path></svg>`);
            } else {
              $$renderer2.push("<!--[!-->");
              if (tool.icon === "prompt") {
                $$renderer2.push("<!--[-->");
                $$renderer2.push(`<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h-5"><path stroke-linecap="round" stroke-linejoin="round" d="M7.5 8.25h9m-9 3H12m-9.75 1.51c0 1.6 1.123 2.994 2.707 3.227 1.129.166 2.27.293 3.423.379.35.026.67.21.865.501L12 21l2.755-4.133a1.14 1.14 0 0 1 .865-.501 48.172 48.172 0 0 0 3.423-.379c1.584-.233 2.707-1.626 2.707-3.228V6.741c0-1.602-1.123-2.995-2.707-3.228A48.394 48.394 0 0 0 12 3c-2.392 0-4.744.175-7.043.513C3.373 3.746 2.25 5.14 2.25 6.741v6.018Z"></path></svg>`);
              } else {
                $$renderer2.push("<!--[!-->");
                if (tool.icon === "agent") {
                  $$renderer2.push("<!--[-->");
                  $$renderer2.push(`<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h-5"><path stroke-linecap="round" stroke-linejoin="round" d="M9.813 15.904 9 18.75l-.813-2.846a4.5 4.5 0 0 0-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 0 0 3.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 0 0 3.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 0 0-3.09 3.09ZM18.259 8.715 18 9.75l-.259-1.035a3.375 3.375 0 0 0-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 0 0 2.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 0 0 2.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 0 0-2.456 2.456ZM16.894 20.567 16.5 21.75l-.394-1.183a2.25 2.25 0 0 0-1.423-1.423L13.5 18.75l1.183-.394a2.25 2.25 0 0 0 1.423-1.423l.394-1.183.394 1.183a2.25 2.25 0 0 0 1.423 1.423l1.183.394-1.183.394a2.25 2.25 0 0 0-1.423 1.423Z"></path></svg>`);
                } else {
                  $$renderer2.push("<!--[!-->");
                  if (tool.icon === "diff") {
                    $$renderer2.push("<!--[-->");
                    $$renderer2.push(`<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h-5"><path stroke-linecap="round" stroke-linejoin="round" d="M7.5 21 3 16.5m0 0L7.5 12M3 16.5h13.5m0-13.5L21 7.5m0 0L16.5 12M21 7.5H7.5"></path></svg>`);
                  } else {
                    $$renderer2.push("<!--[!-->");
                    if (tool.icon === "regex") {
                      $$renderer2.push("<!--[-->");
                      $$renderer2.push(`<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h-5"><path stroke-linecap="round" stroke-linejoin="round" d="M12 21a9.004 9.004 0 0 0 8.716-6.747M12 21a9.004 9.004 0 0 1-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3m0 0a8.997 8.997 0 0 1 7.843 4.582M12 3a8.997 8.997 0 0 0-7.843 4.582m15.686 0A11.953 11.953 0 0 1 12 10.5c-2.998 0-5.74-1.1-7.843-2.918m15.686 0A8.959 8.959 0 0 1 21 12c0 .778-.099 1.533-.284 2.253m0 0A17.919 17.919 0 0 1 12 16.5c-3.162 0-6.133-.815-8.716-2.247m0 0A9.015 9.015 0 0 1 3 12c0-1.605.42-3.113 1.157-4.418"></path></svg>`);
                    } else {
                      $$renderer2.push("<!--[!-->");
                    }
                    $$renderer2.push(`<!--]-->`);
                  }
                  $$renderer2.push(`<!--]-->`);
                }
                $$renderer2.push(`<!--]-->`);
              }
              $$renderer2.push(`<!--]-->`);
            }
            $$renderer2.push(`<!--]-->`);
          }
          $$renderer2.push(`<!--]-->`);
        }
        $$renderer2.push(`<!--]-->`);
      }
      $$renderer2.push(`<!--]--></div> <span${attr_class(`whitespace-nowrap font-medium transition-opacity duration-200 ${stringify(store_get($$store_subs ??= {}, "$sidebarCollapsed", sidebarCollapsed) ? "opacity-0 w-0" : "opacity-100")}`)}>${escape_html(tool.name)}</span> `);
      if (store_get($$store_subs ??= {}, "$sidebarCollapsed", sidebarCollapsed)) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="absolute left-full ml-2 px-2 py-1 bg-slate-800 text-white text-xs rounded opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50">${escape_html(tool.name)}</div>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></a>`);
    }
    $$renderer2.push(`<!--]--> <div class="h-8"></div></nav></aside>`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
  });
}
function CommandPalette($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let search = "";
    const COMMANDS = [
      {
        id: "nav-home",
        title: "Home",
        icon: House,
        action: () => goto()
      },
      {
        id: "nav-prompts",
        title: "Prompt Hub",
        icon: Brain_circuit,
        action: () => goto()
      },
      {
        id: "nav-diagrams",
        title: "Diagram Editor",
        icon: Code,
        action: () => goto()
      },
      {
        id: "nav-tables",
        title: "Table Editor",
        icon: Table,
        action: () => goto()
      },
      {
        id: "nav-yaml",
        title: "YAML Editor",
        icon: File_text,
        action: () => goto()
      },
      {
        id: "act-theme",
        title: "Toggle Theme",
        icon: Sun,
        action: () => toggleTheme()
      }
    ];
    COMMANDS.filter((c) => c.title.toLowerCase().includes(search.toLowerCase()));
    function toggleTheme() {
      document.documentElement.classList.toggle("dark");
    }
    {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
  });
}
function createClipboardStore() {
  let history = [];
  return {
    get history() {
      return history;
    },
    add(text, type = "text") {
      if (!text || history.length > 0 && history[0].text === text) return;
      const item = { id: crypto.randomUUID(), text, timestamp: Date.now(), type };
      history = [item, ...history.slice(0, 49)];
    },
    clear() {
      history = [];
    },
    remove(id) {
      history = history.filter((h) => h.id !== id);
    }
  };
}
const clipboardStore = createClipboardStore();
function ClipboardPanel($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { isOpen = false } = $$props;
    let searchQuery = "";
    let filteredHistory = clipboardStore.history.filter((item) => item.text.toLowerCase().includes(searchQuery.toLowerCase()));
    function formatTime(ts) {
      const diff = Date.now() - ts;
      if (diff < 6e4) return "Just now";
      if (diff < 36e5) return `${Math.floor(diff / 6e4)}m ago`;
      return new Date(ts).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    }
    if (isOpen) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="fixed inset-0 bg-black/20 dark:bg-black/60 backdrop-blur-sm z-50 transition-opacity"></div> <div class="fixed right-0 top-0 h-full w-80 md:w-96 bg-white dark:bg-slate-900 shadow-2xl z-[60] flex flex-col border-l border-slate-200 dark:border-slate-800"><div class="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-black/20"><div class="flex items-center gap-2"><div class="p-2 bg-indigo-100 dark:bg-indigo-900/40 text-indigo-600 dark:text-indigo-400 rounded-lg">`);
      Clipboard($$renderer2, { size: 18 });
      $$renderer2.push(`<!----></div> <h2 class="font-bold text-slate-900 dark:text-white">Clipboard History</h2></div> <button class="p-2 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-full transition-colors text-slate-500">`);
      X($$renderer2, { size: 20 });
      $$renderer2.push(`<!----></button></div> <div class="p-4 space-y-4 flex-1 flex flex-col min-h-0"><div class="relative">`);
      Search($$renderer2, { class: "absolute left-3 top-2.5 text-slate-400", size: 14 });
      $$renderer2.push(`<!----> <input type="text"${attr("value", searchQuery)} placeholder="Search history..." class="w-full pl-9 pr-4 py-2 text-sm bg-slate-100 dark:bg-slate-800 border-none rounded-xl focus:ring-2 focus:ring-primary-500 outline-none"/></div> <div class="flex-1 overflow-y-auto min-h-0 pr-1 space-y-3">`);
      if (filteredHistory.length > 0) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<!--[-->`);
        const each_array = ensure_array_like(filteredHistory);
        for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
          let item = each_array[$$index];
          $$renderer2.push(`<div class="group relative bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl p-4 transition-all hover:shadow-md hover:border-primary-500/30"><div class="flex justify-between items-center mb-2"><div class="flex items-center gap-2"><span class="text-[9px] font-bold text-slate-400 uppercase tracking-widest">${escape_html(item.type)}</span> <span class="text-[9px] text-slate-400 flex items-center gap-1">`);
          Clock($$renderer2, { size: 10 });
          $$renderer2.push(`<!----> ${escape_html(formatTime(item.timestamp))}</span></div> <div class="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity"><button class="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-md text-slate-500 hover:text-primary-500" title="Copy again">`);
          Copy($$renderer2, { size: 14 });
          $$renderer2.push(`<!----></button> <button class="p-1.5 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-md text-slate-400 hover:text-red-500">`);
          Trash_2($$renderer2, { size: 14 });
          $$renderer2.push(`<!----></button></div></div> <p class="text-xs font-mono text-slate-600 dark:text-slate-300 line-clamp-3 break-all whitespace-pre-wrap">${escape_html(item.text)}</p></div>`);
        }
        $$renderer2.push(`<!--]-->`);
      } else {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push(`<div class="h-64 flex flex-col items-center justify-center text-slate-400 text-center px-8 border-2 border-dashed border-slate-100 dark:border-slate-800 rounded-3xl">`);
        Clipboard($$renderer2, { size: 32, class: "opacity-10 mb-4" });
        $$renderer2.push(`<!----> <p class="text-sm font-medium">History is empty</p> <p class="text-xs mt-1">Copied text from this app will appear here.</p></div>`);
      }
      $$renderer2.push(`<!--]--></div></div> `);
      if (clipboardStore.history.length > 0) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="p-4 border-t border-slate-100 dark:border-slate-800">`);
        Button($$renderer2, {
          variant: "ghost",
          class: "w-full text-red-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20",
          onclick: () => clipboardStore.clear(),
          children: ($$renderer3) => {
            Trash_2($$renderer3, { size: 16, class: "mr-2" });
            $$renderer3.push(`<!----> Clear All History`);
          },
          $$slots: { default: true }
        });
        $$renderer2.push(`<!----></div>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
    bind_props($$props, { isOpen });
  });
}
function _layout($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let { children } = $$props;
    let isClipboardOpen = false;
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      head("12qhfyh", $$renderer3, ($$renderer4) => {
        $$renderer4.push(`<link rel="preconnect" href="https://fonts.googleapis.com"/> <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="anonymous"/> <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&amp;family=JetBrains+Mono:wght@400;500;600&amp;display=swap" rel="stylesheet"/>`);
      });
      $$renderer3.push(`<div class="min-h-screen bg-slate-50 dark:bg-slate-950">`);
      CommandPalette($$renderer3);
      $$renderer3.push(`<!----> `);
      Sidebar($$renderer3);
      $$renderer3.push(`<!----> `);
      ClipboardPanel($$renderer3, {
        get isOpen() {
          return isClipboardOpen;
        },
        set isOpen($$value) {
          isClipboardOpen = $$value;
          $$settled = false;
        }
      });
      $$renderer3.push(`<!----> <main${attr_class(` min-h-screen transition-all duration-300 ease-out ${stringify(store_get($$store_subs ??= {}, "$sidebarCollapsed", sidebarCollapsed) ? "ml-16" : "ml-60")} `)}><div class="p-6">`);
      children($$renderer3);
      $$renderer3.push(`<!----></div></main> <div class="fixed bottom-6 right-6 z-40 flex flex-col gap-3"><button class="w-12 h-12 rounded-full bg-white dark:bg-slate-800 shadow-xl border border-slate-200 dark:border-slate-700 flex items-center justify-center text-slate-600 dark:text-slate-400 hover:text-primary-500 dark:hover:text-primary-400 hover:scale-110 transition-all group" title="Clipboard History">`);
      Clipboard($$renderer3, { size: 20 });
      $$renderer3.push(`<!----> <span class="absolute right-0 top-0 w-3 h-3 bg-primary-500 rounded-full border-2 border-white dark:border-slate-800 scale-0 group-hover:scale-100 transition-transform"></span></button></div></div>`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
    if ($$store_subs) unsubscribe_stores($$store_subs);
  });
}
export {
  _layout as default
};
