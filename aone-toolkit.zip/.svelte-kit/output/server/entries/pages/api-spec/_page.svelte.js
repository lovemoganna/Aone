import { a7 as head, a4 as ensure_array_like, a0 as attr_class, a1 as stringify } from "../../../chunks/index2.js";
import { B as Button } from "../../../chunks/Button.js";
import { P as Panel } from "../../../chunks/Panel.js";
import { C as Chevron_right } from "../../../chunks/chevron-right.js";
import { S as Search } from "../../../chunks/search.js";
import { F as File_braces } from "../../../chunks/file-braces.js";
import { G as Globe } from "../../../chunks/globe.js";
import { I as Info } from "../../../chunks/info.js";
import { e as escape_html } from "../../../chunks/context.js";
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let specInput = "";
    let parsedSpec = null;
    let selectedPath = null;
    function parseSpec() {
      try {
        parsedSpec = JSON.parse(specInput);
        selectedPath = Object.keys(parsedSpec.paths || {})[0];
      } catch (e) {
        alert("Invalid OpenAPI JSON");
      }
    }
    let paths = parsedSpec?.paths ? Object.keys(parsedSpec.paths) : [];
    head("jwn8o1", $$renderer2, ($$renderer3) => {
      $$renderer3.title(($$renderer4) => {
        $$renderer4.push(`<title>OpenAPI Explorer - Aone Toolkit</title>`);
      });
    });
    $$renderer2.push(`<div class="h-[calc(100vh-3rem)] p-4 flex flex-col space-y-4"><div class="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-4 min-h-0">`);
    {
      let header = function($$renderer3) {
        $$renderer3.push(`<div class="flex items-center gap-2">`);
        File_braces($$renderer3, { size: 16, class: "text-blue-500" });
        $$renderer3.push(`<!----> <h2 class="font-semibold">Spec Source</h2></div>`);
      };
      Panel($$renderer2, {
        class: "flex flex-col min-h-0",
        header,
        children: ($$renderer3) => {
          $$renderer3.push(`<div class="flex-1 flex flex-col p-4 space-y-4"><textarea class="flex-1 p-4 font-mono text-[10px] bg-slate-50 dark:bg-black/20 border rounded-xl resize-none outline-none" placeholder="Paste OpenAPI 3.0 JSON here...">`);
          const $$body = escape_html(specInput);
          if ($$body) {
            $$renderer3.push(`${$$body}`);
          }
          $$renderer3.push(`</textarea> `);
          Button($$renderer3, {
            class: "w-full",
            onclick: parseSpec,
            children: ($$renderer4) => {
              $$renderer4.push(`<!---->Parse Specification`);
            },
            $$slots: { default: true }
          });
          $$renderer3.push(`<!----></div>`);
        }
      });
    }
    $$renderer2.push(`<!----> `);
    {
      let header = function($$renderer3) {
        $$renderer3.push(`<div class="flex items-center gap-2">`);
        Globe($$renderer3, { size: 16, class: "text-emerald-500" });
        $$renderer3.push(`<!----> <h2 class="font-semibold">Endpoints (${escape_html(paths.length)})</h2></div>`);
      };
      Panel($$renderer2, {
        class: "flex flex-col min-h-0",
        header,
        children: ($$renderer3) => {
          $$renderer3.push(`<div class="flex-1 overflow-y-auto p-2"><!--[-->`);
          const each_array = ensure_array_like(paths);
          for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
            let path = each_array[$$index];
            $$renderer3.push(`<button${attr_class(`w-full text-left p-3 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors flex items-center gap-3 ${stringify(selectedPath === path ? "bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600" : "")}`)}>`);
            Chevron_right($$renderer3, { size: 14, class: "opacity-30" });
            $$renderer3.push(`<!----> <span class="text-xs font-mono truncate">${escape_html(path)}</span></button>`);
          }
          $$renderer3.push(`<!--]--></div>`);
        }
      });
    }
    $$renderer2.push(`<!----> `);
    {
      let header = function($$renderer3) {
        $$renderer3.push(`<div class="flex items-center gap-2">`);
        Info($$renderer3, { size: 16, class: "text-indigo-500" });
        $$renderer3.push(`<!----> <h2 class="font-semibold">Details</h2></div>`);
      };
      Panel($$renderer2, {
        class: "flex flex-col min-h-0 overflow-y-auto",
        header,
        children: ($$renderer3) => {
          $$renderer3.push(`<div class="p-6 space-y-6">`);
          if (selectedPath && parsedSpec.paths[selectedPath]) {
            $$renderer3.push("<!--[-->");
            const methods = Object.keys(parsedSpec.paths[selectedPath]);
            $$renderer3.push(`<!--[-->`);
            const each_array_1 = ensure_array_like(methods);
            for (let $$index_2 = 0, $$length = each_array_1.length; $$index_2 < $$length; $$index_2++) {
              let method = each_array_1[$$index_2];
              $$renderer3.push(`<div class="space-y-4"><div class="flex items-center gap-3"><span class="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-primary-100 text-primary-600">${escape_html(method)}</span> <span class="text-sm font-semibold">${escape_html(parsedSpec.paths[selectedPath][method].summary || "No summary")}</span></div> <p class="text-xs text-slate-500 leading-relaxed">${escape_html(parsedSpec.paths[selectedPath][method].description || "")}</p> `);
              if (parsedSpec.paths[selectedPath][method].parameters) {
                $$renderer3.push("<!--[-->");
                $$renderer3.push(`<div class="space-y-2"><div class="text-[9px] font-bold text-slate-400 uppercase">Parameters</div> <div class="space-y-1"><!--[-->`);
                const each_array_2 = ensure_array_like(parsedSpec.paths[selectedPath][method].parameters);
                for (let $$index_1 = 0, $$length2 = each_array_2.length; $$index_1 < $$length2; $$index_1++) {
                  let param = each_array_2[$$index_1];
                  $$renderer3.push(`<div class="flex justify-between p-2 bg-slate-50 dark:bg-slate-800 rounded border text-[10px]"><span class="font-mono font-bold text-indigo-600">${escape_html(param.name)} <span class="text-slate-400 font-normal">(${escape_html(param.in)})</span></span> <span class="text-slate-400">${escape_html(param.required ? "Required" : "Optional")}</span></div>`);
                }
                $$renderer3.push(`<!--]--></div></div>`);
              } else {
                $$renderer3.push("<!--[!-->");
              }
              $$renderer3.push(`<!--]--></div>`);
            }
            $$renderer3.push(`<!--]-->`);
          } else {
            $$renderer3.push("<!--[!-->");
            $$renderer3.push(`<div class="h-full flex flex-col items-center justify-center opacity-20 text-center">`);
            Search($$renderer3, { size: 48 });
            $$renderer3.push(`<!----> <p class="mt-4 text-sm font-bold">Select an endpoint</p></div>`);
          }
          $$renderer3.push(`<!--]--></div>`);
        }
      });
    }
    $$renderer2.push(`<!----></div></div>`);
  });
}
export {
  _page as default
};
