import { a0 as attr_class, a8 as clsx, a4 as ensure_array_like, a3 as attr, a1 as stringify, a6 as bind_props, a7 as head } from "../../../chunks/index2.js";
import { B as Button } from "../../../chunks/Button.js";
import { P as Panel } from "../../../chunks/Panel.js";
import { e as escape_html } from "../../../chunks/context.js";
import { T as TypeGenModal } from "../../../chunks/TypeGenModal.js";
import { JSONPath } from "jsonpath-plus";
import { S as Search } from "../../../chunks/search.js";
import { I as Info } from "../../../chunks/info.js";
import { C as Code_xml } from "../../../chunks/code-xml.js";
import { T as Trash_2 } from "../../../chunks/trash-2.js";
function isObject(val) {
  return val !== null && typeof val === "object" && !Array.isArray(val);
}
function isArray(val) {
  return Array.isArray(val);
}
function getValueDisplay(key, val) {
  if (isArray(val)) {
    const hasComplexItems = val.some((item) => isObject(item) || isArray(item));
    if (hasComplexItems || val.length > 5) {
      return `Array[${val.length}]`;
    }
    return `[${val.map((item) => typeof item === "string" ? item : JSON.stringify(item)).join(", ")}]`;
  }
  if (isObject(val)) return "";
  return String(val);
}
function hasExpandableChildren(val) {
  if (isObject(val)) return Object.keys(val).length > 0;
  if (isArray(val)) return val.length > 0 && val.some((item) => isObject(item) || isArray(item));
  return false;
}
function getNodeIcon(val) {
  if (isArray(val)) return "tags";
  if (isObject(val)) {
    if (Object.keys(val).length === 0) return "cube";
    return "sitemap";
  }
  return "key";
}
function JsonTreeView_1($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { data, path = [], level = 0, expandedKeys = void 0, onAction } = $$props;
    function getNodeKey(p) {
      return p.join("\0");
    }
    $$renderer2.push(`<ul${attr_class(clsx(level > 0 ? "pl-4 border-l border-slate-200 dark:border-slate-700 mt-1" : ""))}>`);
    if (data && typeof data === "object") {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<!--[-->`);
      const each_array = ensure_array_like(Object.entries(data));
      for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
        let [key, value] = each_array[$$index];
        const currentPath = [...path, key];
        const nodeKey = getNodeKey(currentPath);
        const hasChildren = hasExpandableChildren(value);
        const isExpanded = expandedKeys.has(nodeKey);
        const icon = getNodeIcon(value);
        $$renderer2.push(`<li class="my-1.5"><div class="group flex items-center hover:bg-primary-50 dark:hover:bg-slate-800 rounded px-2 py-1.5 transition-colors focus:bg-primary-100 dark:focus:bg-slate-700 focus:outline-none focus:ring-1 focus:ring-primary-300" role="treeitem" aria-selected="false" tabindex="0"><button type="button" class="w-6 h-6 flex items-center justify-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors focus:outline-none shrink-0"${attr("disabled", !hasChildren, true)} tabindex="-1">`);
        if (hasChildren) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"${attr_class(`w-4 h-4 transition-transform duration-200 ${stringify(isExpanded ? "rotate-90" : "")}`)}><path fill-rule="evenodd" d="M7.21 14.77a.75.75 0 01.02-1.06L11.168 10 7.23 6.29a.75.75 0 111.04-1.08l4.5 4.25a.75.75 0 010 1.08l-4.5 4.25a.75.75 0 01-1.06-.02z" clip-rule="evenodd"></path></svg>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--></button> <span class="w-6 h-6 flex items-center justify-center mr-1 shrink-0">`);
        if (icon === "tags") {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4 text-purple-500"><path stroke-linecap="round" stroke-linejoin="round" d="M9.568 3H5.25A2.25 2.25 0 0 0 3 5.25v4.318c0 .597.237 1.17.659 1.591l9.581 9.581c.699.699 1.78.872 2.607.33a18.095 18.095 0 0 0 5.223-5.223c.542-.827.369-1.908-.33-2.607L11.16 3.66A2.25 2.25 0 0 0 9.568 3Z"></path><path stroke-linecap="round" stroke-linejoin="round" d="M6 6h.008v.008H6V6Z"></path></svg>`);
        } else {
          $$renderer2.push("<!--[!-->");
          if (icon === "cube") {
            $$renderer2.push("<!--[-->");
            $$renderer2.push(`<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4 text-slate-400"><path stroke-linecap="round" stroke-linejoin="round" d="m21 7.5-9-5.25L3 7.5m18 0-9 5.25m9-5.25v9l-9 5.25M3 7.5l9 5.25M3 7.5v9l9 5.25m0-9v9"></path></svg>`);
          } else {
            $$renderer2.push("<!--[!-->");
            if (icon === "sitemap") {
              $$renderer2.push("<!--[-->");
              $$renderer2.push(`<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4 text-blue-500"><path stroke-linecap="round" stroke-linejoin="round" d="M7.217 10.907a2.25 2.25 0 1 0 0 2.186m0-2.186c.18.324.283.696.283 1.093s-.103.77-.283 1.093m0-2.186 9.566-5.314m-9.566 7.5 9.566 5.314m0 0a2.25 2.25 0 1 0 3.935 2.186 2.25 2.25 0 0 0-3.935-2.186Zm0-12.814a2.25 2.25 0 1 0 3.933-2.185 2.25 2.25 0 0 0-3.933 2.185Z"></path></svg>`);
            } else {
              $$renderer2.push("<!--[!-->");
              $$renderer2.push(`<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4 text-green-500"><path stroke-linecap="round" stroke-linejoin="round" d="M15.75 5.25a3 3 0 0 1 3 3m3 0a6 6 0 0 1-7.029 5.912c-.563-.097-1.159.026-1.563.43L10.5 17.25H8.25v2.25H6v2.25H2.25v-2.818c0-.597.237 1.17.659 1.591l6.499-6.499c.404-.404.527-1 .43-1.563A6 6 0 1 1 21.75 8.25Z"></path></svg>`);
            }
            $$renderer2.push(`<!--]-->`);
          }
          $$renderer2.push(`<!--]-->`);
        }
        $$renderer2.push(`<!--]--></span> <div class="flex-grow font-mono text-sm truncate"><span class="font-medium text-slate-700 dark:text-slate-200">${escape_html(key)}</span> `);
        if (!isObject(value)) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<span class="mx-1 text-slate-400">:</span> <span${attr_class(clsx(isArray(value) ? "text-purple-600 dark:text-purple-400" : "text-blue-600 dark:text-blue-400"))}>${escape_html(getValueDisplay(key, value))}</span>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--></div></div> `);
        if (hasChildren && isExpanded) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<div>`);
          JsonTreeView_1($$renderer2, {
            data: value,
            path: currentPath,
            level: level + 1,
            expandedKeys,
            onAction
          });
          $$renderer2.push(`<!----></div>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--></li>`);
      }
      $$renderer2.push(`<!--]-->`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--></ul>`);
    bind_props($$props, { expandedKeys });
  });
}
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let rawInput = "";
    let parsedData = null;
    let jsonPath = "$";
    let queryResult = null;
    let error = null;
    let isTypeGenOpen = false;
    let expandedKeys = /* @__PURE__ */ new Set();
    function parseInput() {
      error = null;
      if (!rawInput.trim()) {
        parsedData = null;
        queryResult = null;
        return;
      }
      try {
        parsedData = JSON.parse(rawInput);
        handleQuery();
      } catch (e) {
        error = "Invalid JSON: " + e.message;
        parsedData = null;
      }
    }
    function handleQuery() {
      if (!parsedData) return;
      try {
        queryResult = JSONPath({ path: jsonPath, json: parsedData });
        error = null;
      } catch (e) {
        error = "JSONPath Error: " + e.message;
      }
    }
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      head("131fyaa", $$renderer3, ($$renderer4) => {
        $$renderer4.title(($$renderer5) => {
          $$renderer5.push(`<title>API Response Viewer - Aone Toolkit</title>`);
        });
      });
      $$renderer3.push(`<div class="h-[calc(100vh-3rem)] p-4 flex flex-col space-y-4"><div class="flex-1 grid grid-cols-1 lg:grid-cols-2 gap-4 min-h-0">`);
      {
        let header = function($$renderer4) {
          $$renderer4.push(`<div class="flex items-center justify-between w-full"><div class="flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 flex items-center justify-center">`);
          Code_xml($$renderer4, { size: 16 });
          $$renderer4.push(`<!----></div> <h2 class="font-semibold text-slate-900 dark:text-white">Response Input</h2></div> <div class="flex gap-2">`);
          Button($$renderer4, {
            variant: "ghost",
            size: "sm",
            onclick: () => {
              rawInput = "";
              parseInput();
            },
            children: ($$renderer5) => {
              Trash_2($$renderer5, { size: 14, class: "mr-1" });
              $$renderer5.push(`<!----> Clear`);
            },
            $$slots: { default: true }
          });
          $$renderer4.push(`<!----> `);
          Button($$renderer4, {
            size: "sm",
            onclick: parseInput,
            children: ($$renderer5) => {
              $$renderer5.push(`<!---->Parse JSON`);
            },
            $$slots: { default: true }
          });
          $$renderer4.push(`<!----></div></div>`);
        };
        Panel($$renderer3, {
          class: "flex flex-col min-h-0",
          header,
          children: ($$renderer4) => {
            $$renderer4.push(`<div class="flex-1 p-0 overflow-hidden relative"><textarea class="w-full h-full p-6 font-mono text-sm bg-transparent resize-none focus:outline-none dark:text-slate-300" placeholder="Paste API JSON response here...">`);
            const $$body = escape_html(rawInput);
            if ($$body) {
              $$renderer4.push(`${$$body}`);
            }
            $$renderer4.push(`</textarea> `);
            if (error && !parsedData) {
              $$renderer4.push("<!--[-->");
              $$renderer4.push(`<div class="absolute bottom-4 left-4 right-4 p-3 bg-red-50 dark:bg-red-900/30 border border-red-100 dark:border-red-900/20 rounded-lg text-red-600 dark:text-red-400 text-sm">${escape_html(error)}</div>`);
            } else {
              $$renderer4.push("<!--[!-->");
            }
            $$renderer4.push(`<!--]--></div>`);
          }
        });
      }
      $$renderer3.push(`<!----> `);
      {
        let header = function($$renderer4) {
          $$renderer4.push(`<div class="flex items-center justify-between w-full"><div class="flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">`);
          Search($$renderer4, { size: 16 });
          $$renderer4.push(`<!----></div> <h2 class="font-semibold text-slate-900 dark:text-white">Analysis &amp; Tree View</h2></div> `);
          if (parsedData) {
            $$renderer4.push("<!--[-->");
            Button($$renderer4, {
              variant: "secondary",
              size: "sm",
              onclick: () => isTypeGenOpen = true,
              children: ($$renderer5) => {
                Code_xml($$renderer5, { size: 14, class: "mr-1" });
                $$renderer5.push(`<!----> Type Gen`);
              },
              $$slots: { default: true }
            });
          } else {
            $$renderer4.push("<!--[!-->");
          }
          $$renderer4.push(`<!--]--></div>`);
        };
        Panel($$renderer3, {
          class: "flex flex-col min-h-0",
          header,
          children: ($$renderer4) => {
            $$renderer4.push(`<div class="flex-1 flex flex-col min-h-0"><div class="p-4 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-black/10"><div class="relative">`);
            Search($$renderer4, { class: "absolute left-3 top-2.5 text-slate-400", size: 14 });
            $$renderer4.push(`<!----> <input type="text"${attr("value", jsonPath)} placeholder="JSONPath (e.g. $.items[*].name)" class="w-full pl-9 pr-4 py-2 text-xs font-mono bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-emerald-500 focus:outline-none"/></div> `);
            {
              $$renderer4.push("<!--[!-->");
            }
            $$renderer4.push(`<!--]--></div> <div class="flex-1 overflow-auto p-4">`);
            if (parsedData) {
              $$renderer4.push("<!--[-->");
              JsonTreeView_1($$renderer4, {
                data: parsedData,
                get expandedKeys() {
                  return expandedKeys;
                },
                set expandedKeys($$value) {
                  expandedKeys = $$value;
                  $$settled = false;
                }
              });
            } else {
              $$renderer4.push("<!--[!-->");
              $$renderer4.push(`<div class="h-full flex flex-col items-center justify-center text-slate-400 text-center space-y-4">`);
              Info($$renderer4, { size: 40, class: "text-slate-200 dark:text-slate-800" });
              $$renderer4.push(`<!----> <p class="text-sm">Parse JSON to explore the response structure.</p></div>`);
            }
            $$renderer4.push(`<!--]--></div></div>`);
          }
        });
      }
      $$renderer3.push(`<!----></div></div> `);
      if (isTypeGenOpen && parsedData) {
        $$renderer3.push("<!--[-->");
        TypeGenModal($$renderer3, {
          jsonData: parsedData,
          isOpen: isTypeGenOpen,
          onClose: () => isTypeGenOpen = false
        });
      } else {
        $$renderer3.push("<!--[!-->");
      }
      $$renderer3.push(`<!--]-->`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
  });
}
export {
  _page as default
};
