import { Z as sanitize_props, _ as spread_props, $ as slot, a7 as head, a4 as ensure_array_like, a3 as attr, a0 as attr_class, a1 as stringify } from "../../../chunks/index2.js";
import { B as Button } from "../../../chunks/Button.js";
import { P as Panel } from "../../../chunks/Panel.js";
import { I as Icon } from "../../../chunks/Icon.js";
import { T as Trash_2 } from "../../../chunks/trash-2.js";
import { e as escape_html } from "../../../chunks/context.js";
function Chart_no_axes_column_increasing($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    ["path", { "d": "M5 21v-6" }],
    ["path", { "d": "M12 21V9" }],
    ["path", { "d": "M19 21V3" }]
  ];
  Icon($$renderer, spread_props([
    { name: "chart-no-axes-column-increasing" },
    $$sanitized_props,
    {
      /**
       * @component @name ChartNoAxesColumnIncreasing
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNNSAyMXYtNiIgLz4KICA8cGF0aCBkPSJNMTIgMjFWOSIgLz4KICA8cGF0aCBkPSJNMTkgMjFWMyIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/chart-no-axes-column-increasing
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let dataInput = '[\n  {"label": "Jan", "value": 45},\n  {"label": "Feb", "value": 52},\n  {"label": "Mar", "value": 38},\n  {"label": "Apr", "value": 65},\n  {"label": "May", "value": 48}\n]';
    let chartData = [];
    let maxVal = Math.max(...chartData.map((d) => d.value), 1);
    head("ldhqum", $$renderer2, ($$renderer3) => {
      $$renderer3.title(($$renderer4) => {
        $$renderer4.push(`<title>Data Insights - Aone Toolkit</title>`);
      });
    });
    $$renderer2.push(`<div class="h-[calc(100vh-3rem)] p-4 flex flex-col space-y-4"><div class="flex-1 grid grid-cols-1 lg:grid-cols-2 gap-4 min-h-0">`);
    {
      let header = function($$renderer3) {
        $$renderer3.push(`<div class="flex items-center justify-between w-full"><h2 class="font-semibold">Data Source (JSON)</h2> `);
        Button($$renderer3, {
          variant: "ghost",
          size: "sm",
          onclick: () => dataInput = "",
          children: ($$renderer4) => {
            Trash_2($$renderer4, { size: 14 });
          },
          $$slots: { default: true }
        });
        $$renderer3.push(`<!----></div>`);
      };
      Panel($$renderer2, {
        class: "flex flex-col min-h-0",
        header,
        children: ($$renderer3) => {
          $$renderer3.push(`<textarea class="flex-1 p-6 font-mono text-xs bg-transparent resize-none focus:outline-none dark:text-slate-300" placeholder="Paste JSON array of objects here...">`);
          const $$body = escape_html(dataInput);
          if ($$body) {
            $$renderer3.push(`${$$body}`);
          }
          $$renderer3.push(`</textarea>`);
        }
      });
    }
    $$renderer2.push(`<!----> `);
    {
      let header = function($$renderer3) {
        $$renderer3.push(`<div class="flex items-center justify-between w-full"><h2 class="font-semibold">Visual Insight</h2> <div class="flex p-1 bg-slate-100 dark:bg-slate-800 rounded-lg"><button${attr_class(`px-3 py-1 text-xs font-medium rounded-md ${stringify("bg-white shadow text-primary-600")}`)}>Bar</button> <button${attr_class(`px-3 py-1 text-xs font-medium rounded-md ${stringify("text-slate-500")}`)}>Line</button></div></div>`);
      };
      Panel($$renderer2, {
        class: "flex flex-col min-h-0",
        header,
        children: ($$renderer3) => {
          $$renderer3.push(`<div class="flex-1 flex items-center justify-center p-12 bg-slate-50/30 dark:bg-black/10">`);
          if (chartData.length > 0) {
            $$renderer3.push("<!--[-->");
            $$renderer3.push(`<svg viewBox="0 0 400 200" class="w-full h-full"><line x1="40" y1="20" x2="40" y2="180" stroke="currentColor" stroke-width="1" class="text-slate-300 dark:text-slate-700"></line><line x1="40" y1="180" x2="380" y2="180" stroke="currentColor" stroke-width="1" class="text-slate-300 dark:text-slate-700"></line>`);
            {
              $$renderer3.push("<!--[-->");
              $$renderer3.push(`<!--[-->`);
              const each_array = ensure_array_like(chartData);
              for (let i = 0, $$length = each_array.length; i < $$length; i++) {
                let d = each_array[i];
                const barWidth = 300 / chartData.length;
                const h = d.value / maxVal * 150;
                $$renderer3.push(`<rect${attr("x", 50 + i * barWidth)}${attr("y", 180 - h)}${attr("width", barWidth * 0.7)}${attr("height", h)} fill="url(#grad)" rx="4" class="transition-all duration-500"></rect><text${attr("x", 50 + i * barWidth + barWidth * 0.35)} y="195" text-anchor="middle" class="text-[8px] fill-slate-400 font-mono">${escape_html(d.label)}</text>`);
              }
              $$renderer3.push(`<!--]-->`);
            }
            $$renderer3.push(`<!--]--><defs><linearGradient id="grad" x1="0%" y1="0%" x2="0%" y2="100%"><stop offset="0%" style="stop-color:rgb(79, 70, 229);stop-opacity:1"></stop><stop offset="100%" style="stop-color:rgb(139, 92, 246);stop-opacity:1"></stop></linearGradient></defs></svg>`);
          } else {
            $$renderer3.push("<!--[!-->");
            $$renderer3.push(`<div class="text-center opacity-20">`);
            Chart_no_axes_column_increasing($$renderer3, { size: 64 });
            $$renderer3.push(`<!----> <p class="mt-4">Paste array of objects to visualize</p></div>`);
          }
          $$renderer3.push(`<!--]--></div>`);
        }
      });
    }
    $$renderer2.push(`<!----></div></div>`);
  });
}
export {
  _page as default
};
