import { Z as sanitize_props, _ as spread_props, $ as slot, a7 as head, a3 as attr, a1 as stringify, a4 as ensure_array_like, a0 as attr_class } from "../../../chunks/index2.js";
import { B as Button } from "../../../chunks/Button.js";
import { P as Panel } from "../../../chunks/Panel.js";
import { I as Icon } from "../../../chunks/Icon.js";
import { C as Copy } from "../../../chunks/copy.js";
import { T as Trash_2 } from "../../../chunks/trash-2.js";
import { C as Check } from "../../../chunks/check.js";
import { e as escape_html } from "../../../chunks/context.js";
function Maximize_2($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    ["path", { "d": "M15 3h6v6" }],
    ["path", { "d": "m21 3-7 7" }],
    ["path", { "d": "m3 21 7-7" }],
    ["path", { "d": "M9 21H3v-6" }]
  ];
  Icon($$renderer, spread_props([
    { name: "maximize-2" },
    $$sanitized_props,
    {
      /**
       * @component @name Maximize2
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTUgM2g2djYiIC8+CiAgPHBhdGggZD0ibTIxIDMtNyA3IiAvPgogIDxwYXRoIGQ9Im0zIDIxIDctNyIgLz4KICA8cGF0aCBkPSJNOSAyMUgzdi02IiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/maximize-2
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Minimize_2($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    ["path", { "d": "m14 10 7-7" }],
    ["path", { "d": "M20 10h-6V4" }],
    ["path", { "d": "m3 21 7-7" }],
    ["path", { "d": "M4 14h6v6" }]
  ];
  Icon($$renderer, spread_props([
    { name: "minimize-2" },
    $$sanitized_props,
    {
      /**
       * @component @name Minimize2
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJtMTQgMTAgNy03IiAvPgogIDxwYXRoIGQ9Ik0yMCAxMGgtNlY0IiAvPgogIDxwYXRoIGQ9Im0zIDIxIDctNyIgLz4KICA8cGF0aCBkPSJNNCAxNGg2djYiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/minimize-2
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let input = "";
    let language = "json";
    let indent = 2;
    let error = null;
    let copied = false;
    const LANGUAGES = [
      { id: "json", label: "JSON" },
      { id: "html", label: "HTML" },
      { id: "css", label: "CSS" },
      { id: "sql", label: "SQL" }
    ];
    function format() {
      error = null;
      if (!input.trim()) return;
      try {
        switch (language) {
          case "json":
            const obj = JSON.parse(input);
            input = JSON.stringify(obj, null, indent);
            break;
          case "html":
            input = formatHTML(input);
            break;
          case "css":
            input = formatCSS(input);
            break;
          case "sql":
            input = formatSQL(input);
            break;
        }
      } catch (e) {
        error = "Format error: " + e.message;
      }
    }
    function minify() {
      error = null;
      if (!input.trim()) return;
      try {
        switch (language) {
          case "json":
            input = JSON.stringify(JSON.parse(input));
            break;
          case "html":
          case "css":
          case "sql":
            input = input.replace(/\s+/g, " ").trim();
            break;
        }
      } catch (e) {
        error = "Minify error: " + e.message;
      }
    }
    function formatHTML(html) {
      let formatted = "";
      let indent_str = " ".repeat(indent);
      let current_indent = 0;
      html.split(/>\s*</).forEach((node) => {
        if (node.match(/^\/\w/)) current_indent -= 1;
        formatted += indent_str.repeat(Math.max(0, current_indent)) + "<" + node + ">\n";
        if (node.match(/^<?\w[^>]*[^\/]$/) && !node.startsWith("input") && !node.startsWith("img") && !node.startsWith("br") && !node.startsWith("hr")) current_indent += 1;
      });
      return formatted.substring(1, formatted.length - 2);
    }
    function formatCSS(css) {
      let formatted = "";
      let indent_str = " ".repeat(indent);
      let current_indent = 0;
      css.replace(/\s*([\{\};])\s*/g, "$1").replace(/\{/g, " {\n").replace(/\}/g, "\n}\n").replace(/;/g, ";\n").split("\n").forEach((line) => {
        line = line.trim();
        if (line.includes("}")) current_indent -= 1;
        if (line) formatted += indent_str.repeat(Math.max(0, current_indent)) + line + "\n";
        if (line.includes("{")) current_indent += 1;
      });
      return formatted.trim();
    }
    function formatSQL(sql) {
      const keywords = [
        "SELECT",
        "FROM",
        "WHERE",
        "AND",
        "OR",
        "GROUP BY",
        "ORDER BY",
        "LIMIT",
        "INSERT INTO",
        "VALUES",
        "UPDATE",
        "SET",
        "DELETE",
        "LEFT JOIN",
        "RIGHT JOIN",
        "INNER JOIN",
        "ON"
      ];
      let formatted = sql.toUpperCase();
      keywords.forEach((kw) => {
        const regex = new RegExp(`\\s${kw}\\s`, "g");
        formatted = formatted.replace(regex, `
${kw} `);
      });
      return formatted.trim();
    }
    function handleCopy() {
      navigator.clipboard.writeText(input);
      copied = true;
      setTimeout(() => copied = false, 2e3);
    }
    head("g1vo6j", $$renderer2, ($$renderer3) => {
      $$renderer3.title(($$renderer4) => {
        $$renderer4.push(`<title>Code Formatter - Aone Toolkit</title>`);
      });
    });
    $$renderer2.push(`<div class="h-[calc(100vh-3rem)] p-4 flex flex-col space-y-4">`);
    {
      let header = function($$renderer3) {
        $$renderer3.push(`<div class="flex items-center justify-between w-full"><div class="flex items-center gap-4"><div class="flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 flex items-center justify-center">`);
        Maximize_2($$renderer3, { size: 16 });
        $$renderer3.push(`<!----></div> <h2 class="font-semibold text-slate-900 dark:text-white">Code Formatter</h2></div> <div class="flex p-1 bg-slate-100 dark:bg-slate-800 rounded-lg"><!--[-->`);
        const each_array = ensure_array_like(LANGUAGES);
        for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
          let lang = each_array[$$index];
          $$renderer3.push(`<button${attr_class(`px-3 py-1 text-xs font-medium rounded-md transition-all ${stringify(language === lang.id ? "bg-white dark:bg-slate-700 shadow-sm text-blue-600" : "text-slate-500 hover:text-slate-700 dark:hover:text-slate-300")}`)}>${escape_html(lang.label)}</button>`);
        }
        $$renderer3.push(`<!--]--></div></div> <div class="flex items-center gap-2">`);
        $$renderer3.select(
          {
            value: indent,
            class: "text-xs p-1 bg-slate-100 dark:bg-slate-800 border-none rounded focus:ring-1 focus:ring-blue-500"
          },
          ($$renderer4) => {
            $$renderer4.option({ value: 2 }, ($$renderer5) => {
              $$renderer5.push(`2 Spaces`);
            });
            $$renderer4.option({ value: 4 }, ($$renderer5) => {
              $$renderer5.push(`4 Spaces`);
            });
            $$renderer4.option({ value: 8 }, ($$renderer5) => {
              $$renderer5.push(`8 Spaces`);
            });
          }
        );
        $$renderer3.push(` <div class="h-6 w-px bg-slate-200 dark:bg-slate-700 mx-1"></div> `);
        Button($$renderer3, {
          variant: "ghost",
          size: "sm",
          onclick: handleCopy,
          children: ($$renderer4) => {
            if (copied) {
              $$renderer4.push("<!--[-->");
              Check($$renderer4, { size: 14, class: "text-emerald-500 mr-1" });
              $$renderer4.push(`<!----> Copied`);
            } else {
              $$renderer4.push("<!--[!-->");
              Copy($$renderer4, { size: 14, class: "mr-1" });
              $$renderer4.push(`<!----> Copy`);
            }
            $$renderer4.push(`<!--]-->`);
          },
          $$slots: { default: true }
        });
        $$renderer3.push(`<!----> `);
        Button($$renderer3, {
          variant: "ghost",
          size: "sm",
          onclick: () => input = "",
          children: ($$renderer4) => {
            Trash_2($$renderer4, { size: 14, class: "mr-1" });
            $$renderer4.push(`<!----> Clear`);
          },
          $$slots: { default: true }
        });
        $$renderer3.push(`<!----></div></div>`);
      };
      Panel($$renderer2, {
        class: "flex-1 flex flex-col min-h-0 overflow-hidden",
        header,
        children: ($$renderer3) => {
          $$renderer3.push(`<div class="flex-1 flex flex-col min-h-0 relative"><textarea class="flex-1 p-6 font-mono text-sm bg-transparent resize-none focus:outline-none dark:text-slate-300 leading-relaxed"${attr("placeholder", `Paste your ${stringify(language.toUpperCase())} code here...`)}>`);
          const $$body = escape_html(input);
          if ($$body) {
            $$renderer3.push(`${$$body}`);
          }
          $$renderer3.push(`</textarea> `);
          if (error) {
            $$renderer3.push("<!--[-->");
            $$renderer3.push(`<div class="absolute bottom-4 left-4 right-4 p-3 bg-red-50 dark:bg-red-900/30 border border-red-100 dark:border-red-900/20 rounded-lg text-red-600 dark:text-red-400 text-sm animate-in fade-in slide-in-from-bottom-2">${escape_html(error)}</div>`);
          } else {
            $$renderer3.push("<!--[!-->");
          }
          $$renderer3.push(`<!--]--></div> <div class="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-black/20 flex gap-2 justify-end">`);
          Button($$renderer3, {
            variant: "secondary",
            onclick: minify,
            children: ($$renderer4) => {
              Minimize_2($$renderer4, { size: 16, class: "mr-2" });
              $$renderer4.push(`<!----> Minify`);
            },
            $$slots: { default: true }
          });
          $$renderer3.push(`<!----> `);
          Button($$renderer3, {
            onclick: format,
            children: ($$renderer4) => {
              Maximize_2($$renderer4, { size: 16, class: "mr-2" });
              $$renderer4.push(`<!----> Format / Beautify`);
            },
            $$slots: { default: true }
          });
          $$renderer3.push(`<!----></div>`);
        }
      });
    }
    $$renderer2.push(`<!----></div>`);
  });
}
export {
  _page as default
};
