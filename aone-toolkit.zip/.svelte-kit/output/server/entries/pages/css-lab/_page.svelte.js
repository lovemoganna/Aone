import { a7 as head, a9 as attr_style, a3 as attr, a0 as attr_class, a1 as stringify } from "../../../chunks/index2.js";
import { B as Button } from "../../../chunks/Button.js";
import { P as Panel } from "../../../chunks/Panel.js";
import { S as Sparkles } from "../../../chunks/sparkles.js";
import { B as Box, P as Palette } from "../../../chunks/palette.js";
import { C as Copy } from "../../../chunks/copy.js";
import { e as escape_html } from "../../../chunks/context.js";
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let x = 0;
    let y = 10;
    let blur = 25;
    let spread = -5;
    let shadowColor = "rgba(0,0,0,0.1)";
    let shadowOpacity = 0.1;
    let blurAmt = 10;
    let transparency = 0.5;
    let glassColor = "#ffffff";
    let shadowStyle = `box-shadow: ${x}px ${y}px ${blur}px ${spread}px ${shadowColor.replace("0.1", shadowOpacity.toString())};`;
    `background: ${glassColor}${Math.floor(transparency * 255).toString(16).padStart(2, "0")};
backdrop-filter: blur(${blurAmt}px);
-webkit-backdrop-filter: blur(${blurAmt}px);
border: 1px solid rgba(255, 255, 255, 0.3);`;
    function copyStyle() {
      const text = shadowStyle;
      navigator.clipboard.writeText(text);
    }
    head("crch2u", $$renderer2, ($$renderer3) => {
      $$renderer3.title(($$renderer4) => {
        $$renderer4.push(`<title>CSS Design Lab - Aone Toolkit</title>`);
      });
    });
    $$renderer2.push(`<div class="h-[calc(100vh-3rem)] p-4 flex flex-col space-y-4"><div class="flex-1 grid grid-cols-1 lg:grid-cols-2 gap-4 min-h-0">`);
    {
      let header = function($$renderer3) {
        $$renderer3.push(`<div class="flex items-center justify-between w-full"><div class="flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400 flex items-center justify-center">`);
        Box($$renderer3, { size: 16 });
        $$renderer3.push(`<!----></div> <h2 class="font-semibold text-slate-900 dark:text-white">Live Preview</h2></div> <div class="flex p-1 bg-slate-100 dark:bg-slate-800 rounded-lg"><button${attr_class(`px-3 py-1 text-xs font-medium rounded-md ${stringify("bg-white shadow text-primary-600")}`)}>Shadow</button> <button${attr_class(`px-3 py-1 text-xs font-medium rounded-md ${stringify("text-slate-500")}`)}>Glass</button></div></div>`);
      };
      Panel($$renderer2, {
        class: "flex flex-col min-h-0 overflow-hidden bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] dark:bg-[radial-gradient(#1f2937_1px,transparent_1px)] [background-size:20px_20px]",
        header,
        children: ($$renderer3) => {
          $$renderer3.push(`<div class="flex-1 flex items-center justify-center p-12"><div class="w-64 h-64 rounded-3xl bg-white dark:bg-slate-800 transition-all duration-300 flex items-center justify-center text-center p-8"${attr_style(shadowStyle)}><div>`);
          Sparkles($$renderer3, { class: "mx-auto mb-4 text-primary-500", size: 32 });
          $$renderer3.push(`<!----> <p class="font-bold text-slate-800 dark:text-white">Design Token</p> <p class="text-xs text-slate-500 mt-2">Preview your visual constraints in real-time.</p></div></div></div>`);
        }
      });
    }
    $$renderer2.push(`<!----> `);
    {
      let header = function($$renderer3) {
        $$renderer3.push(`<div class="flex items-center justify-between w-full"><div class="flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-pink-100 dark:bg-pink-900/30 text-pink-600 dark:text-pink-400 flex items-center justify-center">`);
        Palette($$renderer3, { size: 16 });
        $$renderer3.push(`<!----></div> <h2 class="font-semibold text-slate-900 dark:text-white">Style Parameters</h2></div> `);
        Button($$renderer3, {
          size: "sm",
          onclick: copyStyle,
          children: ($$renderer4) => {
            Copy($$renderer4, { size: 14, class: "mr-2" });
            $$renderer4.push(`<!----> Copy CSS`);
          },
          $$slots: { default: true }
        });
        $$renderer3.push(`<!----></div>`);
      };
      Panel($$renderer2, {
        class: "flex flex-col min-h-0",
        header,
        children: ($$renderer3) => {
          $$renderer3.push(`<div class="flex-1 overflow-y-auto p-6 space-y-8">`);
          {
            $$renderer3.push("<!--[-->");
            $$renderer3.push(`<div class="space-y-6"><div class="space-y-4"><div class="flex justify-between text-xs font-bold text-slate-400 uppercase"><span>Offset X &amp; Y</span> <span>${escape_html(x)}px / ${escape_html(y)}px</span></div> <input type="range" min="-50" max="50"${attr("value", x)} class="w-full"/> <input type="range" min="-50" max="50"${attr("value", y)} class="w-full"/></div> <div class="space-y-4"><div class="flex justify-between text-xs font-bold text-slate-400 uppercase"><span>Blur &amp; Spread</span> <span>${escape_html(blur)}px / ${escape_html(spread)}px</span></div> <input type="range" min="0" max="100"${attr("value", blur)} class="w-full"/> <input type="range" min="-50" max="50"${attr("value", spread)} class="w-full"/></div> <div class="space-y-4"><div class="flex justify-between text-xs font-bold text-slate-400 uppercase"><span>Shadow Opacity</span> <span>${escape_html((shadowOpacity * 100).toFixed(0))}%</span></div> <input type="range" min="0" max="1" step="0.01"${attr("value", shadowOpacity)} class="w-full"/></div></div>`);
          }
          $$renderer3.push(`<!--]--> <section class="pt-6 border-t border-slate-100 dark:border-slate-800"><div class="text-xs font-bold text-slate-400 uppercase mb-3">Generated Code</div> <pre class="p-4 bg-slate-900 text-slate-300 rounded-2xl text-[10px] font-mono leading-relaxed"><code>${escape_html(shadowStyle)}</code></pre></section></div>`);
        }
      });
    }
    $$renderer2.push(`<!----></div></div>`);
  });
}
export {
  _page as default
};
