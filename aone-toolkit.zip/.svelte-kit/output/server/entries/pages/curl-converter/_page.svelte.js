import { a7 as head, a4 as ensure_array_like, a0 as attr_class, a1 as stringify } from "../../../chunks/index2.js";
import { B as Button } from "../../../chunks/Button.js";
import { P as Panel } from "../../../chunks/Panel.js";
import { C as Copy } from "../../../chunks/copy.js";
import { T as Terminal } from "../../../chunks/terminal.js";
import { e as escape_html } from "../../../chunks/context.js";
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let curlInput = "";
    let targetLang = "fetch";
    function parseCurl(curl) {
      const result = { method: "GET", url: "", headers: {}, body: "" };
      const urlMatch = curl.match(/'(https?:\/\/[^']+)'|"(https?:\/\/[^"]+)"/);
      if (urlMatch) result.url = urlMatch[1] || urlMatch[2];
      const methodMatch = curl.match(/-X\s+(\w+)|--request\s+(\w+)/);
      if (methodMatch) result.method = methodMatch[1] || methodMatch[2];
      const headerMatches = curl.matchAll(/-H\s+['"]([^'"]+)['"]/g);
      for (const match of headerMatches) {
        const [key, ...val] = match[1].split(":");
        result.headers[key.trim()] = val.join(":").trim();
      }
      const bodyMatch = curl.match(/-d\s+['"]([^'"]+)['"]|--data\s+['"]([^'"]+)['"]/);
      if (bodyMatch) {
        result.body = bodyMatch[1] || bodyMatch[2];
        if (result.method === "GET") result.method = "POST";
      }
      return result;
    }
    let parsed = parseCurl(curlInput);
    let generatedCode = (() => {
      if (!parsed.url) return "// Paste a valid curl command to generate code";
      switch (targetLang) {
        case "fetch":
          return `fetch("${parsed.url}", {
  method: "${parsed.method}",
  headers: ${JSON.stringify(parsed.headers, null, 2)},
  ${parsed.body ? `body: JSON.stringify(${parsed.body})` : ""}
}).then(res => res.json());`;
        case "axios":
          return `axios({
  method: "${parsed.method}",
  url: "${parsed.url}",
  headers: ${JSON.stringify(parsed.headers, null, 2)},
  ${parsed.body ? `data: ${parsed.body}` : ""}
});`;
        case "python":
          return `import requests

headers = ${JSON.stringify(parsed.headers, null, 4)}
${parsed.body ? `data = ${parsed.body}
` : ""}response = requests.${parsed.method.toLowerCase()}("${parsed.url}", headers=headers${parsed.body ? ", data=data" : ""})`;
        case "go":
          return `req, _ := http.NewRequest("${parsed.method}", "${parsed.url}", ${parsed.body ? `strings.NewReader(\`${parsed.body}\`)` : "nil"})
${Object.entries(parsed.headers).map(([k, v]) => `req.Header.Set("${k}", "${v}")`).join("\n")}
client := &http.Client{}
resp, _ := client.Do(req)`;
        default:
          return "";
      }
    })();
    function copyCode() {
      navigator.clipboard.writeText(generatedCode);
    }
    head("r4dh4s", $$renderer2, ($$renderer3) => {
      $$renderer3.title(($$renderer4) => {
        $$renderer4.push(`<title>Curl Converter - Aone Toolkit</title>`);
      });
    });
    $$renderer2.push(`<div class="h-[calc(100vh-3rem)] p-4 flex flex-col space-y-4">`);
    {
      let header = function($$renderer3) {
        $$renderer3.push(`<div class="flex items-center justify-between w-full"><div class="flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 flex items-center justify-center border">`);
        Terminal($$renderer3, { size: 16 });
        $$renderer3.push(`<!----></div> <h2 class="font-semibold text-slate-900 dark:text-white">Curl to Code</h2></div> <div class="flex p-1 bg-slate-100 dark:bg-slate-800 rounded-lg"><!--[-->`);
        const each_array = ensure_array_like(["fetch", "axios", "python", "go"]);
        for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
          let lang = each_array[$$index];
          $$renderer3.push(`<button${attr_class(`px-3 py-1 text-xs font-medium rounded-md transition-all ${stringify(targetLang === lang ? "bg-white shadow text-primary-600" : "text-slate-500")}`)}>${escape_html(lang)}</button>`);
        }
        $$renderer3.push(`<!--]--></div></div>`);
      };
      Panel($$renderer2, {
        class: "flex-1 flex flex-col min-h-0",
        header,
        children: ($$renderer3) => {
          $$renderer3.push(`<div class="flex-1 grid grid-cols-1 md:grid-cols-2 divide-x divide-slate-100 dark:divide-slate-800"><div class="flex flex-col p-6 space-y-4"><div class="text-xs font-bold text-slate-400 uppercase tracking-wider">Input Curl</div> <textarea class="flex-1 p-4 font-mono text-xs bg-slate-50 dark:bg-black/20 border-none rounded-2xl resize-none focus:outline-none dark:text-slate-300" placeholder="curl 'https://api.example.com/v1/user' -H 'Authorization: Bearer ...'">`);
          const $$body = escape_html(curlInput);
          if ($$body) {
            $$renderer3.push(`${$$body}`);
          }
          $$renderer3.push(`</textarea></div> <div class="flex flex-col p-6 space-y-4 bg-slate-50/30 dark:bg-black/10"><div class="flex justify-between items-center"><div class="text-xs font-bold text-slate-400 uppercase tracking-wider">Generated ${escape_html(targetLang.toUpperCase())}</div> `);
          Button($$renderer3, {
            variant: "ghost",
            size: "sm",
            onclick: copyCode,
            children: ($$renderer4) => {
              Copy($$renderer4, { size: 14, class: "mr-2" });
              $$renderer4.push(`<!----> Copy`);
            },
            $$slots: { default: true }
          });
          $$renderer3.push(`<!----></div> <pre class="flex-1 p-4 bg-slate-900 text-emerald-400 rounded-2xl border border-slate-800 overflow-auto font-mono text-xs leading-relaxed group relative"><code>${escape_html(generatedCode)}</code></pre></div></div>`);
        }
      });
    }
    $$renderer2.push(`<!----></div>`);
  });
}
export {
  _page as default
};
