import { Z as sanitize_props, _ as spread_props, $ as slot, a4 as ensure_array_like, a0 as attr_class, a1 as stringify, a6 as bind_props, aa as derived, a3 as attr, a9 as attr_style, a7 as head } from "../../../chunks/index2.js";
import plantumlEncoder from "plantuml-encoder";
import { instance } from "@viz-js/viz";
import "lz-string";
import { C as Code } from "../../../chunks/code.js";
import { P as Play } from "../../../chunks/play.js";
import { D as Download } from "../../../chunks/download.js";
import { S as Search } from "../../../chunks/search.js";
import { I as Icon } from "../../../chunks/Icon.js";
import { T as Table } from "../../../chunks/table.js";
import { I as Image } from "../../../chunks/image.js";
import { S as Sun, C as Chevron_left } from "../../../chunks/sun.js";
import { M as Moon, U as Upload, T as Triangle_alert } from "../../../chunks/upload.js";
import { e as escape_html } from "../../../chunks/context.js";
import { F as File_text, X } from "../../../chunks/x.js";
import { P as Plus } from "../../../chunks/plus.js";
import { o as onDestroy } from "../../../chunks/index-server.js";
import { Compartment } from "@codemirror/state";
import "@lezer/highlight";
import { snippetCompletion } from "@codemirror/autocomplete";
import { StreamLanguage } from "@codemirror/language";
import { P as Palette, B as Box } from "../../../chunks/palette.js";
import { I as Info } from "../../../chunks/info.js";
import { L as Link } from "../../../chunks/link.js";
import { h as html } from "../../../chunks/html.js";
import { C as Copy } from "../../../chunks/copy.js";
import { E as Eye, a as Eye_off } from "../../../chunks/eye.js";
import { L as Loader_circle } from "../../../chunks/loader-circle.js";
import "clsx";
import { S as Sparkles } from "../../../chunks/sparkles.js";
import { T as Trash_2 } from "../../../chunks/trash-2.js";
import { C as Chevron_right } from "../../../chunks/chevron-right.js";
import { C as Clock } from "../../../chunks/clock.js";
function Arrow_down($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    ["path", { "d": "M12 5v14" }],
    ["path", { "d": "m19 12-7 7-7-7" }]
  ];
  Icon($$renderer, spread_props([
    { name: "arrow-down" },
    $$sanitized_props,
    {
      /**
       * @component @name ArrowDown
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTIgNXYxNCIgLz4KICA8cGF0aCBkPSJtMTkgMTItNyA3LTctNyIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/arrow-down
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Arrow_left($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    ["path", { "d": "m12 19-7-7 7-7" }],
    ["path", { "d": "M19 12H5" }]
  ];
  Icon($$renderer, spread_props([
    { name: "arrow-left" },
    $$sanitized_props,
    {
      /**
       * @component @name ArrowLeft
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJtMTIgMTktNy03IDctNyIgLz4KICA8cGF0aCBkPSJNMTkgMTJINSIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/arrow-left
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Arrow_right($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    ["path", { "d": "M5 12h14" }],
    ["path", { "d": "m12 5 7 7-7 7" }]
  ];
  Icon($$renderer, spread_props([
    { name: "arrow-right" },
    $$sanitized_props,
    {
      /**
       * @component @name ArrowRight
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNNSAxMmgxNCIgLz4KICA8cGF0aCBkPSJtMTIgNSA3IDctNyA3IiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/arrow-right
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Arrow_up($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    ["path", { "d": "m5 12 7-7 7 7" }],
    ["path", { "d": "M12 19V5" }]
  ];
  Icon($$renderer, spread_props([
    { name: "arrow-up" },
    $$sanitized_props,
    {
      /**
       * @component @name ArrowUp
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJtNSAxMiA3LTcgNyA3IiAvPgogIDxwYXRoIGQ9Ik0xMiAxOVY1IiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/arrow-up
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Book($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "path",
      {
        "d": "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20"
      }
    ]
  ];
  Icon($$renderer, spread_props([
    { name: "book" },
    $$sanitized_props,
    {
      /**
       * @component @name Book
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNNCAxOS41di0xNUEyLjUgMi41IDAgMCAxIDYuNSAySDE5YTEgMSAwIDAgMSAxIDF2MThhMSAxIDAgMCAxLTEgMUg2LjVhMSAxIDAgMCAxIDAtNUgyMCIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/book
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Circle_alert($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    ["circle", { "cx": "12", "cy": "12", "r": "10" }],
    ["line", { "x1": "12", "x2": "12", "y1": "8", "y2": "12" }],
    [
      "line",
      { "x1": "12", "x2": "12.01", "y1": "16", "y2": "16" }
    ]
  ];
  Icon($$renderer, spread_props([
    { name: "circle-alert" },
    $$sanitized_props,
    {
      /**
       * @component @name CircleAlert
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8Y2lyY2xlIGN4PSIxMiIgY3k9IjEyIiByPSIxMCIgLz4KICA8bGluZSB4MT0iMTIiIHgyPSIxMiIgeTE9IjgiIHkyPSIxMiIgLz4KICA8bGluZSB4MT0iMTIiIHgyPSIxMi4wMSIgeTE9IjE2IiB5Mj0iMTYiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/circle-alert
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Circle_check_big($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    ["path", { "d": "M21.801 10A10 10 0 1 1 17 3.335" }],
    ["path", { "d": "m9 11 3 3L22 4" }]
  ];
  Icon($$renderer, spread_props([
    { name: "circle-check-big" },
    $$sanitized_props,
    {
      /**
       * @component @name CircleCheckBig
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMjEuODAxIDEwQTEwIDEwIDAgMSAxIDE3IDMuMzM1IiAvPgogIDxwYXRoIGQ9Im05IDExIDMgM0wyMiA0IiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/circle-check-big
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Circle_check($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    ["circle", { "cx": "12", "cy": "12", "r": "10" }],
    ["path", { "d": "m9 12 2 2 4-4" }]
  ];
  Icon($$renderer, spread_props([
    { name: "circle-check" },
    $$sanitized_props,
    {
      /**
       * @component @name CircleCheck
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8Y2lyY2xlIGN4PSIxMiIgY3k9IjEyIiByPSIxMCIgLz4KICA8cGF0aCBkPSJtOSAxMiAyIDIgNC00IiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/circle-check
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function File_code($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "path",
      {
        "d": "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z"
      }
    ],
    ["path", { "d": "M14 2v5a1 1 0 0 0 1 1h5" }],
    ["path", { "d": "M10 12.5 8 15l2 2.5" }],
    ["path", { "d": "m14 12.5 2 2.5-2 2.5" }]
  ];
  Icon($$renderer, spread_props([
    { name: "file-code" },
    $$sanitized_props,
    {
      /**
       * @component @name FileCode
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNNiAyMmEyIDIgMCAwIDEtMi0yVjRhMiAyIDAgMCAxIDItMmg4YTIuNCAyLjQgMCAwIDEgMS43MDQuNzA2bDMuNTg4IDMuNTg4QTIuNCAyLjQgMCAwIDEgMjAgOHYxMmEyIDIgMCAwIDEtMiAyeiIgLz4KICA8cGF0aCBkPSJNMTQgMnY1YTEgMSAwIDAgMCAxIDFoNSIgLz4KICA8cGF0aCBkPSJNMTAgMTIuNSA4IDE1bDIgMi41IiAvPgogIDxwYXRoIGQ9Im0xNCAxMi41IDIgMi41LTIgMi41IiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/file-code
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function File_image($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "path",
      {
        "d": "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z"
      }
    ],
    ["path", { "d": "M14 2v5a1 1 0 0 0 1 1h5" }],
    ["circle", { "cx": "10", "cy": "12", "r": "2" }],
    [
      "path",
      { "d": "m20 17-1.296-1.296a2.41 2.41 0 0 0-3.408 0L9 22" }
    ]
  ];
  Icon($$renderer, spread_props([
    { name: "file-image" },
    $$sanitized_props,
    {
      /**
       * @component @name FileImage
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNNiAyMmEyIDIgMCAwIDEtMi0yVjRhMiAyIDAgMCAxIDItMmg4YTIuNCAyLjQgMCAwIDEgMS43MDQuNzA2bDMuNTg4IDMuNTg4QTIuNCAyLjQgMCAwIDEgMjAgOHYxMmEyIDIgMCAwIDEtMiAyeiIgLz4KICA8cGF0aCBkPSJNMTQgMnY1YTEgMSAwIDAgMCAxIDFoNSIgLz4KICA8Y2lyY2xlIGN4PSIxMCIgY3k9IjEyIiByPSIyIiAvPgogIDxwYXRoIGQ9Im0yMCAxNy0xLjI5Ni0xLjI5NmEyLjQxIDIuNDEgMCAwIDAtMy40MDggMEw5IDIyIiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/file-image
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function File_type($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "path",
      {
        "d": "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z"
      }
    ],
    ["path", { "d": "M14 2v5a1 1 0 0 0 1 1h5" }],
    ["path", { "d": "M11 18h2" }],
    ["path", { "d": "M12 12v6" }],
    [
      "path",
      { "d": "M9 13v-.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 .5.5v.5" }
    ]
  ];
  Icon($$renderer, spread_props([
    { name: "file-type" },
    $$sanitized_props,
    {
      /**
       * @component @name FileType
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNNiAyMmEyIDIgMCAwIDEtMi0yVjRhMiAyIDAgMCAxIDItMmg4YTIuNCAyLjQgMCAwIDEgMS43MDQuNzA2bDMuNTg4IDMuNTg4QTIuNCAyLjQgMCAwIDEgMjAgOHYxMmEyIDIgMCAwIDEtMiAyeiIgLz4KICA8cGF0aCBkPSJNMTQgMnY1YTEgMSAwIDAgMCAxIDFoNSIgLz4KICA8cGF0aCBkPSJNMTEgMThoMiIgLz4KICA8cGF0aCBkPSJNMTIgMTJ2NiIgLz4KICA8cGF0aCBkPSJNOSAxM3YtLjVhLjUuNSAwIDAgMSAuNS0uNWg1YS41LjUgMCAwIDEgLjUuNXYuNSIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/file-type
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Git_compare($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    ["circle", { "cx": "18", "cy": "18", "r": "3" }],
    ["circle", { "cx": "6", "cy": "6", "r": "3" }],
    ["path", { "d": "M13 6h3a2 2 0 0 1 2 2v7" }],
    ["path", { "d": "M11 18H8a2 2 0 0 1-2-2V9" }]
  ];
  Icon($$renderer, spread_props([
    { name: "git-compare" },
    $$sanitized_props,
    {
      /**
       * @component @name GitCompare
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8Y2lyY2xlIGN4PSIxOCIgY3k9IjE4IiByPSIzIiAvPgogIDxjaXJjbGUgY3g9IjYiIGN5PSI2IiByPSIzIiAvPgogIDxwYXRoIGQ9Ik0xMyA2aDNhMiAyIDAgMCAxIDIgMnY3IiAvPgogIDxwYXRoIGQ9Ik0xMSAxOEg4YTIgMiAwIDAgMS0yLTJWOSIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/git-compare
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Grid_3x3($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "rect",
      { "width": "18", "height": "18", "x": "3", "y": "3", "rx": "2" }
    ],
    ["path", { "d": "M3 9h18" }],
    ["path", { "d": "M3 15h18" }],
    ["path", { "d": "M9 3v18" }],
    ["path", { "d": "M15 3v18" }]
  ];
  Icon($$renderer, spread_props([
    { name: "grid-3x3" },
    $$sanitized_props,
    {
      /**
       * @component @name Grid3x3
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cmVjdCB3aWR0aD0iMTgiIGhlaWdodD0iMTgiIHg9IjMiIHk9IjMiIHJ4PSIyIiAvPgogIDxwYXRoIGQ9Ik0zIDloMTgiIC8+CiAgPHBhdGggZD0iTTMgMTVoMTgiIC8+CiAgPHBhdGggZD0iTTkgM3YxOCIgLz4KICA8cGF0aCBkPSJNMTUgM3YxOCIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/grid-3x3
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Grip_vertical($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    ["circle", { "cx": "9", "cy": "12", "r": "1" }],
    ["circle", { "cx": "9", "cy": "5", "r": "1" }],
    ["circle", { "cx": "9", "cy": "19", "r": "1" }],
    ["circle", { "cx": "15", "cy": "12", "r": "1" }],
    ["circle", { "cx": "15", "cy": "5", "r": "1" }],
    ["circle", { "cx": "15", "cy": "19", "r": "1" }]
  ];
  Icon($$renderer, spread_props([
    { name: "grip-vertical" },
    $$sanitized_props,
    {
      /**
       * @component @name GripVertical
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8Y2lyY2xlIGN4PSI5IiBjeT0iMTIiIHI9IjEiIC8+CiAgPGNpcmNsZSBjeD0iOSIgY3k9IjUiIHI9IjEiIC8+CiAgPGNpcmNsZSBjeD0iOSIgY3k9IjE5IiByPSIxIiAvPgogIDxjaXJjbGUgY3g9IjE1IiBjeT0iMTIiIHI9IjEiIC8+CiAgPGNpcmNsZSBjeD0iMTUiIGN5PSI1IiByPSIxIiAvPgogIDxjaXJjbGUgY3g9IjE1IiBjeT0iMTkiIHI9IjEiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/grip-vertical
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function History($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "path",
      { "d": "M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" }
    ],
    ["path", { "d": "M3 3v5h5" }],
    ["path", { "d": "M12 7v5l4 2" }]
  ];
  Icon($$renderer, spread_props([
    { name: "history" },
    $$sanitized_props,
    {
      /**
       * @component @name History
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMyAxMmE5IDkgMCAxIDAgOS05IDkuNzUgOS43NSAwIDAgMC02Ljc0IDIuNzRMMyA4IiAvPgogIDxwYXRoIGQ9Ik0zIDN2NWg1IiAvPgogIDxwYXRoIGQ9Ik0xMiA3djVsNCAyIiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/history
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Keyboard($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    ["path", { "d": "M10 8h.01" }],
    ["path", { "d": "M12 12h.01" }],
    ["path", { "d": "M14 8h.01" }],
    ["path", { "d": "M16 12h.01" }],
    ["path", { "d": "M18 8h.01" }],
    ["path", { "d": "M6 8h.01" }],
    ["path", { "d": "M7 16h10" }],
    ["path", { "d": "M8 12h.01" }],
    [
      "rect",
      { "width": "20", "height": "16", "x": "2", "y": "4", "rx": "2" }
    ]
  ];
  Icon($$renderer, spread_props([
    { name: "keyboard" },
    $$sanitized_props,
    {
      /**
       * @component @name Keyboard
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTAgOGguMDEiIC8+CiAgPHBhdGggZD0iTTEyIDEyaC4wMSIgLz4KICA8cGF0aCBkPSJNMTQgOGguMDEiIC8+CiAgPHBhdGggZD0iTTE2IDEyaC4wMSIgLz4KICA8cGF0aCBkPSJNMTggOGguMDEiIC8+CiAgPHBhdGggZD0iTTYgOGguMDEiIC8+CiAgPHBhdGggZD0iTTcgMTZoMTAiIC8+CiAgPHBhdGggZD0iTTggMTJoLjAxIiAvPgogIDxyZWN0IHdpZHRoPSIyMCIgaGVpZ2h0PSIxNiIgeD0iMiIgeT0iNCIgcng9IjIiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/keyboard
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Layers($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "path",
      {
        "d": "M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z"
      }
    ],
    [
      "path",
      {
        "d": "M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12"
      }
    ],
    [
      "path",
      {
        "d": "M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17"
      }
    ]
  ];
  Icon($$renderer, spread_props([
    { name: "layers" },
    $$sanitized_props,
    {
      /**
       * @component @name Layers
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTIuODMgMi4xOGEyIDIgMCAwIDAtMS42NiAwTDIuNiA2LjA4YTEgMSAwIDAgMCAwIDEuODNsOC41OCAzLjkxYTIgMiAwIDAgMCAxLjY2IDBsOC41OC0zLjlhMSAxIDAgMCAwIDAtMS44M3oiIC8+CiAgPHBhdGggZD0iTTIgMTJhMSAxIDAgMCAwIC41OC45MWw4LjYgMy45MWEyIDIgMCAwIDAgMS42NSAwbDguNTgtMy45QTEgMSAwIDAgMCAyMiAxMiIgLz4KICA8cGF0aCBkPSJNMiAxN2ExIDEgMCAwIDAgLjU4LjkxbDguNiAzLjkxYTIgMiAwIDAgMCAxLjY1IDBsOC41OC0zLjlBMSAxIDAgMCAwIDIyIDE3IiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/layers
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Layout_template($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "rect",
      { "width": "18", "height": "7", "x": "3", "y": "3", "rx": "1" }
    ],
    [
      "rect",
      { "width": "9", "height": "7", "x": "3", "y": "14", "rx": "1" }
    ],
    [
      "rect",
      { "width": "5", "height": "7", "x": "16", "y": "14", "rx": "1" }
    ]
  ];
  Icon($$renderer, spread_props([
    { name: "layout-template" },
    $$sanitized_props,
    {
      /**
       * @component @name LayoutTemplate
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cmVjdCB3aWR0aD0iMTgiIGhlaWdodD0iNyIgeD0iMyIgeT0iMyIgcng9IjEiIC8+CiAgPHJlY3Qgd2lkdGg9IjkiIGhlaWdodD0iNyIgeD0iMyIgeT0iMTQiIHJ4PSIxIiAvPgogIDxyZWN0IHdpZHRoPSI1IiBoZWlnaHQ9IjciIHg9IjE2IiB5PSIxNCIgcng9IjEiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/layout-template
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function List($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    ["path", { "d": "M3 5h.01" }],
    ["path", { "d": "M3 12h.01" }],
    ["path", { "d": "M3 19h.01" }],
    ["path", { "d": "M8 5h13" }],
    ["path", { "d": "M8 12h13" }],
    ["path", { "d": "M8 19h13" }]
  ];
  Icon($$renderer, spread_props([
    { name: "list" },
    $$sanitized_props,
    {
      /**
       * @component @name List
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMyA1aC4wMSIgLz4KICA8cGF0aCBkPSJNMyAxMmguMDEiIC8+CiAgPHBhdGggZD0iTTMgMTloLjAxIiAvPgogIDxwYXRoIGQ9Ik04IDVoMTMiIC8+CiAgPHBhdGggZD0iTTggMTJoMTMiIC8+CiAgPHBhdGggZD0iTTggMTloMTMiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/list
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Maximize($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    ["path", { "d": "M8 3H5a2 2 0 0 0-2 2v3" }],
    ["path", { "d": "M21 8V5a2 2 0 0 0-2-2h-3" }],
    ["path", { "d": "M3 16v3a2 2 0 0 0 2 2h3" }],
    ["path", { "d": "M16 21h3a2 2 0 0 0 2-2v-3" }]
  ];
  Icon($$renderer, spread_props([
    { name: "maximize" },
    $$sanitized_props,
    {
      /**
       * @component @name Maximize
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNOCAzSDVhMiAyIDAgMCAwLTIgMnYzIiAvPgogIDxwYXRoIGQ9Ik0yMSA4VjVhMiAyIDAgMCAwLTItMmgtMyIgLz4KICA8cGF0aCBkPSJNMyAxNnYzYTIgMiAwIDAgMCAyIDJoMyIgLz4KICA8cGF0aCBkPSJNMTYgMjFoM2EyIDIgMCAwIDAgMi0ydi0zIiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/maximize
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Minimize($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    ["path", { "d": "M8 3v3a2 2 0 0 1-2 2H3" }],
    ["path", { "d": "M21 8h-3a2 2 0 0 1-2-2V3" }],
    ["path", { "d": "M3 16h3a2 2 0 0 1 2 2v3" }],
    ["path", { "d": "M16 21v-3a2 2 0 0 1 2-2h3" }]
  ];
  Icon($$renderer, spread_props([
    { name: "minimize" },
    $$sanitized_props,
    {
      /**
       * @component @name Minimize
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNOCAzdjNhMiAyIDAgMCAxLTIgMkgzIiAvPgogIDxwYXRoIGQ9Ik0yMSA4aC0zYTIgMiAwIDAgMS0yLTJWMyIgLz4KICA8cGF0aCBkPSJNMyAxNmgzYTIgMiAwIDAgMSAyIDJ2MyIgLz4KICA8cGF0aCBkPSJNMTYgMjF2LTNhMiAyIDAgMCAxIDItMmgzIiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/minimize
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Minus($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [["path", { "d": "M5 12h14" }]];
  Icon($$renderer, spread_props([
    { name: "minus" },
    $$sanitized_props,
    {
      /**
       * @component @name Minus
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNNSAxMmgxNCIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/minus
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Monitor($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "rect",
      { "width": "20", "height": "14", "x": "2", "y": "3", "rx": "2" }
    ],
    ["line", { "x1": "8", "x2": "16", "y1": "21", "y2": "21" }],
    ["line", { "x1": "12", "x2": "12", "y1": "17", "y2": "21" }]
  ];
  Icon($$renderer, spread_props([
    { name: "monitor" },
    $$sanitized_props,
    {
      /**
       * @component @name Monitor
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cmVjdCB3aWR0aD0iMjAiIGhlaWdodD0iMTQiIHg9IjIiIHk9IjMiIHJ4PSIyIiAvPgogIDxsaW5lIHgxPSI4IiB4Mj0iMTYiIHkxPSIyMSIgeTI9IjIxIiAvPgogIDxsaW5lIHgxPSIxMiIgeDI9IjEyIiB5MT0iMTciIHkyPSIyMSIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/monitor
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Mouse_pointer_2($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "path",
      {
        "d": "M4.037 4.688a.495.495 0 0 1 .651-.651l16 6.5a.5.5 0 0 1-.063.947l-6.124 1.58a2 2 0 0 0-1.438 1.435l-1.579 6.126a.5.5 0 0 1-.947.063z"
      }
    ]
  ];
  Icon($$renderer, spread_props([
    { name: "mouse-pointer-2" },
    $$sanitized_props,
    {
      /**
       * @component @name MousePointer2
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNNC4wMzcgNC42ODhhLjQ5NS40OTUgMCAwIDEgLjY1MS0uNjUxbDE2IDYuNWEuNS41IDAgMCAxLS4wNjMuOTQ3bC02LjEyNCAxLjU4YTIgMiAwIDAgMC0xLjQzOCAxLjQzNWwtMS41NzkgNi4xMjZhLjUuNSAwIDAgMS0uOTQ3LjA2M3oiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/mouse-pointer-2
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Move($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    ["path", { "d": "M12 2v20" }],
    ["path", { "d": "m15 19-3 3-3-3" }],
    ["path", { "d": "m19 9 3 3-3 3" }],
    ["path", { "d": "M2 12h20" }],
    ["path", { "d": "m5 9-3 3 3 3" }],
    ["path", { "d": "m9 5 3-3 3 3" }]
  ];
  Icon($$renderer, spread_props([
    { name: "move" },
    $$sanitized_props,
    {
      /**
       * @component @name Move
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTIgMnYyMCIgLz4KICA8cGF0aCBkPSJtMTUgMTktMyAzLTMtMyIgLz4KICA8cGF0aCBkPSJtMTkgOSAzIDMtMyAzIiAvPgogIDxwYXRoIGQ9Ik0yIDEyaDIwIiAvPgogIDxwYXRoIGQ9Im01IDktMyAzIDMgMyIgLz4KICA8cGF0aCBkPSJtOSA1IDMtMyAzIDMiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/move
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Rotate_ccw($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "path",
      { "d": "M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" }
    ],
    ["path", { "d": "M3 3v5h5" }]
  ];
  Icon($$renderer, spread_props([
    { name: "rotate-ccw" },
    $$sanitized_props,
    {
      /**
       * @component @name RotateCcw
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMyAxMmE5IDkgMCAxIDAgOS05IDkuNzUgOS43NSAwIDAgMC02Ljc0IDIuNzRMMyA4IiAvPgogIDxwYXRoIGQ9Ik0zIDN2NWg1IiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/rotate-ccw
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Save($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "path",
      {
        "d": "M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z"
      }
    ],
    ["path", { "d": "M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7" }],
    ["path", { "d": "M7 3v4a1 1 0 0 0 1 1h7" }]
  ];
  Icon($$renderer, spread_props([
    { name: "save" },
    $$sanitized_props,
    {
      /**
       * @component @name Save
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTUuMiAzYTIgMiAwIDAgMSAxLjQuNmwzLjggMy44YTIgMiAwIDAgMSAuNiAxLjRWMTlhMiAyIDAgMCAxLTIgMkg1YTIgMiAwIDAgMS0yLTJWNWEyIDIgMCAwIDEgMi0yeiIgLz4KICA8cGF0aCBkPSJNMTcgMjF2LTdhMSAxIDAgMCAwLTEtMUg4YTEgMSAwIDAgMC0xIDF2NyIgLz4KICA8cGF0aCBkPSJNNyAzdjRhMSAxIDAgMCAwIDEgMWg3IiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/save
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Settings_2($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    ["path", { "d": "M14 17H5" }],
    ["path", { "d": "M19 7h-9" }],
    ["circle", { "cx": "17", "cy": "17", "r": "3" }],
    ["circle", { "cx": "7", "cy": "7", "r": "3" }]
  ];
  Icon($$renderer, spread_props([
    { name: "settings-2" },
    $$sanitized_props,
    {
      /**
       * @component @name Settings2
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTQgMTdINSIgLz4KICA8cGF0aCBkPSJNMTkgN2gtOSIgLz4KICA8Y2lyY2xlIGN4PSIxNyIgY3k9IjE3IiByPSIzIiAvPgogIDxjaXJjbGUgY3g9IjciIGN5PSI3IiByPSIzIiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/settings-2
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Share_2($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    ["circle", { "cx": "18", "cy": "5", "r": "3" }],
    ["circle", { "cx": "6", "cy": "12", "r": "3" }],
    ["circle", { "cx": "18", "cy": "19", "r": "3" }],
    [
      "line",
      { "x1": "8.59", "x2": "15.42", "y1": "13.51", "y2": "17.49" }
    ],
    [
      "line",
      { "x1": "15.41", "x2": "8.59", "y1": "6.51", "y2": "10.49" }
    ]
  ];
  Icon($$renderer, spread_props([
    { name: "share-2" },
    $$sanitized_props,
    {
      /**
       * @component @name Share2
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8Y2lyY2xlIGN4PSIxOCIgY3k9IjUiIHI9IjMiIC8+CiAgPGNpcmNsZSBjeD0iNiIgY3k9IjEyIiByPSIzIiAvPgogIDxjaXJjbGUgY3g9IjE4IiBjeT0iMTkiIHI9IjMiIC8+CiAgPGxpbmUgeDE9IjguNTkiIHgyPSIxNS40MiIgeTE9IjEzLjUxIiB5Mj0iMTcuNDkiIC8+CiAgPGxpbmUgeDE9IjE1LjQxIiB4Mj0iOC41OSIgeTE9IjYuNTEiIHkyPSIxMC40OSIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/share-2
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Target($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    ["circle", { "cx": "12", "cy": "12", "r": "10" }],
    ["circle", { "cx": "12", "cy": "12", "r": "6" }],
    ["circle", { "cx": "12", "cy": "12", "r": "2" }]
  ];
  Icon($$renderer, spread_props([
    { name: "target" },
    $$sanitized_props,
    {
      /**
       * @component @name Target
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8Y2lyY2xlIGN4PSIxMiIgY3k9IjEyIiByPSIxMCIgLz4KICA8Y2lyY2xlIGN4PSIxMiIgY3k9IjEyIiByPSI2IiAvPgogIDxjaXJjbGUgY3g9IjEyIiBjeT0iMTIiIHI9IjIiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/target
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Zap_off($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "path",
      {
        "d": "M10.513 4.856 13.12 2.17a.5.5 0 0 1 .86.46l-1.377 4.317"
      }
    ],
    [
      "path",
      { "d": "M15.656 10H20a1 1 0 0 1 .78 1.63l-1.72 1.773" }
    ],
    [
      "path",
      {
        "d": "M16.273 16.273 10.88 21.83a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14H4a1 1 0 0 1-.78-1.63l4.507-4.643"
      }
    ],
    ["path", { "d": "m2 2 20 20" }]
  ];
  Icon($$renderer, spread_props([
    { name: "zap-off" },
    $$sanitized_props,
    {
      /**
       * @component @name ZapOff
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTAuNTEzIDQuODU2IDEzLjEyIDIuMTdhLjUuNSAwIDAgMSAuODYuNDZsLTEuMzc3IDQuMzE3IiAvPgogIDxwYXRoIGQ9Ik0xNS42NTYgMTBIMjBhMSAxIDAgMCAxIC43OCAxLjYzbC0xLjcyIDEuNzczIiAvPgogIDxwYXRoIGQ9Ik0xNi4yNzMgMTYuMjczIDEwLjg4IDIxLjgzYS41LjUgMCAwIDEtLjg2LS40NmwxLjkyLTYuMDJBMSAxIDAgMCAwIDExIDE0SDRhMSAxIDAgMCAxLS43OC0xLjYzbDQuNTA3LTQuNjQzIiAvPgogIDxwYXRoIGQ9Im0yIDIgMjAgMjAiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/zap-off
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Zap($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "path",
      {
        "d": "M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"
      }
    ]
  ];
  Icon($$renderer, spread_props([
    { name: "zap" },
    $$sanitized_props,
    {
      /**
       * @component @name Zap
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNNCAxNGExIDEgMCAwIDEtLjc4LTEuNjNsOS45LTEwLjJhLjUuNSAwIDAgMSAuODYuNDZsLTEuOTIgNi4wMkExIDEgMCAwIDAgMTMgMTBoN2ExIDEgMCAwIDEgLjc4IDEuNjNsLTkuOSAxMC4yYS41LjUgMCAwIDEtLjg2LS40NmwxLjkyLTYuMDJBMSAxIDAgMCAwIDExIDE0eiIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/zap
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Zoom_in($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    ["circle", { "cx": "11", "cy": "11", "r": "8" }],
    [
      "line",
      { "x1": "21", "x2": "16.65", "y1": "21", "y2": "16.65" }
    ],
    ["line", { "x1": "11", "x2": "11", "y1": "8", "y2": "14" }],
    ["line", { "x1": "8", "x2": "14", "y1": "11", "y2": "11" }]
  ];
  Icon($$renderer, spread_props([
    { name: "zoom-in" },
    $$sanitized_props,
    {
      /**
       * @component @name ZoomIn
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8Y2lyY2xlIGN4PSIxMSIgY3k9IjExIiByPSI4IiAvPgogIDxsaW5lIHgxPSIyMSIgeDI9IjE2LjY1IiB5MT0iMjEiIHkyPSIxNi42NSIgLz4KICA8bGluZSB4MT0iMTEiIHgyPSIxMSIgeTE9IjgiIHkyPSIxNCIgLz4KICA8bGluZSB4MT0iOCIgeDI9IjE0IiB5MT0iMTEiIHkyPSIxMSIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/zoom-in
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Zoom_out($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    ["circle", { "cx": "11", "cy": "11", "r": "8" }],
    [
      "line",
      { "x1": "21", "x2": "16.65", "y1": "21", "y2": "16.65" }
    ],
    ["line", { "x1": "8", "x2": "14", "y1": "11", "y2": "11" }]
  ];
  Icon($$renderer, spread_props([
    { name: "zoom-out" },
    $$sanitized_props,
    {
      /**
       * @component @name ZoomOut
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8Y2lyY2xlIGN4PSIxMSIgY3k9IjExIiByPSI4IiAvPgogIDxsaW5lIHgxPSIyMSIgeDI9IjE2LjY1IiB5MT0iMjEiIHkyPSIxNi42NSIgLz4KICA8bGluZSB4MT0iOCIgeDI9IjE0IiB5MT0iMTEiIHkyPSIxMSIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/zoom-out
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function DiffViewer($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { textA = "", textB = "" } = $$props;
    let diff = (() => {
      const linesA = textA.split("\n");
      const linesB = textB.split("\n");
      const result = [];
      const maxLen = Math.max(linesA.length, linesB.length);
      for (let i = 0; i < maxLen; i++) {
        const a = linesA[i];
        const b = linesB[i];
        if (a === b) {
          if (a !== void 0) {
            result.push({ type: "same", content: a, lineNum: i + 1 });
          }
        } else {
          if (a !== void 0) {
            result.push({ type: "removed", content: a, lineNum: i + 1 });
          }
          if (b !== void 0) {
            result.push({ type: "added", content: b, lineNum: i + 1 });
          }
        }
      }
      return result;
    })();
    let stats = (() => {
      const added = diff.filter((d) => d.type === "added").length;
      const removed = diff.filter((d) => d.type === "removed").length;
      const same = diff.filter((d) => d.type === "same").length;
      return { added, removed, same };
    })();
    $$renderer2.push(`<div class="h-full flex flex-col gap-4"><div class="flex flex-col md:flex-row gap-4 flex-1 min-h-[200px]"><div class="flex-1 flex flex-col gap-2"><label for="diff-a" class="text-sm font-semibold text-slate-700 dark:text-slate-300">Original</label> <textarea id="diff-a" class="flex-1 p-4 font-mono text-sm bg-red-50/50 dark:bg-red-950/20 border border-red-200 dark:border-red-900/50 rounded-lg outline-none resize-none focus:ring-2 focus:ring-red-500/20 transition-all placeholder:text-slate-400" placeholder="Paste original text here...">`);
    const $$body = escape_html(textA);
    if ($$body) {
      $$renderer2.push(`${$$body}`);
    }
    $$renderer2.push(`</textarea></div> <div class="flex-1 flex flex-col gap-2"><label for="diff-b" class="text-sm font-semibold text-slate-700 dark:text-slate-300">Modified</label> <textarea id="diff-b" class="flex-1 p-4 font-mono text-sm bg-green-50/50 dark:bg-green-950/20 border border-green-200 dark:border-green-900/50 rounded-lg outline-none resize-none focus:ring-2 focus:ring-green-500/20 transition-all placeholder:text-slate-400" placeholder="Paste modified text here...">`);
    const $$body_1 = escape_html(textB);
    if ($$body_1) {
      $$renderer2.push(`${$$body_1}`);
    }
    $$renderer2.push(`</textarea></div></div> <div class="flex gap-4 text-sm"><span class="px-3 py-1 bg-green-100 dark:bg-green-900/50 text-green-700 dark:text-green-300 rounded-full font-medium">+${escape_html(stats.added)} added</span> <span class="px-3 py-1 bg-red-100 dark:bg-red-900/50 text-red-700 dark:text-red-300 rounded-full font-medium">-${escape_html(stats.removed)} removed</span> <span class="px-3 py-1 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded-full font-medium">${escape_html(stats.same)} unchanged</span></div> <div class="flex-1 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg overflow-auto max-h-[400px]">`);
    if (diff.length === 0) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="p-8 text-center text-slate-400 italic">Enter text in both fields to see differences...</div>`);
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<div class="font-mono text-sm divide-y divide-slate-100 dark:divide-slate-900"><!--[-->`);
      const each_array = ensure_array_like(diff);
      for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
        let line = each_array[$$index];
        $$renderer2.push(`<div${attr_class(`flex ${stringify(line.type === "added" ? "bg-green-50 dark:bg-green-950/30" : line.type === "removed" ? "bg-red-50 dark:bg-red-950/30" : "")}`)}><div class="w-12 shrink-0 px-2 py-1 text-right text-slate-400 border-r border-slate-200 dark:border-slate-800 select-none">${escape_html(line.lineNum)}</div> <div${attr_class(`w-8 shrink-0 text-center py-1 font-bold select-none ${stringify(line.type === "added" ? "text-green-600" : line.type === "removed" ? "text-red-600" : "text-slate-300")}`)}>${escape_html(line.type === "added" ? "+" : line.type === "removed" ? "-" : " ")}</div> <div${attr_class(`flex-1 px-2 py-1 whitespace-pre-wrap ${stringify(line.type === "added" ? "text-green-700 dark:text-green-300" : line.type === "removed" ? "text-red-700 dark:text-red-300" : "text-slate-700 dark:text-slate-300")}`)}>${escape_html(line.content || " ")}</div></div>`);
      }
      $$renderer2.push(`<!--]--></div>`);
    }
    $$renderer2.push(`<!--]--></div></div>`);
    bind_props($$props, { textA, textB });
  });
}
async function renderPlantUML(code, serverUrl = "https://www.plantuml.com/plantuml") {
  const encoded = plantumlEncoder.encode(code);
  const baseUrl = serverUrl.replace(/\/$/, "");
  const url = `${baseUrl}/svg/${encoded}`;
  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`PlantUML Render Failed: ${response.status} ${response.statusText}`);
    }
    return await response.text();
  } catch (e) {
    console.error("PlantUML Render Error:", e);
    throw new Error(`Connection Failed: ${e.message}`);
  }
}
let vizInstance = null;
async function getViz() {
  if (!vizInstance) {
    vizInstance = await instance();
  }
  return vizInstance;
}
async function renderGraphviz(code, engine = "dot") {
  try {
    const viz = await getViz();
    const result = viz.renderSVGElement(code, { engine });
    return result.outerHTML;
  } catch (e) {
    vizInstance = null;
    throw e;
  }
}
function generateHeuristicDiagram(prompt) {
  const p = prompt.toLowerCase();
  const lines = prompt.split("\n").filter((l) => l.trim());
  if (p.includes("graphviz") || p.includes("dot") || p.includes("digraph") || p.includes("cluster")) {
    let code2 = `digraph G {
    rankdir=LR;
    node [shape=box, style=filled, fillcolor="#e0e7ff", color="#4338ca", fontname="Sans-Serif"];
    edge [color="#6366f1"];

`;
    const edges = [];
    const nodes = /* @__PURE__ */ new Set();
    lines.forEach((line) => {
      const cleanLine = line.replace(/connects to|leads to|goes to/gi, "->");
      if (cleanLine.includes("->")) {
        const parts = cleanLine.split("->");
        if (parts.length >= 2) {
          const src = parts[0].trim().replace(/\s+/g, "_");
          const dst = parts[1].trim().replace(/\s+/g, "_");
          edges.push(`    ${src} -> ${dst};`);
          nodes.add(src);
          nodes.add(dst);
        }
      } else {
        const word = line.split(" ")[0].trim().replace(/\s+/g, "_");
        if (word && !word.includes("->")) {
          nodes.add(word);
        }
      }
    });
    if (edges.length === 0 && nodes.size === 0) {
      const words = p.split(" ").filter((w) => w.length > 3 && !["make", "create", "draw", "graph"].includes(w)).slice(0, 3);
      if (words.length > 0) {
        words.forEach((w, i) => {
          if (i < words.length - 1) code2 += `    ${w} -> ${words[i + 1]};
`;
        });
      } else {
        code2 += `    Start -> Process -> End;
`;
      }
    } else {
      edges.forEach((e) => code2 += e + "\n");
    }
    code2 += "}";
    return { code: code2, mode: "graphviz" };
  }
  let code = "@startuml\n!theme plain\n";
  if (p.includes("class") || p.includes("object") || p.includes("interface") || p.includes("inherit")) {
    code = "@startuml\n!theme mimeograph\nskinparam classAttributeIconSize 0\n\n";
    lines.forEach((line) => {
      if (line.includes("extends") || line.includes("inherits")) {
        const parts = line.split(/extends|inherits/i);
        code += `class ${parts[0].trim()} extends ${parts[1].trim()}
`;
      } else if (line.includes("class")) {
        const name = line.match(/class\s+(\w+)/i)?.[1] || line.split(" ")[0];
        code += `class ${name} {
  + method()
}
`;
      }
    });
    if (code.trim() === "@startuml\n!theme mimeograph\nskinparam classAttributeIconSize 0") {
      code += `class User {
  - id : String
  + login()
}
class System
User --> System : interactive
`;
    }
  } else if (p.includes("use case") || p.includes("actor")) {
    code += `left to right direction
`;
    lines.forEach((line) => {
      if (line.toLowerCase().includes("actor")) {
        const name = line.split(" ").pop() || "User";
        code += `actor ${name}
`;
      } else if (line.includes("uses") || line.includes("can")) {
        code += `usecase "Action" as UC1
`;
      }
    });
    code += `actor User
usecase "Core Feature" as UC1
User --> UC1
`;
  } else if (p.includes("gantt") || p.includes("timeline") || p.includes("schedule")) {
    code = `@startgantt
[Project Start] lasts 0 days
`;
    lines.forEach((line) => {
      if (line.includes("days") || line.includes("weeks")) {
        code += `[Task] lasts 5 days
`;
      }
    });
    code += `[Phase 1] lasts 10 days
[Phase 2] starts at [Phase 1]'s end and lasts 5 days
@endgantt`;
    return { code, mode: "plantuml" };
  } else if (p.includes("mindmap") || p.includes("breakdown") || p.includes("idea")) {
    code = `@startmindmap
* Root
`;
    lines.forEach((line) => {
      if (line.trim()) code += `** ${line.trim()}
`;
    });
    code += `@endmindmap`;
    return { code, mode: "plantuml" };
  } else if (p.includes("db") || p.includes("database") || p.includes("entity") || p.includes("schema") || p.includes("table")) {
    code = `@startuml
!theme bluegray
hide circle
skinparam linetype ortho

`;
    code += `entity "User" as user {
  *id : number <<generated>>
  --
  name : text
}

`;
    code += `entity "Order" as order {
  *id : number
  user_id : number <<FK>>
}

`;
    code += `user ||..o{ order : places
`;
  } else {
    code = "@startuml\nautonumber\n";
    let hasInteraction = false;
    lines.forEach((line) => {
      if (line.includes("->") || line.includes(" to ")) {
        const parts = line.split(/->| to /);
        if (parts.length >= 2) {
          code += `${parts[0].trim()} -> ${parts[1].trim()} : ${parts[1].trim().split(" ")[0]}
`;
          hasInteraction = true;
        }
      }
    });
    if (!hasInteraction) {
      code += `User -> System : Request
System --> User : Response
`;
    }
  }
  code += "\n@enduml";
  return { code, mode: "plantuml" };
}
function findDefinitions(code, mode) {
  const definitions = /* @__PURE__ */ new Map();
  const lines = code.split("\n");
  if (mode === "plantuml") {
    const regexExplicit = /^\s*(class|interface|enum|component|node|rectangle|file|storage|usecase|actor|agent|boundary|control|entity|database|queue)\s+(.+?)(?:\s*\{|$)/;
    lines.forEach((line, index) => {
      const match = line.match(regexExplicit);
      if (match) {
        let type = match[1];
        let body = match[2].trim();
        let id = "";
        const asMatch = body.split(/\s+as\s+/);
        if (asMatch.length > 1) {
          let potentialId = asMatch[1].trim();
          potentialId = potentialId.split(/[\s<<#]/)[0];
          id = potentialId;
        } else {
          if (body.startsWith('"')) {
            const endQuote = body.indexOf('"', 1);
            if (endQuote !== -1) id = body.slice(1, endQuote);
            else id = body;
          } else if (body.startsWith("[")) {
            const endBracket = body.indexOf("]");
            if (endBracket !== -1) id = body.slice(1, endBracket);
            else id = body;
          } else {
            id = body.split(/\s+/)[0];
          }
        }
        id = id.replace(/^["\[]|["\]]$/g, "");
        if (id && !definitions.has(id)) {
          definitions.set(id, {
            id,
            type,
            line: index,
            raw: line
          });
        }
      }
    });
  } else {
    lines.forEach((line, index) => {
      const trimmed = line.trim();
      if (trimmed.includes("->") || trimmed.includes("--")) return;
      if (trimmed.startsWith("//") || trimmed.startsWith("#")) return;
      if (!trimmed) return;
      const regexDot = /^(\s*)(?:([a-zA-Z0-9_]+)|"([^"]+)")\s*(?:\[.*\])?\s*;?\s*(?:(?:\/\/|#).*)?$/;
      const match = line.match(regexDot);
      if (match) {
        const id = match[2] || match[3];
        if (id && !definitions.has(id)) {
          definitions.set(id, {
            id,
            type: "node",
            // Generic node
            line: index,
            raw: line
          });
        }
      }
    });
  }
  return definitions;
}
function extractProperties(definitionLine, mode) {
  const props = {};
  if (mode === "plantuml") {
    const colorMatch = definitionLine.match(/#(\w+|[0-9a-fA-F]{3,6})/);
    if (colorMatch) {
      props.color = "#" + colorMatch[1];
    }
    const labelMatch = definitionLine.match(/"([^"]+)"/);
    if (labelMatch) {
      props.label = labelMatch[1];
    } else {
      const bracketMatch = definitionLine.match(/\[([^\]]+)\]/);
      if (bracketMatch) {
        props.label = bracketMatch[1];
      }
    }
  } else {
    const colorMatch = definitionLine.match(/(?:color|fillcolor)\s*=\s*(?:"([^"]+)"|([a-zA-Z0-9#]+))/);
    if (colorMatch) {
      props.color = colorMatch[1] || colorMatch[2];
    }
    const labelMatch = definitionLine.match(/label\s*=\s*"([^"]+)"/);
    if (labelMatch) {
      props.label = labelMatch[1];
    }
    const posMatch = definitionLine.match(/pos\s*=\s*"?([-0-9.,!]+)"?/);
    if (posMatch) {
      props.pos = posMatch[1];
    }
  }
  return props;
}
function injectColor(code, id, color, mode) {
  const definitions = findDefinitions(code, mode);
  const def = definitions.get(id);
  if (!def) {
    if (mode === "plantuml") {
      return appendNewDefinition(code, mode, `${id} ${color}`);
    } else {
      return appendNewDefinition(code, mode, `${id} [fillcolor="${color}", style="filled"];`);
    }
  }
  const lines = code.split("\n");
  let line = lines[def.line];
  if (mode === "plantuml") {
    const existingColorRegex = /#(\w+|[0-9a-fA-F]{3,6})/;
    const match = line.match(existingColorRegex);
    if (match) {
      line = line.replace(match[0], color ? `${color}` : "");
    } else if (color) {
      const splitRegex = /(\s*)(\{|$|<<)/;
      const splitMatch = line.match(splitRegex);
      if (splitMatch && splitMatch.index !== void 0) {
        line = line.slice(0, splitMatch.index) + " " + color + line.slice(splitMatch.index);
      } else {
        line += " " + color;
      }
    }
  } else {
    const attrBlockRegex = /\[(.*?)\]/;
    const blockMatch = line.match(attrBlockRegex);
    if (blockMatch) {
      let content = blockMatch[1];
      const colorPropRegex = /(color|fillcolor)\s*=\s*(?:"[^"]*"|[^,\s\]]+)/;
      if (colorPropRegex.test(content)) {
        if (color) {
          content = content.replace(colorPropRegex, `fillcolor="${color}"`);
        } else {
          content = content.replace(colorPropRegex, `fillcolor="${color}"`);
        }
      } else if (color) {
        if (content.trim().length > 0) {
          content += `, fillcolor="${color}", style="filled"`;
        } else {
          content = `fillcolor="${color}", style="filled"`;
        }
      }
      line = line.replace(attrBlockRegex, `[${content}]`);
    } else if (color) {
      const splitRegex = /(\s*)(;|$)/;
      const splitMatch = line.match(splitRegex);
      if (splitMatch && splitMatch.index !== void 0) {
        line = line.slice(0, splitMatch.index) + ` [fillcolor="${color}", style="filled"]` + line.slice(splitMatch.index);
      }
    }
  }
  lines[def.line] = line;
  return lines.join("\n");
}
function appendNewDefinition(code, mode, newLine) {
  const lines = code.split("\n");
  let insertIdx = lines.length;
  if (mode === "plantuml") {
    for (let i = lines.length - 1; i >= 0; i--) {
      if (lines[i].trim() === "@enduml") {
        insertIdx = i;
        break;
      }
    }
  } else {
    for (let i = lines.length - 1; i >= 0; i--) {
      if (lines[i].trim() === "}") {
        insertIdx = i;
        break;
      }
    }
  }
  const indent = "    ";
  lines.splice(insertIdx, 0, indent + newLine);
  return lines.join("\n");
}
function injectLabel(code, id, label, mode) {
  const definitions = findDefinitions(code, mode);
  const def = definitions.get(id);
  if (!def) {
    if (mode === "plantuml") {
      return appendNewDefinition(code, mode, `${id} : "${label}"`);
    } else {
      return appendNewDefinition(code, mode, `${id} [label="${label}"];`);
    }
  }
  const lines = code.split("\n");
  let line = lines[def.line];
  if (mode === "plantuml") {
    const quotedLabelRegex = /"([^"]+)"/;
    const bracketLabelRegex = /\[([^\]]+)\]/;
    if (quotedLabelRegex.test(line)) {
      line = line.replace(quotedLabelRegex, `"${label}"`);
    } else if (bracketLabelRegex.test(line)) {
      line = line.replace(bracketLabelRegex, `[${label}]`);
    } else {
      const splitRegex = /(\s*)(\{|$|<<|#)/;
      const splitMatch = line.match(splitRegex);
      if (splitMatch && splitMatch.index !== void 0) {
        line = line.slice(0, splitMatch.index) + ` "${label}"` + line.slice(splitMatch.index);
      }
    }
  } else {
    const labelRegex = /label\s*=\s*"([^"]+)"/;
    if (labelRegex.test(line)) {
      line = line.replace(labelRegex, `label="${label}"`);
    } else {
      const attrBlockRegex = /\[(.*?)\]/;
      const blockMatch = line.match(attrBlockRegex);
      if (blockMatch) {
        let content = blockMatch[1];
        if (content.trim().length > 0) {
          content += `, label="${label}"`;
        } else {
          content = `label="${label}"`;
        }
        line = line.replace(attrBlockRegex, `[${content}]`);
      } else {
        const splitRegex = /(\s*)(;|$)/;
        const splitMatch = line.match(splitRegex);
        if (splitMatch && splitMatch.index !== void 0) {
          line = line.slice(0, splitMatch.index) + ` [label="${label}"]` + line.slice(splitMatch.index);
        }
      }
    }
  }
  lines[def.line] = line;
  return lines.join("\n");
}
function injectShape(code, id, shape, mode) {
  const definitions = findDefinitions(code, mode);
  const def = definitions.get(id);
  if (!def) {
    if (mode === "plantuml") {
      return appendNewDefinition(code, mode, `${shape} ${id}`);
    } else {
      return appendNewDefinition(code, mode, `${id} [shape=${shape}];`);
    }
  }
  const lines = code.split("\n");
  let line = lines[def.line];
  if (mode === "plantuml") {
    const typeRegex = new RegExp(`^(\\s*)${def.type}\\b`);
    if (typeRegex.test(line)) {
      line = line.replace(typeRegex, `$1${shape}`);
    }
  } else {
    const shapeRegex = /shape\s*=\s*([a-zA-Z0-9]+)/;
    if (shapeRegex.test(line)) {
      line = line.replace(shapeRegex, `shape=${shape}`);
    } else {
      const attrBlockRegex = /\[(.*?)\]/;
      const blockMatch = line.match(attrBlockRegex);
      if (blockMatch) {
        let content = blockMatch[1];
        content += `, shape=${shape}`;
        line = line.replace(attrBlockRegex, `[${content}]`);
      } else {
        const splitRegex = /(\s*)(;|$)/;
        const splitMatch = line.match(splitRegex);
        if (splitMatch && splitMatch.index !== void 0) {
          line = line.slice(0, splitMatch.index) + ` [shape=${shape}]` + line.slice(splitMatch.index);
        }
      }
    }
  }
  lines[def.line] = line;
  return lines.join("\n");
}
function injectPosition(code, id, x, y, mode) {
  if (mode !== "graphviz") return code;
  const definitions = findDefinitions(code, mode);
  const def = definitions.get(id);
  const posStr = `${x.toFixed(2)},${y.toFixed(2)}!`;
  if (!def) {
    return appendNewDefinition(code, mode, `${id} [pos="${posStr}"];`);
  }
  const lines = code.split("\n");
  let line = lines[def.line];
  const posRegex = /pos\s*=\s*(?:"[^"]*"|[^,\s\]]+)/;
  const attrBlockRegex = /\[(.*?)\]/;
  const blockMatch = line.match(attrBlockRegex);
  if (blockMatch) {
    let content = blockMatch[1];
    if (posRegex.test(content)) {
      content = content.replace(posRegex, `pos="${posStr}"`);
    } else {
      if (content.trim().length > 0) {
        content += `, pos="${posStr}"`;
      } else {
        content = `pos="${posStr}"`;
      }
    }
    line = line.replace(attrBlockRegex, `[${content}]`);
  } else {
    const splitRegex = /(\s*)(;|$)/;
    const splitMatch = line.match(splitRegex);
    if (splitMatch && splitMatch.index !== void 0) {
      line = line.slice(0, splitMatch.index) + ` [pos="${posStr}"]` + line.slice(splitMatch.index);
    }
  }
  lines[def.line] = line;
  return lines.join("\n");
}
class DiagramStore {
  // Core State (Proxied to Active Document)
  get code() {
    return this.documents.find((d) => d.id === this.activeDocumentId)?.code || "";
  }
  set code(v) {
    const doc = this.documents.find((d) => d.id === this.activeDocumentId);
    if (doc) doc.code = v;
  }
  get mode() {
    return this.documents.find((d) => d.id === this.activeDocumentId)?.mode || "plantuml";
  }
  set mode(v) {
    const doc = this.documents.find((d) => d.id === this.activeDocumentId);
    if (doc) doc.mode = v;
  }
  get engine() {
    return this.documents.find((d) => d.id === this.activeDocumentId)?.engine || "dot";
  }
  set engine(v) {
    const doc = this.documents.find((d) => d.id === this.activeDocumentId);
    if (doc) doc.engine = v;
  }
  // View State (Per-session, not per-document strictly, but let's keep it global for now or strictly per doc? 
  // Let's keep View State global for simplicity of switching, OR per doc if we want to remember scroll pos.
  // For now, SVG is derived from render, so it's transient.)
  svg = "";
  isRendering = false;
  error = null;
  scale = 1;
  pan = { x: 0, y: 0 };
  snippets = [];
  autoRender = true;
  previewTheme = "light";
  // Advanced Interactions
  selectedElementId = null;
  selectedElementType = null;
  get overrides() {
    return this.documents.find((d) => d.id === this.activeDocumentId)?.overrides || {};
  }
  set overrides(v) {
    const doc = this.documents.find((d) => d.id === this.activeDocumentId);
    if (doc) doc.overrides = v;
  }
  // UI Panels
  isInspectorOpen = false;
  isSidebarPinned = true;
  focusMode = false;
  multiSelection = [];
  // Layer Management
  activeLayers = [];
  // Using array for easier serialization
  availableLayers = [];
  toggleLayer(layer) {
    if (this.activeLayers.includes(layer)) {
      this.activeLayers = this.activeLayers.filter((l) => l !== layer);
    } else {
      this.activeLayers = [...this.activeLayers, layer];
    }
  }
  setAvailableLayers(layers) {
    this.availableLayers = layers;
    this.activeLayers = this.activeLayers.filter((l) => layers.includes(l));
  }
  // Layout Parameters (Reactive & Per-engine)
  layoutParams = {
    nodesep: 0.5,
    ranksep: 0.5,
    rankdir: "TB",
    // TB, LR, BT, RL
    overlap: "false",
    splines: "true"
  };
  // Multi-Doc State
  documents = [];
  activeDocumentId = "";
  #renderTimeout = null;
  // Settings
  fontSize = 14;
  fontFamily = "'JetBrains Mono', monospace";
  plantumlServerUrl = "https://www.plantuml.com/plantuml";
  constructor(initialCode = "", initialMode = "plantuml") {
    const defaultDoc = {
      id: crypto.randomUUID(),
      name: "Untitled",
      code: initialCode,
      mode: initialMode,
      engine: "dot",
      overrides: {},
      history: []
    };
    this.documents = [defaultDoc];
    this.activeDocumentId = defaultDoc.id;
    this.loadAll();
    this.loadSnippets();
  }
  loadAll() {
    if (typeof localStorage === "undefined") return;
    const savedDocs = localStorage.getItem("aone_diagram_documents");
    const activeId = localStorage.getItem("aone_diagram_active_id");
    if (savedDocs && activeId) {
      try {
        this.documents = JSON.parse(savedDocs);
        this.activeDocumentId = activeId;
        const active = this.documents.find((d) => d.id === this.activeDocumentId);
        if (active) {
          this.code = active.code;
          this.mode = active.mode;
          this.engine = active.engine;
          this.overrides = active.overrides || {};
          if (active.layoutParams) {
            this.layoutParams = { ...this.layoutParams, ...active.layoutParams };
          }
        }
      } catch (e) {
        console.error("Failed to load documents", e);
      }
    } else {
      this.handleMigration();
    }
    this.loadSettings();
  }
  loadSettings() {
    if (typeof localStorage === "undefined") return;
    const settings = localStorage.getItem("aone_diagram_settings");
    if (settings) {
      try {
        const parsed = JSON.parse(settings);
        if (parsed.fontSize) this.fontSize = parsed.fontSize;
        if (parsed.fontFamily) this.fontFamily = parsed.fontFamily;
        if (parsed.plantumlServerUrl) this.plantumlServerUrl = parsed.plantumlServerUrl;
        if (parsed.previewTheme) this.previewTheme = parsed.previewTheme;
      } catch (e) {
        console.error("Failed to load settings", e);
      }
    }
  }
  saveSettings() {
    if (typeof localStorage === "undefined") return;
    const settings = {
      fontSize: this.fontSize,
      fontFamily: this.fontFamily,
      plantumlServerUrl: this.plantumlServerUrl,
      previewTheme: this.previewTheme
    };
    localStorage.setItem("aone_diagram_settings", JSON.stringify(settings));
  }
  handleMigration() {
    const draftStr = localStorage.getItem("aone_diagram_draft");
    if (draftStr) {
      const draft = JSON.parse(draftStr);
      const savedOverrides = localStorage.getItem("diagram_overrides");
      this.documents[0].code = draft.code || "";
      this.documents[0].mode = draft.mode || "plantuml";
      this.documents[0].engine = draft.engine || "dot";
      this.documents[0].overrides = savedOverrides ? JSON.parse(savedOverrides) : {};
    }
    this.saveAll();
  }
  saveAll() {
    if (typeof localStorage === "undefined") return;
    localStorage.setItem("aone_diagram_documents", JSON.stringify(this.documents));
    localStorage.setItem("aone_diagram_active_id", this.activeDocumentId);
  }
  // Tab Management
  createDocument(name = "New Diagram") {
    const newDoc = {
      id: crypto.randomUUID(),
      name,
      code: "",
      mode: "plantuml",
      engine: "dot",
      overrides: {},
      history: []
    };
    this.documents = [...this.documents, newDoc];
    this.switchDocument(newDoc.id);
  }
  switchDocument(id) {
    this.saveAll();
    const doc = this.documents.find((d) => d.id === id);
    if (doc) {
      this.activeDocumentId = id;
      this.svg = "";
      this.render();
    }
  }
  closeDocument(id) {
    if (this.documents.length <= 1) return;
    const index = this.documents.findIndex((d) => d.id === id);
    this.documents = this.documents.filter((d) => d.id !== id);
    if (this.activeDocumentId === id) {
      const nextDoc = this.documents[Math.max(0, index - 1)];
      this.switchDocument(nextDoc.id);
    } else {
      this.saveAll();
    }
  }
  // History Logic
  takeSnapshot() {
    const active = this.documents.find((d) => d.id === this.activeDocumentId);
    if (!active || !this.code) return;
    const lastSnapshot = active.history[active.history.length - 1];
    if (lastSnapshot?.code === this.code) return;
    active.history = [
      ...active.history,
      { code: this.code, timestamp: Date.now() }
    ].slice(-50);
    this.saveAll();
  }
  // Simplified override logic (syncs with active doc)
  setOverride(id, adjustment) {
    if (!this.overrides[id]) {
      this.overrides[id] = {};
    }
    this.overrides[id] = { ...this.overrides[id], ...adjustment };
    this.saveAll();
  }
  clearOverride(id) {
    delete this.overrides[id];
    this.saveAll();
  }
  #definitions = derived(() => findDefinitions(this.code, this.mode));
  get definitions() {
    return this.#definitions();
  }
  set definitions($$value) {
    return this.#definitions($$value);
  }
  #selectedElementProperties = derived(() => {
    if (!this.selectedElementId) return {};
    const def = this.definitions.get(this.selectedElementId);
    if (def) {
      const props = extractProperties(def.raw, this.mode);
      const override = this.overrides[this.selectedElementId] || {};
      return { ...props, ...override };
    }
    return this.overrides[this.selectedElementId] || {};
  });
  get selectedElementProperties() {
    return this.#selectedElementProperties();
  }
  set selectedElementProperties($$value) {
    return this.#selectedElementProperties($$value);
  }
  updateElementProperty(prop, value) {
    if (!this.selectedElementId) return;
    if (prop === "color") {
      this.code = injectColor(this.code, this.selectedElementId, value, this.mode);
      if (this.overrides[this.selectedElementId]?.color) {
        delete this.overrides[this.selectedElementId].color;
      }
    } else if (prop === "label") {
      this.code = injectLabel(this.code, this.selectedElementId, value, this.mode);
    } else if (prop === "shape") {
      this.code = injectShape(this.code, this.selectedElementId, value, this.mode);
    } else {
      this.setOverride(this.selectedElementId, { [prop]: value });
    }
  }
  updateNodePosition(id, x, y) {
    if (this.mode === "graphviz") {
      this.code = injectPosition(this.code, id, x, y, this.mode);
      if (this.overrides[id]) {
        delete this.overrides[id].x;
        delete this.overrides[id].y;
      }
    } else {
      this.setOverride(id, { x, y });
    }
  }
  #persistDraft = derived(() => {
    this.saveAll();
  });
  get persistDraft() {
    return this.#persistDraft();
  }
  set persistDraft($$value) {
    return this.#persistDraft($$value);
  }
  loadSnippets() {
    if (typeof localStorage === "undefined") return;
    const data = localStorage.getItem("aone_diagram_snippets");
    if (data) {
      try {
        this.snippets = JSON.parse(data);
      } catch (e) {
        console.error("Failed to load snippets", e);
      }
    }
  }
  saveSnippet(name) {
    const newSnippet = {
      id: crypto.randomUUID(),
      name,
      code: this.code,
      mode: this.mode,
      timestamp: Date.now()
    };
    this.snippets = [newSnippet, ...this.snippets];
    this.persistSnippets();
  }
  deleteSnippet(id) {
    this.snippets = this.snippets.filter((s) => s.id !== id);
    this.persistSnippets();
  }
  loadSnippet(id) {
    const snippet = this.snippets.find((s) => s.id === id);
    if (snippet) {
      this.code = snippet.code;
      this.mode = snippet.mode;
      this.render();
    }
  }
  persistSnippets() {
    if (typeof localStorage === "undefined") return;
    localStorage.setItem("aone_diagram_snippets", JSON.stringify(this.snippets));
  }
  async render() {
    if (!this.code.trim()) return;
    const isPlantUmlNode = /^\s*node\s+(?!"|\[)/m.test(this.code);
    if (this.mode !== "plantuml" && (this.code.includes("@startuml") || this.code.includes("class ") || this.code.includes("interface ") || isPlantUmlNode)) {
      if (this.code.includes("@startuml") || isPlantUmlNode) {
        console.warn("Auto-switching to PlantUML mode detected.");
        this.mode = "plantuml";
      }
    }
    if (this.mode === "plantuml" && (this.code.trim().startsWith("digraph") || this.code.trim().startsWith("graph"))) {
      console.warn("Auto-switching to Graphviz mode detected.");
      this.mode = "graphviz";
    }
    this.isRendering = true;
    this.error = null;
    try {
      if (this.mode === "plantuml") {
        this.svg = await renderPlantUML(this.code, this.plantumlServerUrl);
      } else {
        let finalCode = this.code;
        const p = this.layoutParams;
        const injection = `
  nodesep=${p.nodesep};
  ranksep=${p.ranksep};
  rankdir=${p.rankdir};
  overlap=${p.overlap};
  splines=${p.splines};
`;
        const braceIndex = finalCode.indexOf("{");
        if (braceIndex !== -1) {
          finalCode = finalCode.slice(0, braceIndex + 1) + injection + finalCode.slice(braceIndex + 1);
        }
        this.svg = await renderGraphviz(finalCode, this.engine);
      }
    } catch (e) {
      console.error("Render error:", e);
      this.error = e.message || "Render failed";
      this.svg = "";
    } finally {
      this.isRendering = false;
    }
  }
  resetView() {
    this.scale = 1;
    this.pan = { x: 0, y: 0 };
  }
  async generateFromPrompt(prompt) {
    if (!prompt.trim()) return;
    this.isRendering = true;
    this.error = null;
    try {
      const result = generateHeuristicDiagram(prompt);
      await new Promise((resolve) => setTimeout(resolve, 800));
      this.code = result.code;
      this.mode = result.mode;
      await this.render();
    } catch (e) {
      this.error = "AI Generation failed: " + e.message;
    } finally {
      this.isRendering = false;
    }
  }
  restoreHistory(item) {
    this.code = item.code;
    this.render();
  }
  autoRenderEffect = () => {
  };
}
const diagramStore = new DiagramStore("");
function Header($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    $$renderer2.push(`<header class="flex items-center justify-between px-6 py-3 m-4 mb-0 rounded-2xl glass-panel transition-all duration-300 z-50 shrink-0"><div class="flex items-center gap-3 group cursor-pointer"><div class="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 via-purple-500 to-purple-600 flex items-center justify-center text-white shadow-glow-md group-hover:scale-110 transition-transform duration-300">`);
    Code($$renderer2, {
      size: (
        // Share logic moved to ShareModal
        20
      ),
      strokeWidth: 2.5
    });
    $$renderer2.push(`<!----></div> <div class="flex flex-col"><h1 class="font-black text-lg tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-indigo-500 to-purple-600">AONE</h1> <span class="text-[10px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500">Toolkit</span></div></div> <div class="flex bg-gray-100/50 dark:bg-gray-800/50 p-1 rounded-xl border border-gray-200/50 dark:border-gray-700/50 backdrop-blur-sm"><button${attr_class(`px-4 py-1.5 rounded-lg text-sm font-semibold transition-all duration-300 ${stringify(diagramStore.mode === "plantuml" ? "bg-white dark:bg-gray-700 shadow-sm text-indigo-600 dark:text-indigo-400 scale-105" : "text-gray-500 hover:text-gray-700 dark:text-gray-400 hover:bg-gray-200/50 dark:hover:bg-gray-700/50")}`)}>PlantUML</button> <button${attr_class(`px-4 py-1.5 rounded-lg text-sm font-semibold transition-all duration-300 ${stringify(diagramStore.mode === "graphviz" ? "bg-white dark:bg-gray-700 shadow-sm text-indigo-600 dark:text-indigo-400 scale-105" : "text-gray-500 hover:text-gray-700 dark:text-gray-400 hover:bg-gray-200/50 dark:hover:bg-gray-700/50")}`)}>Graphviz</button></div> `);
    if (diagramStore.mode === "graphviz") {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="ml-4 flex items-center gap-2 animate-fade-in"><span class="text-[10px] font-bold uppercase tracking-wider text-gray-400">Engine</span> <div class="relative group">`);
      $$renderer2.select(
        {
          value: diagramStore.engine,
          class: "appearance-none bg-gray-100/50 dark:bg-gray-800/50 border border-gray-200 dark:border-gray-700 rounded-lg py-1.5 pl-3 pr-8 text-sm font-medium focus:ring-2 focus:ring-indigo-500 outline-none cursor-pointer hover:bg-white dark:hover:bg-gray-800 transition-colors"
        },
        ($$renderer3) => {
          $$renderer3.push(`<!--[-->`);
          const each_array = ensure_array_like(["dot", "circo", "fdp", "neato", "osage", "twopi"]);
          for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
            let e = each_array[$$index];
            $$renderer3.option({ value: e }, ($$renderer4) => {
              $$renderer4.push(`${escape_html(e)}`);
            });
          }
          $$renderer3.push(`<!--]-->`);
        }
      );
      $$renderer2.push(` <div class="absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none opacity-50"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"></path></svg></div></div></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> <div class="flex items-center gap-1.5 pl-4 border-l border-gray-200/50 dark:border-gray-700/50 ml-4"><button class="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-500 hover:to-indigo-600 text-white rounded-xl shadow-lg shadow-indigo-500/20 transition-all duration-300 hover:-translate-y-0.5 active:scale-95 font-semibold text-sm"${attr("disabled", diagramStore.isRendering, true)}>`);
    Play($$renderer2, {
      size: 16,
      class: diagramStore.isRendering ? "animate-spin" : "fill-current"
    });
    $$renderer2.push(`<!----> Render</button> <div class="w-px h-6 bg-gray-200/50 dark:bg-gray-700/50 mx-1"></div> <button class="p-2 text-gray-500 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 rounded-lg transition-all duration-200 hover:-translate-y-0.5" title="Export Image">`);
    Download($$renderer2, { size: 20 });
    $$renderer2.push(`<!----></button> <button class="p-2 text-gray-500 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 rounded-lg transition-all duration-200 hover:-translate-y-0.5" title="Find &amp; Replace (Ctrl+H)">`);
    Search($$renderer2, { size: 20 });
    $$renderer2.push(`<!----></button> <button class="p-2 text-gray-500 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 rounded-lg transition-all duration-200 hover:-translate-y-0.5" title="Local History">`);
    History($$renderer2, { size: 20 });
    $$renderer2.push(`<!----></button> <button class="p-2 text-gray-500 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 rounded-lg transition-all duration-200 hover:-translate-y-0.5" title="Accessibility View">`);
    Table($$renderer2, { size: 20 });
    $$renderer2.push(`<!----></button> <button class="p-2 text-gray-500 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 rounded-lg transition-all duration-200 hover:-translate-y-0.5" title="Keyboard Shortcuts (Ctrl+/)">`);
    Keyboard($$renderer2, { size: 20 });
    $$renderer2.push(`<!----></button> <div class="w-px h-6 bg-gray-200/50 dark:bg-gray-700/50 mx-1"></div> <button class="p-2 text-gray-500 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 rounded-lg transition-all duration-200 hover:-translate-y-0.5" title="Icon Browser">`);
    Image($$renderer2, { size: 20 });
    $$renderer2.push(`<!----></button> <button class="p-2 text-gray-500 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 rounded-lg transition-all duration-200 hover:-translate-y-0.5" title="Presentation Mode">`);
    Book($$renderer2, { size: 20 });
    $$renderer2.push(`<!----></button> <button${attr_class(`p-2 ${stringify(diagramStore.focusMode ? "text-indigo-600 bg-indigo-50 dark:bg-indigo-900/30 ring-1 ring-indigo-500/30" : "text-gray-500 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/20")} rounded-lg transition-all duration-200 hover:-translate-y-0.5`)} title="Toggle Zen Mode">`);
    if (diagramStore.focusMode) {
      $$renderer2.push("<!--[-->");
      Minimize($$renderer2, { size: 20 });
    } else {
      $$renderer2.push("<!--[!-->");
      Maximize($$renderer2, { size: 20 });
    }
    $$renderer2.push(`<!--]--></button> <button${attr_class(`p-2 transition-all duration-200 hover:-translate-y-0.5 rounded-lg ${stringify(diagramStore.autoRender ? "text-amber-500 bg-amber-50 dark:bg-amber-900/20 ring-1 ring-amber-500/30 shadow-glow-sm" : "text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800")}`)}${attr("title", diagramStore.autoRender ? "Auto-Render On" : "Auto-Render Off")}>`);
    if (diagramStore.autoRender) {
      $$renderer2.push("<!--[-->");
      Zap($$renderer2, { size: 20, class: "fill-current" });
    } else {
      $$renderer2.push("<!--[!-->");
      Zap_off($$renderer2, { size: 20 });
    }
    $$renderer2.push(`<!--]--></button> <button class="p-2 text-gray-500 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 rounded-lg transition-all duration-200 hover:-translate-y-0.5" title="Share Diagram">`);
    Share_2($$renderer2, { size: 20 });
    $$renderer2.push(`<!----></button> <div class="flex items-center gap-1 bg-gray-100/50 dark:bg-gray-800/50 p-1 rounded-lg ml-2"><button${attr_class(`p-1.5 transition-all duration-200 rounded-md ${stringify(diagramStore.previewTheme === "dark" ? "text-indigo-500 bg-white dark:bg-gray-700 shadow-sm" : "text-gray-400 hover:text-gray-600")}`)} title="Toggle Preview Theme">`);
    if (diagramStore.previewTheme === "light") {
      $$renderer2.push("<!--[-->");
      Image($$renderer2, { size: 16 });
    } else {
      $$renderer2.push("<!--[!-->");
      Image($$renderer2, { size: 16 });
    }
    $$renderer2.push(`<!--]--></button> <button class="p-1.5 text-gray-400 hover:text-indigo-500 transition-all duration-200 rounded-md">`);
    Sun($$renderer2, { size: 16, class: "hidden dark:block" });
    $$renderer2.push(`<!----> `);
    Moon($$renderer2, { size: 16, class: "block dark:hidden" });
    $$renderer2.push(`<!----></button></div></div></header>`);
  });
}
function TabsBar($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let editingTabId = null;
    let editName = "";
    $$renderer2.push(`<div class="flex items-center gap-1 bg-slate-50 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-2 h-10 overflow-hidden group"><div class="flex items-center gap-2 overflow-x-auto no-scrollbar scroll-smooth flex-1 h-full py-1 svelte-1p6edp6"><!--[-->`);
    const each_array = ensure_array_like(diagramStore.documents);
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      let doc = each_array[$$index];
      $$renderer2.push(`<div${attr_class(`flex items-center gap-2 px-3 h-full min-w-[120px] max-w-[200px] text-xs font-medium rounded-t-lg transition-all relative group/tab cursor-pointer ${stringify(diagramStore.activeDocumentId === doc.id ? "bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 shadow-[0_-1px_0_rgba(0,0,0,0.05)] border-x border-t border-slate-200 dark:border-slate-700" : "text-slate-500 hover:bg-slate-200/50 dark:hover:bg-slate-800/50")}`)} role="button" tabindex="0">`);
      File_text($$renderer2, {
        size: 12,
        class: diagramStore.activeDocumentId === doc.id ? "opacity-100" : "opacity-50"
      });
      $$renderer2.push(`<!----> `);
      if (editingTabId === doc.id) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<input${attr("value", editName)} class="bg-indigo-50 dark:bg-indigo-900/50 border-none outline-none text-xs w-full py-0.5 px-1 rounded"/>`);
      } else {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push(`<span class="truncate pr-4 flex-1 text-left">${escape_html(doc.name)}</span>`);
      }
      $$renderer2.push(`<!--]--> `);
      if (diagramStore.documents.length > 1) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<button class="absolute right-1.5 p-0.5 hover:bg-slate-200 dark:hover:bg-slate-700 rounded opacity-0 group-hover/tab:opacity-100 transition-opacity" title="Close Tab">`);
        X($$renderer2, { size: 10 });
        $$renderer2.push(`<!----></button>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></div>`);
    }
    $$renderer2.push(`<!--]--></div> <button class="p-1.5 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-lg text-slate-500 transition-colors flex-shrink-0" title="New Diagram (Ctrl+N)">`);
    Plus($$renderer2, { size: 16 });
    $$renderer2.push(`<!----></button></div>`);
  });
}
[
  snippetCompletion("class ${Name} {\n	${// properties}\n}", {
    label: "class",
    detail: "Define a class",
    type: "class"
  }),
  snippetCompletion("interface ${Name} {\n	${// methods}\n}", {
    label: "interface",
    detail: "Define an interface",
    type: "interface"
  }),
  snippetCompletion('folder "${Name}" {\n	${// content}\n}', {
    label: "folder",
    detail: "Group items in a folder",
    type: "namespace"
  }),
  snippetCompletion('package "${Name}" {\n	${// content}\n}', {
    label: "package",
    detail: "Group items in a package",
    type: "namespace"
  }),
  snippetCompletion('node "${Name}" {\n	${// content}\n}', {
    label: "node",
    detail: "Deployment node",
    type: "class"
  }),
  snippetCompletion('database "${Name}" {\n	${// content}\n}', {
    label: "database",
    detail: "Database element",
    type: "class"
  }),
  snippetCompletion("note ${right} of ${Target} : ${text}", {
    label: "note",
    detail: "Attach a note",
    type: "text"
  }),
  snippetCompletion("@startuml\n${}\n@enduml", {
    label: "startuml",
    detail: "Start PlantUML block",
    type: "keyword"
  }),
  snippetCompletion("skinparam ${param} ${value}", {
    label: "skinparam",
    detail: "Style parameter",
    type: "variable"
  })
];
function createSimpleMode(spec) {
  const parser = {
    startState() {
      return { state: "start", pending: null };
    },
    token(stream, state) {
      if (state.pending) {
        const style = state.pending;
        state.pending = null;
        return style;
      }
      const rules = spec[state.state];
      if (!rules) {
        stream.next();
        return null;
      }
      for (const rule of rules) {
        const matches = stream.match(rule.regex);
        if (matches) {
          if (rule.next) {
            state.state = rule.next;
          }
          return rule.token || null;
        }
      }
      stream.next();
      return null;
    }
  };
  return StreamLanguage.define(parser);
}
const plantUmlRules = {
  start: [
    { regex: /'.*/, token: "comment" },
    { regex: /\/\*/, token: "comment", next: "comment" },
    { regex: /@startuml|@enduml|@startmindmap|@endmindmap|@startsalt|@endsalt|@startjson|@endjson|@startyaml|@endyaml/, token: "meta" },
    { regex: /\b(participant|actor|boundary|control|entity|database|collections|queue|usecase|class|interface|enum|abstract|annotation|package|namespace|node|folder|frame|cloud|rectangle|component|agent|artifact|file|card|stack|storage|label|hexagon|person)\b/, token: "keyword" },
    { regex: /\b(as|is|of|on|if|then|else|endif|elseif|while|endwhile|repeat|endrepeat|fork|again|end|kill|stop|start|detach|note|end note|rnote|hnote|legend|end legend|title|header|footer|newpage|autonumber|activate|deactivate|destroy|create|box|end box|alt|opt|loop|par|break|critical|group|ref|return|partition|skinparam|hide|show|top|bottom|left|right|up|down|over|of)\b/, token: "keyword" },
    { regex: /\b(true|false|null)\b/, token: "atom" },
    { regex: /(?:<\|?|[ox*+#])?(?:-+(?:>|\|>)?|-+(?:\[#\w+\])?-+(?:>|\|>)?|\.+(?:>|\|>)?|={2,}(?:>|\|>)?)/, token: "string-2" },
    // 'builtin' -> 'string-2' (Arrow)
    { regex: /"(?:[^"\\]|\\.)*"/, token: "string" },
    { regex: /:.*?[;|<>/\]}]/, token: "string" },
    { regex: /\b[A-Z][a-zA-Z0-9_]*\b/, token: "type" },
    { regex: /[{}\[\]()]/, token: "operator" },
    // 'bracket' -> 'operator' (Pink)
    { regex: /[+\-#~]/, token: "operator" }
  ],
  comment: [
    { regex: /.*?\*\//, token: "comment", next: "start" },
    { regex: /.*/, token: "comment" }
  ]
};
const dotRules = {
  start: [
    { regex: /\/\/.*/, token: "comment" },
    { regex: /#.*/, token: "comment" },
    { regex: /\/\*/, token: "comment", next: "comment" },
    { regex: /\b(strict|graph|digraph|subgraph|node|edge)\b/i, token: "keyword" },
    { regex: /\b(label|color|fillcolor|fontcolor|fontname|fontsize|shape|style|width|height|size|rankdir|rank|splines|overlap|compound|bgcolor|margin|arrowhead|arrowtail|dir|penwidth)\b/i, token: "attribute" },
    { regex: /\b(box|polygon|ellipse|oval|circle|point|diamond|rect|rectangle|square|cylinder|note|folder|box3d|component|record)\b/i, token: "atom" },
    { regex: /->|--/, token: "string-2" },
    // 'builtin' -> 'string-2'
    { regex: /"(?:[^"\\]|\\.)*"/, token: "string" },
    { regex: /<[^>]*>/, token: "string" },
    { regex: /\b[a-zA-Z_][a-zA-Z0-9_]*\b/, token: "variable" },
    { regex: /[{}\[\]();,]/, token: "operator" },
    { regex: /=/, token: "operator" }
  ],
  comment: [
    { regex: /.*?\*\//, token: "comment", next: "start" },
    { regex: /.*/, token: "comment" }
  ]
};
createSimpleMode(plantUmlRules);
createSimpleMode(dotRules);
function ColorPicker($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    $$renderer2.push(`<div class="relative"><button${attr_class(`p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors ${stringify("")}`)} title="Color Picker">`);
    Palette($$renderer2, { size: 18 });
    $$renderer2.push(`<!----></button> `);
    {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--></div>`);
  });
}
function EditorToolbar($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      mode,
      activeDirection = null,
      hasArrows = false
    } = $$props;
    const buttons = [
      { id: "left", icon: Arrow_left, label: "Left" },
      { id: "right", icon: Arrow_right, label: "Right" },
      { id: "up", icon: Arrow_up, label: "Up" },
      { id: "down", icon: Arrow_down, label: "Down" },
      { id: "default", icon: Move, label: "Auto" }
    ];
    $$renderer2.push(`<div class="border-b border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 transition-all duration-300 overflow-hidden"${attr_style("", {
      height: hasArrows ? "40px" : "0px",
      opacity: hasArrows ? "1" : "0"
    })}><div class="h-10 flex items-center px-4 gap-4"><div class="text-[10px] font-bold text-gray-400 uppercase tracking-wider shrink-0 flex items-center gap-2"><span>Connection</span> <div class="h-3 w-[1px] bg-gray-200 dark:bg-gray-700"></div></div> `);
    if (mode === "plantuml") {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="flex items-center gap-1"><!--[-->`);
      const each_array = ensure_array_like(buttons);
      for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
        let btn = each_array[$$index];
        $$renderer2.push(`<button${attr_class(`p-1.5 rounded-md transition-all duration-200 relative group ${stringify(activeDirection === btn.id ? "bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400 shadow-sm ring-1 ring-indigo-200 dark:ring-indigo-800" : "text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800")}`)}${attr("title", btn.label)}>`);
        if (btn.id === "left") {
          $$renderer2.push("<!--[-->");
          Arrow_left($$renderer2, { size: 14, strokeWidth: 2.5 });
        } else {
          $$renderer2.push("<!--[!-->");
          if (btn.id === "right") {
            $$renderer2.push("<!--[-->");
            Arrow_right($$renderer2, { size: 14, strokeWidth: 2.5 });
          } else {
            $$renderer2.push("<!--[!-->");
            if (btn.id === "up") {
              $$renderer2.push("<!--[-->");
              Arrow_up($$renderer2, { size: 14, strokeWidth: 2.5 });
            } else {
              $$renderer2.push("<!--[!-->");
              if (btn.id === "down") {
                $$renderer2.push("<!--[-->");
                Arrow_down($$renderer2, { size: 14, strokeWidth: 2.5 });
              } else {
                $$renderer2.push("<!--[!-->");
                Move($$renderer2, { size: 14, strokeWidth: 2.5 });
              }
              $$renderer2.push(`<!--]-->`);
            }
            $$renderer2.push(`<!--]-->`);
          }
          $$renderer2.push(`<!--]-->`);
        }
        $$renderer2.push(`<!--]--></button>`);
      }
      $$renderer2.push(`<!--]--></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<div class="flex items-center gap-2 text-xs text-amber-600 dark:text-amber-500 bg-amber-50 dark:bg-amber-900/20 px-3 py-1 rounded-full border border-amber-100 dark:border-amber-900/30">`);
      Info($$renderer2, { size: 12 });
      $$renderer2.push(`<!----> <span>Graphviz uses global rankdir</span></div>`);
    }
    $$renderer2.push(`<!--]--></div>  <div class="h-10 flex items-center px-4 gap-2 border-l border-gray-200 dark:border-gray-800"><div class="flex items-center gap-1 bg-gray-100 dark:bg-gray-800 rounded-lg p-0.5 mr-2"><button${attr_class(`p-1 px-2 text-[10px] font-bold rounded transition-all ${stringify(diagramStore.code.includes("left to right direction") || diagramStore.layoutParams.rankdir === "LR" ? "text-gray-500" : "bg-white dark:bg-gray-700 text-indigo-600 shadow-sm")}`)} title="Top-Down Layout">TB</button> <button${attr_class(`p-1 px-2 text-[10px] font-bold rounded transition-all ${stringify(diagramStore.code.includes("left to right direction") || diagramStore.layoutParams.rankdir === "LR" ? "bg-white dark:bg-gray-700 text-indigo-600 shadow-sm" : "text-gray-500")}`)} title="Left-Right Layout">LR</button></div> `);
    ColorPicker($$renderer2);
    $$renderer2.push(`<!----> <button class="p-1.5 rounded-md text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 transition-colors relative group" title="Copy Live Share URL"><div id="share-btn-icon" class="transition-colors duration-300">`);
    Link($$renderer2, {
      size: (
        // Simple toast feedback could go here, or changing icon temporarily
        // green
        16
      ),
      strokeWidth: 2
    });
    $$renderer2.push(`<!----></div> <span class="absolute top-full right-0 mt-2 px-2 py-1 bg-slate-800 text-white text-xs rounded opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50 transition-opacity">Copy Link</span></button></div></div>`);
  });
}
function Editor($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { code = "", mode = "plantuml", onRender, onCursorChange } = $$props;
    new Compartment();
    new Compartment();
    let activeArrows = [];
    let activeDirection = null;
    onDestroy(() => {
    });
    function scrollToLine(line) {
      return;
    }
    $$renderer2.push(`<div class="h-full flex flex-col overflow-hidden bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-800">`);
    EditorToolbar($$renderer2, {
      mode: diagramStore.mode,
      activeDirection,
      hasArrows: activeArrows.length > 0
    });
    $$renderer2.push(`<!----> <div class="flex-1 w-full overflow-hidden outline-none" role="textbox" tabindex="0"></div></div>`);
    bind_props($$props, { code, scrollToLine });
  });
}
function validatePlantUML(code) {
  const errors = [];
  const warnings = [];
  const lines = code.split("\n");
  let hasStart = false;
  let hasEnd = false;
  lines.forEach((line, i) => {
    const trimmed = line.trim();
    const lineNum = i + 1;
    if (trimmed.startsWith("@startuml")) {
      if (hasStart) {
        errors.push({ line: lineNum, message: "Duplicate @startuml declaration", type: "structure" });
      }
      hasStart = true;
    }
    if (trimmed.startsWith("@enduml")) {
      if (!hasStart) {
        errors.push({ line: lineNum, message: "@enduml without matching @startuml", type: "structure" });
      }
      hasEnd = true;
    }
    if (trimmed.includes("->") && !trimmed.includes(":") && !trimmed.startsWith("@") && !trimmed.startsWith("'")) {
      warnings.push({ line: lineNum, message: "Arrow without message text (consider adding description)" });
    }
    const openBrackets = (trimmed.match(/{/g) || []).length;
    const closeBrackets = (trimmed.match(/}/g) || []).length;
    if (openBrackets !== closeBrackets && !trimmed.endsWith("{") && !trimmed.startsWith("}")) ;
  });
  if (!hasStart && code.trim().length > 0) {
    errors.push({ line: 1, message: "Missing @startuml declaration", type: "structure" });
  }
  if (hasStart && !hasEnd) {
    errors.push({ line: lines.length, message: "Missing @enduml declaration", type: "structure" });
  }
  return {
    isValid: errors.length === 0,
    errors,
    warnings
  };
}
function validateGraphviz(code) {
  const errors = [];
  const warnings = [];
  const lines = code.split("\n");
  let hasGraph = false;
  let braceCount = 0;
  lines.forEach((line, i) => {
    const trimmed = line.trim();
    const lineNum = i + 1;
    if (trimmed.match(/^(strict\s+)?(di)?graph\s+/i)) {
      hasGraph = true;
    }
    braceCount += (trimmed.match(/{/g) || []).length;
    braceCount -= (trimmed.match(/}/g) || []).length;
    if (trimmed.includes("->") && !trimmed.includes("digraph") && code.includes("graph ") && !code.includes("digraph")) {
      errors.push({ line: lineNum, message: "Using -> (directed edge) in undirected graph. Use -- instead.", type: "syntax" });
    }
    if (trimmed.length > 0 && !trimmed.endsWith(";") && !trimmed.endsWith("{") && !trimmed.endsWith("}") && !trimmed.startsWith("//") && !trimmed.startsWith("#")) {
      warnings.push({ line: lineNum, message: "Statement may be missing semicolon" });
    }
  });
  if (!hasGraph && code.trim().length > 0) {
    errors.push({ line: 1, message: "Missing graph or digraph declaration", type: "structure" });
  }
  if (braceCount !== 0) {
    errors.push({ line: lines.length, message: `Unbalanced braces (${braceCount > 0 ? "missing closing" : "extra closing"})`, type: "syntax" });
  }
  return {
    isValid: errors.length === 0,
    errors,
    warnings
  };
}
function validateDiagram(code, mode) {
  if (!code.trim()) {
    return { isValid: true, errors: [], warnings: [] };
  }
  if (mode === "plantuml") {
    return validatePlantUML(code);
  } else {
    return validateGraphviz(code);
  }
}
function Minimap($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const MINIMAP_W = 240;
    const MINIMAP_H = 160;
    let contentRect = { w: 2e3, h: 2e3, x: 0, y: 0 };
    let viewport = { w: 0, h: 0 };
    let mapScale = (() => {
      const sx = MINIMAP_W / contentRect.w;
      const sy = MINIMAP_H / contentRect.h;
      return Math.min(sx, sy);
    })();
    let offsetX = (MINIMAP_W - contentRect.w * mapScale) / 2;
    let offsetY = (MINIMAP_H - contentRect.h * mapScale) / 2;
    let rectProps = (() => {
      const s = diagramStore.scale;
      (-diagramStore.pan.x + viewport.w / 2) / s;
      const cx = contentRect.x + contentRect.w / 2 - diagramStore.pan.x / s;
      const cy = contentRect.y + contentRect.h / 2 - diagramStore.pan.y / s;
      const vw = viewport.w / s;
      const vh = viewport.h / s;
      const x = cx - vw / 2;
      const y = cy - vh / 2;
      return {
        x: offsetX + (x - contentRect.x) * mapScale,
        y: offsetY + (y - contentRect.y) * mapScale,
        w: vw * mapScale,
        h: vh * mapScale
      };
    })();
    $$renderer2.push(`<div class="absolute top-4 right-4 w-[240px] h-[160px] bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg shadow-xl overflow-hidden opacity-90 transition-opacity z-20 hidden md:block select-none"><div class="absolute inset-0 flex items-center justify-center p-2 opacity-30 pointer-events-none">`);
    if (diagramStore.svg) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`${html(diagramStore.svg.replace(/width="[^"]*"/, 'width="100%"').replace(/height="[^"]*"/, 'height="100%"'))}`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--></div> <div class="absolute border-2 border-indigo-500 bg-indigo-500/10 cursor-move shadow-sm"${attr_style(` left: ${stringify(rectProps.x)}px; top: ${stringify(rectProps.y)}px; width: ${stringify(rectProps.w)}px; height: ${stringify(rectProps.h)}px; `)}></div></div>`);
  });
}
function analyzeDiagram(code, mode) {
  const results = [];
  const layers = {};
  const allTags = /* @__PURE__ */ new Set();
  code.toLowerCase();
  const adj = {};
  const degrees = {};
  const nodes = /* @__PURE__ */ new Set();
  const definitions = /* @__PURE__ */ new Set();
  const lines = code.split("\n");
  lines.forEach((line, idx) => {
    const trimmed = line.trim();
    const tagMatch = line.match(/(?:'|#|\/\/)\s*@tag:\s*([a-zA-Z0-9_, ]+)/) || line.match(/!pragma\s+tag:\s*([a-zA-Z0-9_, ]+)/);
    if (tagMatch) {
      const tags = tagMatch[1].split(/[,\s]+/).filter((t) => t);
      tags.forEach((t) => allTags.add(t));
      let idMatch = trimmed.match(/^(?:class|interface|component|node|rectangle|storage|database)\s+([a-zA-Z0-9_]+)/i);
      if (!idMatch && mode === "graphviz") {
        idMatch = trimmed.match(/^\s*([a-zA-Z0-9_]+)\s*\[/);
      }
      const idsFound = [];
      if (idMatch) idsFound.push(idMatch[1]);
      const arrowMatch2 = line.match(/([a-zA-Z0-9_]+)\s*-+>\s*([a-zA-Z0-9_]+)/);
      if (arrowMatch2) {
        idsFound.push(arrowMatch2[1]);
        idsFound.push(arrowMatch2[2]);
      }
      if (idsFound.length > 0) {
        idsFound.forEach((id) => {
          if (!layers[id]) layers[id] = [];
          tags.forEach((t) => {
            if (!layers[id].includes(t)) layers[id].push(t);
          });
        });
      }
    }
    if (!trimmed || trimmed.startsWith("'") || trimmed.startsWith("#") || trimmed.startsWith("//")) return;
    if (mode === "plantuml") {
      const defMatch = trimmed.match(/^(?:class|interface|component|node|rectangle|storage|database)\s+([a-zA-Z0-9_]+)/i);
      if (defMatch) {
        const id = defMatch[1];
        if (definitions.has(id)) {
          results.push({
            severity: "info",
            message: `Duplicate definition for '${id}'`,
            line: idx + 1
          });
        } else {
          definitions.add(id);
        }
        nodes.add(id);
        if (!degrees[id]) degrees[id] = 0;
      }
    }
    const addEdge = (src, tgt) => {
      if (!adj[src]) adj[src] = [];
      adj[src].push(tgt);
      nodes.add(src);
      nodes.add(tgt);
      degrees[src] = (degrees[src] || 0) + 1;
      degrees[tgt] = (degrees[tgt] || 0) + 1;
    };
    const arrowMatch = line.match(/([a-zA-Z0-9_]+)\s*-+>\s*([a-zA-Z0-9_]+)/);
    if (arrowMatch) {
      addEdge(arrowMatch[1], arrowMatch[2]);
    }
  });
  const visited = /* @__PURE__ */ new Set();
  const recStack = /* @__PURE__ */ new Set();
  function hasCycle(node, path) {
    if (recStack.has(node)) return [...path, node];
    if (visited.has(node)) return null;
    visited.add(node);
    recStack.add(node);
    path.push(node);
    if (adj[node]) {
      for (const neighbor of adj[node]) {
        const cycle = hasCycle(neighbor, path);
        if (cycle) return cycle;
      }
    }
    recStack.delete(node);
    path.pop();
    return null;
  }
  for (const node of nodes) {
    if (!visited.has(node)) {
      const cyclePath = hasCycle(node, []);
      if (cyclePath) {
        const cycleStart = cyclePath[cyclePath.length - 1];
        const cleanCycle = cyclePath.slice(cyclePath.indexOf(cycleStart));
        if (cleanCycle.length > 1) {
          results.push({
            severity: "warning",
            message: `Cycle detected: ${cleanCycle.join(" -> ")}`
          });
          break;
        }
      }
    }
  }
  const ignored = /* @__PURE__ */ new Set(["start", "stop", "end", "top", "bottom", "left", "right", "up", "down"]);
  nodes.forEach((node) => {
    if (degrees[node] === 0 && !definitions.has(node) && !ignored.has(node.toLowerCase())) {
      results.push({
        severity: "info",
        message: `Disconnected node: '${node}'`
      });
    } else if (degrees[node] === 0 && definitions.has(node)) {
      results.push({
        severity: "info",
        message: `Disconnected component: '${node}'`
      });
    }
  });
  return {
    lints: results,
    layers,
    allTags: Array.from(allTags).sort()
  };
}
const lintDiagram = (code, mode) => analyzeDiagram(code, mode).lints;
function Preview($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { svg, isRendering } = $$props;
    let validation = validateDiagram(diagramStore.code, diagramStore.mode);
    $$renderer2.push(`<div${attr_class(
      `relative flex-1 h-full overflow-hidden bg-gray-50 dark:bg-gray-900/50 cursor-grab select-none grid-bg transition-colors ${stringify(
        // ... imports
        // Run Analysis to get Layers
        // We only want to update store if layers changed to avoid loops
        // But store.availableLayers is primitive string[], so simple compare
        // ... existing Mouse/Wheel handlers ...
        // Updated Effect for styling
        // Re-run analysis for local lookup (or use store if we pushed map there)
        // Store only has list of layers, not map of id->layers.
        // Let's re-run analysis locally for the map, it's fast.
        // ... (existing adjacency build) ...
        // ... (keep existing) ...
        // Check active layers
        // Layer Visibility Check
        // If element has tags, must match at least one active layer?
        // Or if ANY tags exist, must match?
        // Logic:
        // 1. If filtering is ON (activeLayers > 0):
        //    - If node has tags: Show if intersection > 0
        //    - If node has NO tags: Show (default) or Hide?
        //    Usually "Show only X" implies hiding untagged?
        //    Let's go with: If activeLayers is set, ONLY show elements in those layers?
        //    But many elements are untagged.
        //    Better: "Highlight Mode". Dim others.
        // If node is tagged, it MUST be in active set to be fully visible
        // If it shares NO tags with active set, it is dimmed/hidden.
        // Untagged nodes:
        // If we are filtering, maybe we hide untagged too?
        // Let's keep untagged visible for context, unless strictly "Layer Mode".
        // Let's make untagged = context = dimmed?
        // Implementation: If tags exist in diagram, and activeLayers is set,
        // untagged items are dimmed.
        // "StrictMode" filtering
        // ... (keep transform logic) ...
        // Opacity Logic:
        // 1. Layer Filter (Strongest)
        // 2. Focus Mode
        // Almost invisible
        // Dim background
        diagramStore.previewTheme === "dark" ? "dark-preview" : ""
      )}`,
      "svelte-e9vu3z"
    )} role="presentation"><div class="absolute inset-0 pointer-events-none z-10 bg-[radial-gradient(circle_at_center,transparent_50%,rgba(0,0,0,0.03)_100%)] dark:bg-[radial-gradient(circle_at_center,transparent_50%,rgba(0,0,0,0.2)_100%)]"></div> <div class="absolute w-full h-full flex items-center justify-center origin-center transition-transform duration-75"${attr_style(`transform: translate(${stringify(diagramStore.pan.x)}px, ${stringify(diagramStore.pan.y)}px) scale(${stringify(diagramStore.scale)}); --preview-font: ${stringify(diagramStore.fontFamily)}`)}>${html(svg)}</div> <div class="absolute bottom-4 right-4 flex gap-2 bg-white dark:bg-gray-800 p-2 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700"><span class="text-xs font-mono flex items-center px-2 text-gray-500">${escape_html(Math.round(diagramStore.scale * 100))}%</span> <button class="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded text-gray-500" title="Zoom Out">`);
    Zoom_out($$renderer2, { size: 16 });
    $$renderer2.push(`<!----></button> <button class="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded text-gray-500" title="Zoom In">`);
    Zoom_in($$renderer2, { size: 16 });
    $$renderer2.push(`<!----></button> <button${attr_class(`p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded transition-colors ${stringify("text-gray-500")}`)} title="Copy SVG">`);
    {
      $$renderer2.push("<!--[!-->");
      Copy($$renderer2, { size: 16 });
    }
    $$renderer2.push(`<!--]--></button> <button class="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded text-gray-500" title="Reset View">`);
    Maximize($$renderer2, { size: 16 });
    $$renderer2.push(`<!----></button> <div class="w-px h-4 bg-gray-200 dark:bg-gray-700 mx-1"></div> <button${attr_class(`p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded transition-colors ${stringify(diagramStore.focusMode ? "text-indigo-500 bg-indigo-50 dark:bg-indigo-900/20" : "text-gray-500")}`)} title="Focus Mode (Highlight Connections)">`);
    Target($$renderer2, { size: 16 });
    $$renderer2.push(`<!----></button> `);
    if (diagramStore.availableLayers.length > 0) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="relative group"><button class="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded text-gray-500 flex items-center gap-1" title="Filter Layers">`);
      Layers($$renderer2, {
        size: 16,
        class: diagramStore.activeLayers.length > 0 ? "text-indigo-500" : ""
      });
      $$renderer2.push(`<!----></button> <div class="absolute bottom-full right-0 mb-2 w-48 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg shadow-xl p-2 hidden group-hover:block z-50"><div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2 px-2">Visible Layers</div> <!--[-->`);
      const each_array = ensure_array_like(diagramStore.availableLayers);
      for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
        let layer = each_array[$$index];
        $$renderer2.push(`<button${attr_class(`w-full text-left px-2 py-1.5 text-xs rounded hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center justify-between ${stringify(diagramStore.activeLayers.includes(layer) ? "text-indigo-600 dark:text-indigo-400 font-medium" : "text-slate-600 dark:text-slate-400")}`)}><span>${escape_html(layer)}</span> `);
        if (diagramStore.activeLayers.includes(layer)) {
          $$renderer2.push("<!--[-->");
          Eye($$renderer2, { size: 12 });
        } else {
          $$renderer2.push("<!--[!-->");
          Eye_off($$renderer2, { size: 12, class: "opacity-50" });
        }
        $$renderer2.push(`<!--]--></button>`);
      }
      $$renderer2.push(`<!--]--> <div class="border-t border-slate-100 dark:border-slate-700 mt-2 pt-1"><button class="w-full text-center text-[10px] text-slate-400 hover:text-indigo-500 p-1">Reset Filter</button></div></div></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--></div> `);
    if (isRendering) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="absolute inset-0 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm flex flex-col items-center justify-center z-10 transition-opacity">`);
      Loader_circle($$renderer2, { class: "animate-spin text-indigo-500 mb-2", size: 32 });
      $$renderer2.push(`<!----> <span class="text-sm text-gray-500">Rendering...</span></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> `);
    if (svg && !isRendering) {
      $$renderer2.push("<!--[-->");
      Minimap($$renderer2);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> `);
    if (!svg && !isRendering) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="absolute inset-0 flex items-center justify-center text-gray-400"><div class="text-center"><p class="text-lg">No Diagram Rendered</p> <p class="text-sm">Press Ctrl+Enter to render</p></div></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> `);
    if (diagramStore.code.trim() && !isRendering) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="absolute bottom-4 left-4 flex flex-col gap-2 items-start z-20 pointer-events-none">`);
      if (!validation.isValid) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<!--[-->`);
        const each_array_1 = ensure_array_like(validation.errors);
        for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
          let error = each_array_1[$$index_1];
          $$renderer2.push(`<div class="px-3 py-1.5 bg-rose-50 dark:bg-rose-900/30 text-rose-600 dark:text-rose-400 text-xs font-medium rounded-lg border border-rose-200 dark:border-rose-800 flex items-center gap-2 shadow-sm">`);
          Circle_alert($$renderer2, { size: 14 });
          $$renderer2.push(`<!----> <span>L${escape_html(error.line)}: ${escape_html(error.message)}</span></div>`);
        }
        $$renderer2.push(`<!--]-->`);
      } else {
        $$renderer2.push("<!--[!-->");
        if (validation.warnings.length > 0) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<div class="px-3 py-1.5 bg-amber-50 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 text-xs font-medium rounded-lg border border-amber-200 dark:border-amber-800 flex items-center gap-2 shadow-sm">`);
          Circle_alert($$renderer2, { size: 14 });
          $$renderer2.push(`<!----> <span>${escape_html(validation.warnings.length)} warning(s)</span></div>`);
        } else {
          $$renderer2.push("<!--[!-->");
          $$renderer2.push(`<div class="px-3 py-1.5 bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 text-xs font-medium rounded-lg border border-emerald-200 dark:border-emerald-800 flex items-center gap-2 shadow-sm">`);
          Circle_check($$renderer2, { size: 14 });
          $$renderer2.push(`<!----> <span>Syntax OK</span></div>`);
        }
        $$renderer2.push(`<!--]-->`);
      }
      $$renderer2.push(`<!--]--></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--></div>`);
  });
}
function PropertyRow($$renderer, $$props) {
  let { label, children } = $$props;
  $$renderer.push(`<div class="space-y-1.5 hover:bg-gray-50 dark:hover:bg-indigo-900/10 p-1 rounded-lg transition-colors group"><div class="flex justify-between items-center text-xs"><label class="text-gray-500 dark:text-gray-400 font-medium group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">${escape_html(label)}</label></div> <div class="text-gray-700 dark:text-gray-300">`);
  children($$renderer);
  $$renderer.push(`<!----></div></div>`);
}
function Inspector($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { isPinned = false } = $$props;
    diagramStore.selectedElementId ? diagramStore.overrides[diagramStore.selectedElementId] || {} : {};
    $$renderer2.push(`<aside class="bg-white/90 dark:bg-gray-900/90 backdrop-blur-xl border border-white/20 dark:border-white/10 flex flex-col w-80 shadow-2xl z-20 m-4 ml-0 rounded-2xl"><div class="p-4 border-b border-white/10 dark:border-white/5 flex items-center justify-between bg-gradient-to-b from-white/50 to-transparent dark:from-white/5 dark:to-transparent"><div class="flex items-center gap-2"><div class="w-2 h-2 rounded-full bg-indigo-500 shadow-[0_0_10px_rgba(99,102,241,0.5)] animate-pulse"></div> <h3 class="text-[10px] font-extrabold uppercase tracking-widest text-indigo-900/50 dark:text-indigo-100/50">Control Deck</h3></div> <div class="flex items-center gap-1">`);
    if (diagramStore.selectedElementId) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<button${attr_class(`p-1 px-2 rounded-lg ${stringify(diagramStore.multiSelection.length > 0 ? "bg-indigo-600 text-white shadow-glow-sm" : "bg-indigo-500/10 text-indigo-500 dark:text-indigo-400")} hover:bg-indigo-500/20 text-[9px] font-bold flex items-center gap-1 transition-all`)} title="Select all nodes with similar properties">`);
      Search($$renderer2, { size: 10, strokeWidth: 3 });
      $$renderer2.push(`<!----> ${escape_html(diagramStore.multiSelection.length > 0 ? `${diagramStore.multiSelection.length} selected` : "Similar")}</button>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> <button class="p-1 hover:bg-black/5 dark:hover:bg-white/10 rounded-lg text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 transition-colors">`);
    X($$renderer2, { size: 16 });
    $$renderer2.push(`<!----></button></div></div> `);
    if (diagramStore.selectedElementId) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="flex-1 overflow-y-auto p-4 space-y-6 scrollbar-thin">`);
      if (diagramStore.mode === "graphviz") {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<button${attr_class(`w-full p-3 rounded-xl border flex items-center justify-between transition-all group/focus overflow-hidden relative ${stringify(diagramStore.focusMode ? "bg-indigo-500/10 border-indigo-500/50 text-indigo-500" : "bg-gray-50/50 dark:bg-gray-800/30 border-gray-200/50 dark:border-gray-700/50 text-gray-400")}`)}>`);
        if (diagramStore.focusMode) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<div class="absolute inset-0 bg-indigo-500/10 animate-pulse-soft"></div>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--> <div class="flex items-center gap-2 relative z-10">`);
        if (diagramStore.focusMode) {
          $$renderer2.push("<!--[-->");
          Eye($$renderer2, { size: 14, class: "drop-shadow-sm" });
        } else {
          $$renderer2.push("<!--[!-->");
          Eye_off($$renderer2, { size: 14 });
        }
        $$renderer2.push(`<!--]--> <span class="text-[10px] font-bold uppercase tracking-widest">Neighborhood Focus</span></div></button>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> <div><h4 class="text-[10px] uppercase font-extrabold tracking-widest text-gray-400/80 mb-2 pl-1">Context</h4></div> <div class="flex p-1 bg-gray-100/50 dark:bg-gray-800/50 rounded-xl border border-gray-200/50 dark:border-gray-700/50 relative"><div class="absolute inset-y-1 w-[calc(50%-4px)] bg-white dark:bg-gray-700 rounded-lg shadow-sm transition-all duration-300 ease-out"${attr_style(`left: ${stringify("4px")}`)}></div> <button${attr_class(`flex-1 px-4 py-1.5 text-xs font-bold flex items-center justify-center gap-2 transition-colors relative z-10 ${stringify(
        "text-gray-900 dark:text-white"
      )}`)}>`);
      Info($$renderer2, { size: 14 });
      $$renderer2.push(`<!----> Properties</button> <button${attr_class(`flex-1 px-4 py-1.5 text-xs font-bold flex items-center justify-center gap-2 transition-colors relative z-10 ${stringify("text-gray-500 hover:text-gray-700 dark:hover:text-gray-300")}`)}>`);
      Sparkles($$renderer2, { size: 14 });
      $$renderer2.push(`<!----> AI Insight</button></div> `);
      {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="space-y-6 flex-1 animate-fade-in"><div class="flex items-center gap-3 p-3 bg-white/50 dark:bg-gray-800/30 rounded-xl border border-gray-100 dark:border-gray-700/50"><div class="p-2.5 bg-gradient-to-br from-indigo-50 to-indigo-100 dark:from-indigo-900/50 dark:to-indigo-800/50 rounded-lg text-indigo-600 dark:text-indigo-400 shadow-inner">`);
        Box($$renderer2, { size: 20 });
        $$renderer2.push(`<!----></div> <div class="min-w-0"><h3 class="font-bold text-sm text-gray-900 dark:text-white truncate">${escape_html(diagramStore.selectedElementId)}</h3> <p class="text-[10px] font-mono text-gray-500 dark:text-gray-400 mt-0.5">${escape_html(diagramStore.selectedElementType || "Unknown Element")}</p></div></div> <div class="space-y-3"><h4 class="text-[10px] font-extrabold text-gray-400/80 uppercase tracking-widest pl-1">Appearance</h4> <div class="bg-white/30 dark:bg-gray-800/20 rounded-xl p-3 border border-gray-100/50 dark:border-gray-700/50 space-y-4">`);
        PropertyRow($$renderer2, {
          label: "Color",
          children: ($$renderer3) => {
            $$renderer3.push(`<div class="flex gap-2"><!--[-->`);
            const each_array = ensure_array_like(["#ef4444", "#f59e0b", "#10b981", "#3b82f6", "#8b5cf6"]);
            for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
              let color = each_array[$$index];
              $$renderer3.push(`<button class="w-6 h-6 rounded-full border-2 border-white dark:border-gray-700 shadow-sm hover:scale-110 hover:shadow-glow-sm transition-all"${attr_style(`background-color: ${stringify(color)}`)}${attr("aria-label", `Set color ${stringify(color)}`)}></button>`);
            }
            $$renderer3.push(`<!--]--></div>`);
          }
        });
        $$renderer2.push(`<!----> <div class="w-full h-px bg-gray-200/50 dark:bg-gray-700/50"></div> `);
        PropertyRow($$renderer2, {
          label: "Shape",
          children: ($$renderer3) => {
            $$renderer3.push(`<select class="w-full h-8 text-xs bg-white/50 dark:bg-gray-900/50 border border-gray-200 dark:border-gray-700 rounded-lg px-2 text-gray-700 dark:text-gray-200 focus:ring-2 focus:ring-indigo-500/20 outline-none">`);
            $$renderer3.option({ value: "" }, ($$renderer4) => {
              $$renderer4.push(`Default`);
            });
            $$renderer3.option({ value: "rectangle" }, ($$renderer4) => {
              $$renderer4.push(`Rectangle`);
            });
            $$renderer3.option({ value: "cloud" }, ($$renderer4) => {
              $$renderer4.push(`Cloud`);
            });
            $$renderer3.option({ value: "database" }, ($$renderer4) => {
              $$renderer4.push(`Database`);
            });
            $$renderer3.option({ value: "node" }, ($$renderer4) => {
              $$renderer4.push(`Node`);
            });
            $$renderer3.push(`</select>`);
          }
        });
        $$renderer2.push(`<!----></div></div> <div class="space-y-3"><h4 class="text-[10px] font-extrabold text-gray-400/80 uppercase tracking-widest pl-1">Typography</h4> <div class="bg-white/30 dark:bg-gray-800/20 rounded-xl p-3 border border-gray-100/50 dark:border-gray-700/50 space-y-4">`);
        PropertyRow($$renderer2, {
          label: "Label",
          children: ($$renderer3) => {
            $$renderer3.push(`<input type="text" class="w-full h-8 text-xs bg-white/50 dark:bg-gray-900/50 border border-gray-200 dark:border-gray-700 rounded-lg px-2 text-gray-700 dark:text-gray-200 focus:ring-2 focus:ring-indigo-500/20 outline-none" placeholder="Element label..."/>`);
          }
        });
        $$renderer2.push(`<!----></div></div></div>`);
      }
      $$renderer2.push(`<!--]--> <div class="pt-4"><button class="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-xs font-bold text-gray-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/10 transition-all border border-dashed border-gray-200 dark:border-gray-700 hover:border-red-200 dark:hover:border-red-900/30 group">`);
      Trash_2($$renderer2, {
        size: 14,
        class: "group-hover:scale-110 transition-transform"
      });
      $$renderer2.push(`<!----> Reset Selection</button></div></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<div class="flex-1 flex flex-col items-center justify-center p-8 text-center text-gray-300 dark:text-gray-700"><div class="w-20 h-20 rounded-full bg-gradient-to-b from-gray-50 to-gray-100 dark:from-gray-800/50 dark:to-gray-800/30 flex items-center justify-center mb-6 shadow-inner">`);
      Mouse_pointer_2($$renderer2, { size: 32, class: "opacity-30 text-indigo-500" });
      $$renderer2.push(`<!----></div> <p class="text-sm font-bold text-gray-500 dark:text-gray-400">No Selection</p> <p class="text-[11px] mt-2 leading-relaxed text-gray-400 max-w-[180px]">Select any node or edge in the diagram to access advanced
                controls.</p></div>`);
    }
    $$renderer2.push(`<!--]--> <div class="p-4 border-t border-white/10 dark:border-white/5 bg-gray-50/30 dark:bg-gray-900/30 flex justify-center backdrop-blur-sm rounded-b-2xl"><label class="flex items-center gap-2 cursor-pointer group select-none"><input type="checkbox"${attr("checked", isPinned, true)} class="sr-only"/> <div${attr_class(`w-9 h-5 bg-gray-200 dark:bg-gray-700 rounded-full relative transition-all duration-300 ${stringify(isPinned ? "bg-indigo-500 shadow-glow-sm" : "")}`)}><div${attr_class(`absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full shadow-sm transition-transform duration-300 ${stringify(isPinned ? "translate-x-4" : "")}`)}></div></div> <span class="text-[10px] font-bold text-gray-400 group-hover:text-indigo-500 transition-colors uppercase tracking-widest">Pin Deck</span></label></div></aside>`);
    bind_props($$props, { isPinned });
  });
}
function SnippetModal($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { isOpen = false, onClose } = $$props;
    let newSnippetName = "";
    if (isOpen) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"><div class="bg-white dark:bg-gray-800 rounded-xl shadow-2xl w-full max-w-lg flex flex-col max-h-[80vh] overflow-hidden"><div class="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700"><h3 class="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2">`);
      File_code($$renderer2, { size: 20, class: "text-indigo-500" });
      $$renderer2.push(`<!----> Snippet Library</h3> <button class="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">`);
      X($$renderer2, { size: 20 });
      $$renderer2.push(`<!----></button></div> <div class="flex-1 overflow-y-auto p-4 space-y-6"><div class="bg-gray-50 dark:bg-gray-900/50 p-4 rounded-lg border border-gray-200 dark:border-gray-700"><label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Save current diagram as snippet</label> <div class="flex gap-2"><input type="text"${attr("value", newSnippetName)} placeholder="Snippet Name..." class="flex-1 px-3 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"/> <button class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg flex items-center gap-2 font-medium disabled:opacity-50"${attr("disabled", !newSnippetName.trim(), true)}>`);
      Save($$renderer2, { size: 18 });
      $$renderer2.push(`<!----> Save</button></div></div> <div><h4 class="text-sm font-medium text-gray-500 mb-3 uppercase tracking-wider">Saved Snippets (${escape_html(diagramStore.snippets.length)})</h4> `);
      if (diagramStore.snippets.length === 0) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="text-center py-8 text-gray-400 border-2 border-dashed border-gray-200 dark:border-gray-700 rounded-lg">No snippets saved yet.</div>`);
      } else {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push(`<div class="space-y-2"><!--[-->`);
        const each_array = ensure_array_like(diagramStore.snippets);
        for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
          let snippet = each_array[$$index];
          $$renderer2.push(`<div class="flex items-center justify-between p-3 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg hover:border-indigo-300 dark:hover:border-indigo-700 group transition-colors"><div class="flex flex-col"><span class="font-medium text-gray-900 dark:text-white">${escape_html(snippet.name)}</span> <span class="text-xs text-gray-500">${escape_html(snippet.mode === "plantuml" ? "PlantUML" : "Graphviz")} • ${escape_html(new Date(snippet.timestamp).toLocaleDateString())}</span></div> <div class="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity"><button class="p-2 text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 rounded-lg" title="Load">`);
          Upload($$renderer2, { size: 18 });
          $$renderer2.push(`<!----></button> <button class="p-2 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/30 rounded-lg" title="Delete">`);
          Trash_2($$renderer2, { size: 18 });
          $$renderer2.push(`<!----></button></div></div>`);
        }
        $$renderer2.push(`<!--]--></div>`);
      }
      $$renderer2.push(`<!--]--></div></div></div></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
    bind_props($$props, { isOpen });
  });
}
function ExportModal($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { isOpen = false, onClose } = $$props;
    let format = "png";
    let scale = 2;
    let includeWatermark = false;
    const SCALES = [1, 2, 3, 4];
    if (isOpen) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" role="button" tabindex="0"><div class="bg-white dark:bg-gray-800 rounded-xl shadow-2xl w-full max-w-md overflow-hidden" role="document" tabindex="-1"><div class="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700"><h3 class="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2">`);
      Download($$renderer2, { size: 20, class: "text-indigo-500" });
      $$renderer2.push(`<!----> Export Diagram</h3> <button class="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">`);
      X($$renderer2, { size: 20 });
      $$renderer2.push(`<!----></button></div> <div class="p-6 space-y-6"><div role="group" aria-labelledby="format-label"><span id="format-label" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">Format</span> <div class="grid grid-cols-2 gap-3"><button${attr_class(`flex flex-col items-center gap-2 p-4 rounded-lg border-2 transition-all ${stringify("border-gray-200 dark:border-gray-700 text-gray-400 hover:border-gray-300")}`)}>`);
      File_type($$renderer2, { size: 24 });
      $$renderer2.push(`<!----> <span class="text-sm font-medium">SVG</span></button> <button${attr_class(`flex flex-col items-center gap-2 p-4 rounded-lg border-2 transition-all ${stringify(
        "border-indigo-500 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600"
      )}`)}>`);
      Image($$renderer2, { size: 24 });
      $$renderer2.push(`<!----> <span class="text-sm font-medium">PNG</span></button> <button${attr_class(`flex flex-col items-center gap-2 p-4 rounded-lg border-2 transition-all ${stringify("border-gray-200 dark:border-gray-700 text-gray-400 hover:border-gray-300")}`)}>`);
      File_image($$renderer2, { size: 24 });
      $$renderer2.push(`<!----> <span class="text-sm font-medium">JPG</span></button> <button${attr_class(`flex flex-col items-center gap-2 p-4 rounded-lg border-2 transition-all ${stringify("border-gray-200 dark:border-gray-700 text-gray-400 hover:border-gray-300")}`)}>`);
      File_text($$renderer2, { size: 24 });
      $$renderer2.push(`<!----> <span class="text-sm font-medium">PDF</span></button></div></div> `);
      {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div role="group" aria-labelledby="scale-label"><span id="scale-label" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">Scale (for high-res export)</span> <div class="flex gap-3"><!--[-->`);
        const each_array = ensure_array_like(SCALES);
        for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
          let s = each_array[$$index];
          $$renderer2.push(`<button${attr_class(`flex-1 py-2 rounded-lg border-2 font-medium transition-all ${stringify(scale === s ? "border-indigo-500 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600" : "border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-400 hover:border-gray-300")}`)}>${escape_html(s)}x</button>`);
        }
        $$renderer2.push(`<!--]--></div> <p class="mt-2 text-xs text-gray-500">Higher scale = larger file, better quality for
                            print.</p></div>`);
      }
      $$renderer2.push(`<!--]--> `);
      {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="pt-4 border-t border-gray-100 dark:border-gray-700"><label class="flex items-center gap-2 cursor-pointer mb-3"><input type="checkbox"${attr("checked", includeWatermark, true)} class="w-4 h-4 text-indigo-600 rounded border-gray-300 focus:ring-indigo-500"/> <span class="text-sm font-medium text-gray-700 dark:text-gray-300">Include Watermark</span></label> `);
        {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--></div>`);
      }
      $$renderer2.push(`<!--]--></div> <div class="p-4 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50"><button class="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-medium flex items-center justify-center gap-2 transition-colors">`);
      Download($$renderer2, { size: 18 });
      $$renderer2.push(`<!----> Export as ${escape_html(format.toUpperCase())}
                    ${escape_html(` (${scale}x)`)}</button></div></div></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
    bind_props($$props, { isOpen });
  });
}
const TEMPLATES = [
  // --- STRUCTURE (Static) ---
  {
    id: "puml-class",
    name: "Class Diagram",
    mode: "plantuml",
    category: "UML: Structure",
    code: `@startuml
skinparam classAttributeIconSize 0

abstract class Animal {
    - name: String
    - age: int
    + {abstract} makeSound(): void
    + eat(): void
}

class Dog extends Animal {
    - breed: String
    + makeSound(): void
    + fetch(): void
}

class Cat extends Animal {
    - indoor: boolean
    + makeSound(): void
}

interface Trainable {
    + train(command: String): void
}

Dog ..|> Trainable

class Owner {
    - name: String
    + adopt(pet: Animal): void
}

Owner "1" o-- "*" Animal : owns

@enduml`
  },
  {
    id: "puml-component",
    name: "Component Diagram",
    mode: "plantuml",
    category: "UML: Structure",
    code: `@startuml
skinparam componentStyle uml2

package "Frontend" {
    [Web App] as WebApp
    [Mobile App] as MobileApp
}

package "API Layer" {
    [API Gateway] as Gateway
}

cloud "Microservices" {
    [User Service] as UserService
    [Order Service] as OrderService
}

database "Data Store" {
    [MySQL] as MySQL
    [Redis] as Redis
}

WebApp --> Gateway
MobileApp --> Gateway
Gateway --> UserService
Gateway --> OrderService
UserService --> MySQL
UserService --> Redis
OrderService --> MySQL

@enduml`
  },
  {
    id: "puml-er",
    name: "ER Diagram (Data)",
    mode: "plantuml",
    category: "System: Data",
    code: `@startuml
' ER Diagram
skinparam linetype ortho

entity "User" as user {
    * user_id : INT <<PK>>
    --
    * username : VARCHAR(50)
    * email : VARCHAR(100)
    created_at : DATETIME
}

entity "Order" as order {
    * order_id : INT <<PK>>
    --
    * user_id : INT <<FK>>
    * total_amount : DECIMAL
    * status : ENUM
}

entity "OrderItem" as order_item {
    * item_id : INT <<PK>>
    --
    * order_id : INT <<FK>>
    * product_id : INT <<FK>>
    * quantity : INT
}

entity "Product" as product {
    * product_id : INT <<PK>>
    --
    * name : VARCHAR(200)
    * price : DECIMAL
    * stock : INT
}

user ||--o{ order : "places"
order ||--|{ order_item : "contains"
order_item }|--|| product : "refers"

@enduml`
  },
  {
    id: "puml-object",
    name: "Object Diagram",
    mode: "plantuml",
    category: "UML: Structure",
    code: `@startuml
object "user1: User" as u1 {
    name = "Alice"
    email = "alice@example.com"
}

object "order123: Order" as o1 {
    id = 123
    amount = 99.99
    status = "PAID"
}

object "item1: Product" as p1 {
    name = "Headphones"
    price = 99.99
}

u1 -- o1 : places >
o1 -- p1 : contains >
@enduml`
  },
  // --- BEHAVIOR (Dynamic) ---
  {
    id: "puml-sequence",
    name: "Sequence Diagram",
    mode: "plantuml",
    category: "UML: Behavior",
    code: `@startuml
title User Authentication Flow
autonumber

actor User
participant "Frontend" as Frontend
participant "API Gateway" as Gateway
participant "Auth Service" as Auth
database "User DB" as DB

User -> Frontend: Enter Credentials
Frontend -> Gateway: POST /login
Gateway -> Auth: Validate Request
Auth -> DB: Query User
DB --> Auth: Return User Data
Auth -> Auth: Verify Password
Auth --> Gateway: Generate JWT
Gateway --> Frontend: Return Token
Frontend --> User: Login Success

@enduml`
  },
  {
    id: "puml-activity",
    name: "Activity Diagram",
    mode: "plantuml",
    category: "UML: Behavior",
    code: `@startuml
start
:Receive Order Request;

if (User Logged In?) then (Yes)
    :Fetch User Details;
else (No)
    :Redirect to Login;
    stop
endif

:Check Inventory;

if (Inventory Available?) then (Yes)
    fork
        :Lock Inventory;
    fork again
        :Calculate Price;
    end fork

    :Create Order;
    :Send Confirmation Email;
else (No)
    :Show Out of Stock Error;
endif

stop
@enduml`
  },
  {
    id: "puml-state",
    name: "State Diagram",
    mode: "plantuml",
    category: "UML: Behavior",
    code: `@startuml
[*] --> Pending

state "Pending" as Pending {
    [*] --> WaitingForPayment
    WaitingForPayment --> Processing : Payment Started
    Processing --> WaitingForPayment : Payment Failed
}

Pending --> Paid : Payment Success
Pending --> Cancelled : Timeout/Cancel

state "Paid" as Paid {
    [*] --> ReadyToShip
    ReadyToShip --> Shipped : Ship Item
}

Paid --> Completed : Confirm Receipt
Completed --> [*]
Cancelled --> [*]

@enduml`
  },
  {
    id: "puml-usecase",
    name: "Use Case Diagram",
    mode: "plantuml",
    category: "UML: Behavior",
    code: `@startuml
left to right direction
actor Customer
actor Admin

rectangle "E-commerce System" {
    usecase "Browse Products" as UC1
    usecase "Add to Cart" as UC2
    usecase "Checkout" as UC3
    usecase "Manage Inventory" as UC4
}

Customer --> UC1
Customer --> UC2
Customer --> UC3
Admin --> UC4
UC3 ..> UC2 : <<include>>
@enduml`
  },
  {
    id: "puml-timing",
    name: "Timing Diagram",
    mode: "plantuml",
    category: "UML: Behavior",
    code: `@startuml
robust "DNS Resolver" as DNS
robust "Web Server" as Web
concise "Client" as Client

@0
DNS is Idle
Web is Idle
Client is Idle

@+100
Client -> DNS : Resolve URL
DNS is Processing

@+200
DNS is Idle
Client -> Web : HTTP Request
Web is Processing

@+500
Web is Idle
Client is Processing
@enduml`
  },
  // --- STRATEGY & PROCESS ---
  {
    id: "puml-mindmap",
    name: "Project Mindmap",
    mode: "plantuml",
    category: "Business: Strategy",
    code: `@startmindmap
* Launch Product
** Planning
*** Market Research
*** Competitor Analysis
** Development
*** MVP Features
*** Testing
** Marketing
*** Social Media
*** Email Campaign
@endmindmap`
  },
  {
    id: "puml-wbs",
    name: "Work Breakdown (WBS)",
    mode: "plantuml",
    category: "Business: Strategy",
    code: `@startwbs
* Website Project
** Design
*** Layout
*** Assets
*** Color Palette
** Backend
*** API Design
*** Database Setup
** Frontend
*** Home Page
*** Login Page
*** Dashboard
** Deploy
*** CI/CD Pipeline
*** Domain Setup
@endwbs`
  },
  {
    id: "puml-gantt",
    name: "Gantt Chart",
    mode: "plantuml",
    category: "Business: Strategy",
    code: `@startgantt
[Project Planning] lasts 5 days
[Prototype Design] lasts 10 days
[Prototype Design] starts at [Project Planning]'s end
[Implementation] lasts 20 days
[Implementation] starts at [Prototype Design]'s end
[Testing] lasts 10 days
[Testing] starts at [Implementation]'s end
@endgantt`
  },
  {
    id: "puml-swimlane",
    name: "Swimlane Activity",
    mode: "plantuml",
    category: "Business: Strategy",
    code: `@startuml
|Customer|
start
:Place Order;
|#AntiqueWhite|Sales|
if (Order Accepted?) then (Yes)
  :Process Order;
  |Warehouse|
  :Pick Items;
  :Pack Items;
  |Logistics|
  :Ship Items;
else (No)
  |Sales|
  :Reject Order;
endif
|Customer|
:Receive Goods;
stop
@enduml`
  },
  {
    id: "puml-value-stream",
    name: "Value Stream Mapping",
    mode: "plantuml",
    category: "Business: Strategy",
    code: `@startuml
' Simple Value Stream using Process Shapes
:Raw Material;
-> Transport;
:Machining;
-> Inspect;
:Assembly;
-> Test;
:Finished Goods;
@enduml`
  },
  // --- INFRASTRUCTURE (Implementation) ---
  {
    id: "puml-cloud",
    name: "Cloud Architecture",
    mode: "plantuml",
    category: "System: Architecture",
    code: `@startuml
!define AWS https://raw.githubusercontent.com/awslabs/aws-icons-for-plantuml/v14.0/dist
!includeurl AWS/AWSCommon.puml
!includeurl AWS/Compute/EC2.puml
!includeurl AWS/Database/RDS.puml
!includeurl AWS/Networking/ElasticLoadBalancing.puml

ELB(lb, "Load Balancer", "web")
EC2(web1, "Web Server 1", "t3.micro")
EC2(web2, "Web Server 2", "t3.micro")
RDS(db, "Primary DB", "postgresql")

lb --> web1
lb --> web2
web1 --> db
web2 --> db
@enduml`
  },
  {
    id: "puml-json",
    name: "JSON Visualization",
    mode: "plantuml",
    category: "System: Architecture",
    code: `@startjson
{
  "project": "Aone Toolkit",
  "version": "1.0",
  "modules": [
    "Diagrams",
    "Tables",
    "JSON"
  ]
}
@endjson`
  },
  {
    id: "puml-network",
    name: "Network Diagram",
    mode: "plantuml",
    category: "System: Architecture",
    code: `@startuml
nwdiag {
  network dmz {
      address = "210.x.x.x/24"
      web01 [address = "210.x.x.1"];
      web02 [address = "210.x.x.2"];
  }
  network internal {
      address = "172.x.x.x/24";
      web01 [address = "172.x.x.1"];
      web02 [address = "172.x.x.2"];
      db01;
      db02;
  }
}
@enduml`
  },
  // --- SPECIALIZED (Advanced) ---
  {
    id: "puml-salt",
    name: "UI Wireframe (Salt)",
    mode: "plantuml",
    category: "System: Engineering",
    code: `@startsalt
{
  JustPlain Window
  [X] Checkbox 1
  [ ] Checkbox 2
  Radio buttons:
  ( ) Option 1
  (X) Option 2
  [ Cancle ] | [  OK   ]
}
@endsalt`
  },
  {
    id: "puml-c4-context",
    name: "C4 Context",
    mode: "plantuml",
    category: "System: Engineering",
    code: `@startuml
!include https://raw.githubusercontent.com/plantuml-stdlib/C4-PlantUML/master/C4_Context.puml

Person(user, "User", "A user of our banking system.")
System(banking_system, "Internet Banking System", "Allows users to view information.")
System_Ext(mail_system, "E-mail System", "The internal Microsoft Exchange e-mail system.")
System_Ext(mainframe, "Mainframe Banking System", "Store all of the core banking information.")

Rel(user, banking_system, "Uses")
Rel(banking_system, mail_system, "Sends e-mails", "SMTP")
Rel(banking_system, mainframe, "Uses")
@enduml`
  },
  {
    id: "puml-c4-container",
    name: "C4 Container",
    mode: "plantuml",
    category: "System: Architecture",
    code: `@startuml
!include https://raw.githubusercontent.com/plantuml-stdlib/C4-PlantUML/master/C4_Container.puml

LAYOUT_TOP_DOWN()

Person(user, "User", "Uses the banking app")
System_Boundary(c1, "Banking System") {
    Container(web_app, "Web Application", "Java, Spring MVC", "Delivers the static content")
    Container(spa, "Single Page App", "JavaScript, Angular", "Provides functionality to user")
    Container(api, "API Application", "Java, Docker Container", "Provides Internet Banking functionality via API")
    ContainerDb(db, "Database", "Oracle 12c", "Stores user registration info")
}

System_Ext(email, "E-Mail System", "Internal Exchange system")

Rel(user, web_app, "Uses", "HTTPS")
Rel(user, spa, "Uses", "HTTPS")
Rel(web_app, spa, "Delivers")
Rel(spa, api, "Uses", "JSON/HTTPS")
Rel(api, db, "Reads/Writes", "JDBC")
Rel(api, email, "Sends e-mails", "SMTP")
@enduml`
  },
  {
    id: "puml-c4-component",
    name: "C4 Component",
    mode: "plantuml",
    category: "System: Architecture",
    code: `@startuml
!include https://raw.githubusercontent.com/plantuml-stdlib/C4-PlantUML/master/C4_Component.puml

Container(spa, "Single Page App", "Angular")
ContainerDb(db, "Database", "Relational Database Schema")

Container_Boundary(api, "API Application") {
    Component(sign, "Sign In Controller", "MVC Rest Controler", "Allows users to sign in")
    Component(security, "Security Component", "Spring Bean", "Provides functionality related to sign in")
    Component(mbs, "Mainframe Banking Facade", "Spring Bean", "Facade")
    
    Rel(sign, security, "Uses")
    Rel(security, db, "Read & write to", "JDBC")
    Rel(sign, mbs, "Uses")
}

Rel(spa, sign, "Uses", "JSON/HTTPS")
@enduml`
  },
  {
    id: "puml-archimate",
    name: "Archimate Enterprise",
    mode: "plantuml",
    category: "System: Engineering",
    code: `@startuml
!include <archimate/Archimate>

archimate #Technology "VPN Server" as vpnServer <<technology-device>>
archimate #Technology "Firewall" as firewall <<technology-device>>
archimate #Technology "Local Network" as localNetwork <<technology-network>>

vpnServer -down- localNetwork
firewall -down- vpnServer
@enduml`
  },
  {
    id: "puml-ditaa",
    name: "ASCII Art (Ditaa)",
    mode: "plantuml",
    category: "System: Engineering",
    code: `@startditaa
+---------+   +-----+
|    cBLU |   |     |
|  Server |-->|  DB |
|    {s}  |   | cGRE|
+---------+   +-----+
@endditaa`
  },
  {
    id: "puml-math",
    name: "Math Formula",
    mode: "plantuml",
    category: "System: Engineering",
    code: `@startmath
f(t)=(a_0)/2 + sum_(n=1)^ooa_ncos((npi t)/L)+sum_(n=1)^oo b_nsin((npi t)/L)
@endmath`
  },
  // --- GRAPHVIZ ALGORITHMS ---
  {
    id: "dot-struct",
    name: "Data Structures",
    mode: "graphviz",
    category: "System: Data",
    code: `digraph structs {
    rankdir=LR;
    node [shape=record];
    struct1 [label="<f0> left|<f1> mid\\ dle|<f2> right"];
    struct2 [label="<f0> one|<f1> two"];
    struct3 [label="hello\\nworld |{ b |{c|<here> d|e}| f}| g | h"];
    struct1:f1 -> struct2:f0;
    struct1:f2 -> struct3:here;
}`
  },
  {
    id: "dot-tree",
    name: "Binary Tree",
    mode: "graphviz",
    category: "System: Data",
    code: `digraph Tree {
    node [shape=circle, style=filled, fillcolor="#e1f5fe"];
    10 -> 6;
    10 -> 14;
    6 -> 4;
    6 -> 8;
    14 -> 12;
    14 -> 16;
    
    null4 [shape=point]; 4 -> null4;
    null8 [shape=point]; 8 -> null8;
    null12 [shape=point]; 12 -> null12;
}`
  },
  {
    id: "dot-fsm",
    name: "Finite State Machine",
    mode: "graphviz",
    category: "System: Engineering",
    code: `digraph finite_state_machine {
	rankdir=LR;
	size="8,5"
	node [shape = doublecircle]; LR_0 LR_3 LR_4 LR_8;
	node [shape = circle];
	LR_0 -> LR_2 [ label = "SS(B)" ];
	LR_0 -> LR_1 [ label = "SS(S)" ];
	LR_1 -> LR_3 [ label = "S($end)" ];
	LR_2 -> LR_6 [ label = "SS(b)" ];
	LR_2 -> LR_5 [ label = "SS(a)" ];
	LR_2 -> LR_4 [ label = "S(A)" ];
    LR_5 -> LR_7 [ label = "S(b)" ];
    LR_5 -> LR_5 [ label = "S(a)" ];
}`
  },
  {
    id: "dot-cluster",
    name: "Complex Clusters",
    mode: "graphviz",
    category: "Graphviz: Features",
    code: `digraph G {
	fontname="Helvetica,Arial,sans-serif"
	node [fontname="Helvetica,Arial,sans-serif"]
	edge [fontname="Helvetica,Arial,sans-serif"]

	subgraph cluster_0 {
		style=filled;
		color=lightgrey;
		node [style=filled,color=white];
		a0 -> a1 -> a2 -> a3;
		label = "process #1";
	}

	subgraph cluster_1 {
		node [style=filled];
		b0 -> b1 -> b2 -> b3;
		label = "process #2";
		color=blue
	}
	start -> a0;
	start -> b0;
	a1 -> b3;
	b2 -> a3;
	a3 -> a0;
	a3 -> end;
	b3 -> end;

	start [shape=Mdiamond];
	end [shape=Msquare];
}`
  },
  {
    id: "eng-twopi",
    name: "Radial Layout (Twopi)",
    mode: "graphviz",
    category: "Graphviz: Layouts",
    code: `digraph G {
    layout=twopi;
    ranksep=3;
    ratio=auto;
    node [shape=circle];
    
    root -> a;
    root -> b;
    root -> c;
    
    a -> a1;
    a -> a2;
    b -> b1;
    b -> b2;
    c -> c1;
}`
  },
  // --- PATTERN: DESIGN (GoF) ---
  {
    id: "pat-singleton",
    name: "Singleton Pattern",
    mode: "plantuml",
    category: "Design: Patterns",
    code: `@startuml
title Singleton Pattern
class Singleton {
  - static instance: Singleton
  - constructor()
  + static getInstance(): Singleton
}
Singleton --> Singleton : instance
note right of Singleton::getInstance
  if (instance == null)
    instance = new Singleton()
  return instance
end note
@enduml`
  },
  {
    id: "pat-observer",
    name: "Observer Pattern",
    mode: "plantuml",
    category: "Design: Patterns",
    code: `@startuml
title Observer Pattern
interface Subject {
  + attach(observer: Observer)
  + detach(observer: Observer)
  + notify()
}

interface Observer {
  + update()
}

class ConcreteSubject {
  - state
  + getState()
  + setState()
}

class ConcreteObserver {
  - observerState
  + update()
}

Subject -> Observer : notifies >
ConcreteSubject --|> Subject
ConcreteObserver --|> Observer
ConcreteObserver --> ConcreteSubject : observes >
@enduml`
  },
  {
    id: "pat-factory",
    name: "Factory Method",
    mode: "plantuml",
    category: "Design: Patterns",
    code: `@startuml
title Factory Method Pattern
interface Product
class ConcreteProductA
class ConcreteProductB

interface Creator {
  + factoryMethod(): Product
}

class ConcreteCreatorA {
  + factoryMethod(): Product
}

class ConcreteCreatorB {
  + factoryMethod(): Product
}

ConcreteProductA ..|> Product
ConcreteProductB ..|> Product
ConcreteCreatorA ..|> Creator
ConcreteCreatorB ..|> Creator

ConcreteCreatorA ..> ConcreteProductA : creates >
ConcreteCreatorB ..> ConcreteProductB : creates >
@enduml`
  },
  {
    id: "pat-strategy",
    name: "Strategy Pattern",
    mode: "plantuml",
    category: "Design: Patterns",
    code: `@startuml
title Strategy Pattern

class Context {
  - strategy: Strategy
  + setStrategy(Strategy)
  + execute()
}

interface Strategy {
  + algorithm()
}

class ConcreteStrategyA {
  + algorithm()
}

class ConcreteStrategyB {
  + algorithm()
}

Context o-> Strategy
ConcreteStrategyA ..|> Strategy
ConcreteStrategyB ..|> Strategy
@enduml`
  },
  // --- PATTERN: SYSTEM (Microservices) ---
  {
    id: "pat-saga",
    name: "Saga Pattern (Orchestration)",
    mode: "plantuml",
    category: "System: Patterns",
    code: `@startuml
title Saga Pattern: Order Processing
autonumber

participant "Order Saga" as Saga
participant "Order Service" as Order
participant "Inventory Service" as Inv
participant "Payment Service" as Pay

Saga -> Order: Create Order (PENDING)
activate Order
Order --> Saga: Order Created
deactivate Order

Saga -> Inv: Reserve Stock
activate Inv
alt Stock Available
    Inv --> Saga: Reserved
else Stock Empty
    Inv --> Saga: Out of Stock
    Saga -> Order: Reject Order
end
deactivate Inv

Saga -> Pay: Process Payment
activate Pay
alt Payment Success
    Pay --> Saga: Success
    Saga -> Order: Approve Order
else Insufficient Funds
    Pay --> Saga: Failed
    Saga -> Inv: Release Stock
    Saga -> Order: Reject Order
end
deactivate Pay
@enduml`
  },
  {
    id: "pat-saga-chor",
    name: "Saga Pattern (Choreography)",
    mode: "plantuml",
    category: "System: Patterns",
    code: `@startuml
title Saga Pattern (Choreography - Event Driven)
autonumber

participant "Order Service" as Order
participant "Inventory Service" as Inv
participant "Payment Service" as Pay
queue "Message Broker" as Bus

Order -> Bus: Publish(OrderCreated)
activate Order
Bus -> Inv: Consume(OrderCreated)
deactivate Order

activate Inv
Inv -> Inv: Reserve Stock
alt Success
    Inv -> Bus: Publish(StockReserved)
else OutOfStock
    Inv -> Bus: Publish(StockFailed)
end
deactivate Inv

Bus -> Pay: Consume(StockReserved)
activate Pay
Pay -> Pay: Process Payment
alt Success
    Pay -> Bus: Publish(PaymentSuccess)
else Failed
    Pay -> Bus: Publish(PaymentFailed)
end
deactivate Pay

Bus -> Order: Consume(PaymentSuccess)
activate Order
Order -> Order: Approve Order
deactivate Order
@enduml`
  },
  {
    id: "pat-sidecar",
    name: "Pattern: Sidecar (K8s)",
    mode: "plantuml",
    category: "System: Patterns",
    code: `@startuml
title Sidecar Pattern (Kubernetes Pod)

node "Kubernetes Pod" {
    component "Main Container
(Application)" as app
    component "Sidecar Container
(Proxy / Log Agent)" as sidecar
    
    interface "Localhost" as local
    
    app -d-> local : HTTP/Logs
    local -u-> sidecar : Intercept
}

cloud "External Service" as ext
database "Log Aggregator" as logs

sidecar -> ext : Proxy Req
sidecar -> logs : Ship Logs
@enduml`
  },
  {
    id: "pat-gateway",
    name: "Pattern: API Gateway",
    mode: "plantuml",
    category: "System: Patterns",
    code: `@startuml
title API Gateway Pattern

actor Client
node "API Gateway" {
    component "Rate Limiter"
    component "Auth Filter"
    component "Router"
}

node "Services" {
    component "Product Service" as prod
    component "Order Service" as order
    component "User Service" as user
}

Client -> "API Gateway" : /api/v1/orders
"API Gateway" -> user : 1. Validate Token
"API Gateway" -> prod : 2. Get Product Info
"API Gateway" -> order : 3. Create Order
@enduml`
  },
  {
    id: "pat-es",
    name: "Pattern: Event Sourcing",
    mode: "plantuml",
    category: "System: Patterns",
    code: `@startuml
title Event Sourcing (Replay State)

database "Event Store" as Store
collections "Events" as Events
control "Projection" as Proj
database "Read Model" as Read
actor User

User -> Store: 1. Command(AddItem)
Store -> Events: 2. Append(ItemAdded)
Events -> Proj: 3. Subscribe
Proj -> Read: 4. Update View
User -> Read: 5. Query(Cart)

note right of Events
  Stream: Cart-123
  1. Created
  2. ItemAdded(A)
  3. ItemRemoved(A)
  4. ItemAdded(B)
end note
@enduml`
  },
  {
    id: "pat-circuit",
    name: "Circuit Breaker",
    mode: "plantuml",
    category: "System: Patterns",
    code: `@startuml
title Circuit Breaker State
state Closed {
    [*] --> Healthy
    Healthy --> FailureCount : Error
    FailureCount --> Healthy : Success
}

state Open {
    [*] --> TimerRunning
    TimerRunning --> HalfOpen : Timeout
}

state HalfOpen {
    [*] --> Probe
    Probe --> Closed : Success
    Probe --> Open : Error
}

Closed --> Open : Threshold Exceeded
@enduml`
  },
  {
    id: "pat-cqrs",
    name: "CQRS Pattern",
    mode: "plantuml",
    category: "System: Patterns",
    code: `@startuml
title CQRS Architecture

package "Command Side" {
    [Command API] as C_API
    [Command Handler] as Handler
    database "Write DB" as WriteDB
}

package "Query Side" {
    [Query API] as Q_API
    database "Read DB" as ReadDB
}

[Event Bus] as Bus

C_API -> Handler : Send Command
Handler -> WriteDB : Update State
Handler -> Bus : Publish Event
Bus -> ReadDB : Sync Data
Q_API -> ReadDB : Read Data
@enduml`
  },
  // --- PATTERN: PROCESS ---
  {
    id: "pat-gitflow",
    name: "Git Flow",
    mode: "plantuml",
    category: "Business: Process",
    code: `@startuml
title Git Flow
group Master
    start
    :v1.0 Tag;
end group

group Develop
    :Init Develop;
    split
        :Feature A;
    split again
        :Feature B;
    end split
    :Merge Features;
end group

group Release
    :Create Release 1.1;
    :Test & Fix;
end group

split
    :Merge to Master (v1.1);
split again
    :Merge to Develop;
end split

stop
@enduml`
  },
  {
    id: "pat-kanban",
    name: "Kanban Board",
    mode: "plantuml",
    category: "Business: Process",
    code: `@startsalt
{
  {+
    <b>To Do</b> | <b>In Progress</b> | <b>Done</b>
    {.
      [New Feature X]
      [Bug Fix Y]
    } | {
      [Refactor Z]
    } | {
      [Deploy v1.0]
      [Update Docs]
    }
  }
}
@endsalt`
  },
  {
    id: "puml-event-storming",
    name: "Event Storming",
    mode: "plantuml",
    category: "Business: Process",
    code: `@startuml
title Event Storming (Domain Model)

skinparam component {
  BackgroundColor<<Event>> Orange
  BackgroundColor<<Command>> LightBlue
  BackgroundColor<<Aggregate>> Yellow
}

package "Order Context" {
  [Create Order] <<Command>> as c1
  [Order Created] <<Event>> as e1
  [Check Credit] <<Command>> as c2
  [Credit Approved] <<Event>> as e2
  [Inventory Reserved] <<Event>> as e3
  
  note top of e1 : Sticky note style
}

c1 -> e1
e1 -> c2
c2 -> e2
e2 -> e3

legend right
  |<back:Orange>Event</back>| Domain Change |
  |<back:LightBlue>Command</back>| User Intent |
  |<back:Yellow>Aggregate</back>| Entity Boundary |
end legend
@enduml`
  },
  {
    id: "puml-user-story-map",
    name: "User Story Map",
    mode: "plantuml",
    category: "Business: Process",
    code: `@startuml
title User Story Map: E-commerce

skinparam rectangle {
    BackgroundColor White
    BorderColor Black
}

rectangle "Activity: Browse Product" as a1 {
    rectangle "Search" as search
    rectangle "Filter" as filter
}

rectangle "Activity: Purchase" as a2 {
    rectangle "Checkout" as checkout
    rectangle "Payment" as pay
}

rectangle "Release 1 (MVP)" as r1 #LightGreen {
    rectangle "Basic Search" as s1
    rectangle "Guest Checkout" as c1
}

rectangle "Release 2" as r2 #LightBlue {
    rectangle "Advanced Filter" as s2
    rectangle "Registered User" as c2
}

search -d-> s1
search -d-> s2
checkout -d-> c1
checkout -d-> c2
@enduml`
  },
  // --- PLANTUML: FEATURES (Power User) ---
  {
    id: "feat-preproc",
    name: "Preprocessor (Macros/Logic)",
    mode: "plantuml",
    category: "PlantUML: Features",
    code: `@startuml
!define DARK_MODE
!include <tupadr3/common>
!include <tupadr3/font-awesome-5/server>
!include <tupadr3/font-awesome-5/database>

!ifdef DARK_MODE
    skinparam backgroundColor #333
    skinparam arrowColor White
    skinparam nodeFontColor White
    skinparam nodeBorderColor White
!endif

!function $double($a)
!return $a + $a
!endfunction

title Preprocessor Logic ($double("Test"))

FA5_SERVER(web, "Web Server")
FA5_DATABASE(db, "Database")

web --> db
@enduml`
  },
  {
    id: "feat-theme",
    name: "Theming & Styling",
    mode: "plantuml",
    category: "PlantUML: Features",
    code: `@startuml
!theme spacelab
skinparam node {
    BackgroundColor<<highlight>> yellow
    BorderColor<<highlight>> red
}

node "Normal Node"
node "Important Node" <<highlight>>

cloud "Cloud" {
  [App]
}
@enduml`
  },
  {
    id: "feat-yaml",
    name: "YAML Visualization",
    mode: "plantuml",
    category: "PlantUML: DSLs",
    code: `@startyaml
# Highlight specific keys
#highlight "production"
environment:
  development:
    db: sqlite
    server: local
  production:
    db: postgres
    server: aws
    replicas: 5
@endyaml`
  },
  {
    id: "feat-deploy",
    name: "Deployment Diagram",
    mode: "plantuml",
    category: "PlantUML: DSLs",
    code: `@startuml
artifact "Web App" as app
node "App Server" {
    component "Tomcat"
    app ..> Tomcat : deploy
}

node "DB Server" {
    database "PostgreSQL"
}

Tomcat --> PostgreSQL
@enduml`
  },
  // --- GRAPHVIZ: ENGINES & ADVANCED ---
  {
    id: "eng-neato",
    name: "Engine: Neato (Physics)",
    mode: "graphviz",
    engine: "neato",
    category: "Graphviz: Layouts",
    code: `graph G {
    layout=neato;
    overlap=false;
    splines=true;
    node [shape=circle, style=filled, fillcolor="#b3e5fc"];
    
    // Fully connected mesh
    a -- b; a -- c; a -- d; a -- e;
    b -- c; b -- d; b -- e;
    c -- d; c -- e;
    d -- e;
}`
  },
  {
    id: "eng-patchwork",
    name: "Engine: Patchwork (TreeMap)",
    mode: "graphviz",
    engine: "patchwork",
    category: "Graphviz: Layouts",
    code: `digraph G {
    layout=patchwork;
    node [style=filled];
    
    subgraph cluster_regions {
        label="Sales by Region";
        
        node [fillcolor="#ffcdd2"] "North America" [area=50];
        node [fillcolor="#c8e6c9"] "Europe" [area=30];
        node [fillcolor="#bbdefb"] "Asia" [area=80];
    }
}`
  },
  {
    id: "eng-fdp",
    name: "Engine: FDP (Force-Directed)",
    mode: "graphviz",
    engine: "fdp",
    category: "Graphviz: Layouts",
    code: `graph G {
    layout=fdp;
    node [shape=box, style=filled, fillcolor="#C5CAE9"];
    
    // Spring model with groups
    subgraph cluster_A {
        label="Group A";
        a1 -- a2 -- a3 -- a1;
    }
    
    subgraph cluster_B {
        label="Group B";
        b1 -- b2 -- b3 -- b4 -- b1;
    }
    
    a1 -- b1;
    a2 -- b2;
}`
  },
  {
    id: "eng-sfdp",
    name: "Engine: SFDP (Large Graphs)",
    mode: "graphviz",
    engine: "sfdp",
    category: "Graphviz: Layouts",
    code: `graph G {
    layout=sfdp;
    overlap=false;
    node [shape=point, width=0.1];
    
    hub -- {n1 n2 n3 n4 n5 n6 n7 n8 n9 n10};
    n1 -- {n11 n12 n13};
    n2 -- {n21 n22 n23};
}`
  },
  {
    id: "eng-sfdp-stress",
    name: "Stress Test: SFDP (Large)",
    mode: "graphviz",
    engine: "sfdp",
    category: "Graphviz: Layouts",
    code: `graph SFDP_Stress {
    layout=sfdp;
    // Optimize for speed
    overlap=prism;
    outputorder=edgesfirst;
    node [shape=point, width=0.1, color="#444444"];
    edge [color="#AAAAAA50", penwidth=0.5];

    // Hub 1
    root1 -- {a1 a2 a3 a4 a5 a6 a7 a8 a9 a10};
    a1 -- {b1 b2 b3 b4 b5};
    a2 -- {c1 c2 c3 c4 c5};
    
    // Hub 2
    root2 -- {x1 x2 x3 x4 x5 x6 x7 x8 x9 x10};
    x1 -- {y1 y2 y3};
    x2 -- {z1 z2 z3};
    
    // Bridge
    root1 -- root2 [penwidth=2, color=red];
    b3 -- y2;
    c5 -- z1;
}`
  },
  {
    id: "eng-cheatsheet",
    name: "Guide: Which Engine?",
    mode: "graphviz",
    category: "Graphviz: Layouts",
    code: `digraph EngineGuide {
    rankdir=LR;
    node [shape=note, style=filled, fillcolor="#FFF3E0", fontname="Arial"];
    edge [color="#555555"];
    
    Question [label="What is your\\nTopology?", shape=diamond, fillcolor="#B2EBF2", style=filled];
    
    Hierarchical [shape=box, label="Hierarchical\\n(Tree/Flow)"];
    Network [shape=box, label="Network\\n(Mesh/Connections)"];
    Ring [shape=box, label="Ring / Cycle"];
    Cluster [shape=box, label="Clusters / Groups"];
    
    Dot [label="DOT\\n(Standard)", fillcolor="#C8E6C9"];
    Neato [label="NEATO\\n(Small < 100)", fillcolor="#FFCCBC"];
    SFDP [label="SFDP\\n(Large > 100)", fillcolor="#FFCCBC"];
    Circo [label="CIRCO\\n(Circular)", fillcolor="#E1BEE7"];
    Osage [label="OSAGE\\n(Array/Box)", fillcolor="#BBDEFB"];
    FDP [label="FDP\\n(Force Cluster)", fillcolor="#BBDEFB"];

    Question -> Hierarchical;
    Question -> Network;
    Question -> Ring;
    Question -> Cluster;

    Hierarchical -> Dot [label="Use"];
    Network -> Neato [label="Small"];
    Network -> SFDP [label="Large"];
    Ring -> Circo [label="Use"];
    Cluster -> Osage [label="Packed"];
    Cluster -> FDP [label="Loose"];
    Cluster -> Dot [label="Structured"];
}`
  },
  {
    id: "eng-cluster-comp",
    name: "Comparison: Clusters",
    mode: "graphviz",
    category: "Graphviz: Layouts",
    code: `graph ClusterComp {
    // Try changing layout directly here to see differences:
    // layout=fdp   -> Clusters float like bubbles (Springs)
    // layout=osage -> Clusters packed like boxes (Arrays)
    // layout=dot   -> Clusters are regions (Hierarchy)
    layout=fdp; 
    
    node [shape=circle, style=filled, color=white];
    
    subgraph cluster_A {
        label="Cluster A";
        bgcolor="#E3F2FD";
        a1 -- a2 -- a3 -- a1;
    }
    
    subgraph cluster_B {
        label="Cluster B";
        bgcolor="#FCE4EC";
        b1 -- b2 -- b3;
    }
    
    // Cross-cluster link
    a2 -- b2 [penwidth=2];
}`
  },
  {
    id: "eng-circo",
    name: "Engine: Circo (Circular)",
    mode: "graphviz",
    engine: "circo",
    category: "Graphviz: Layouts",
    code: `graph G {
    layout=circo;
    node [shape=doublecircle, color=orange];
    
    1 -- 2 -- 3 -- 4 -- 5 -- 6 -- 7 -- 1;
    
    1 -- 4;
    2 -- 5;
    3 -- 6;
}`
  },
  {
    id: "eng-osage",
    name: "Engine: Osage (Clustered)",
    mode: "graphviz",
    engine: "osage",
    category: "Graphviz: Layouts",
    code: `graph G {
    layout=osage;
    node [shape=box, style=filled];
    
    subgraph cluster_0 {
        label="Section 1";
        node [fillcolor=lightblue];
        a b c d;
    }
    
    subgraph cluster_1 {
        label="Section 2";
        node [fillcolor=lightgreen];
        e f g h;
    }
}`
  },
  {
    id: "eng-nop",
    name: "Engine: Nop (Fixed Positions)",
    mode: "graphviz",
    category: "Graphviz: Layouts",
    code: `digraph G {
    layout=nop2;
    node [shape=circle];
    
    n1 [pos="0,0!"];
    n2 [pos="100,100!"];
    n3 [pos="200,0!"];
    
    n1 -> n2 -> n3 -> n1;
}`
  },
  {
    id: "eng-html",
    name: "HTML Labels",
    mode: "graphviz",
    category: "Graphviz: Features",
    code: `digraph structs {
    rankdir=LR;
    node [shape=plaintext];
    
    struct1 [label=<
<TABLE BORDER="0" CELLBORDER="1" CELLSPACING="0">
  <TR>
    <TD>left</TD>
    <TD PORT="f1">mid dle</TD>
    <TD PORT="f2">right</TD>
  </TR>
</TABLE>>];
    
    struct2 [label=<
<TABLE BORDER="0" CELLBORDER="1" CELLSPACING="0">
  <TR><TD PORT="f0">one</TD><TD>two</TD></TR>
</TABLE>>];
    
    struct1:f1 -> struct2:f0;
}`
  },
  {
    id: "eng-gradient",
    name: "Gradients & Colors",
    mode: "graphviz",
    category: "Graphviz: Features",
    code: `digraph G {
    bgcolor="transparent";
    node [style=filled, shape=circle];
    
    // Linear Gradient
    a [fillcolor="yellow:blue", label="Linear"];
    
    // Radial Gradient
    b [style="filled,radial", fillcolor="white:red", label="Radial"];
    
    a -> b;
}`
  },
  // --- ADDITIONAL: CLOUD & DATA ---
  {
    id: "cloud-azure",
    name: "Cloud: Azure",
    mode: "plantuml",
    category: "System: Architecture",
    code: `@startuml
!define AzurePuml https://raw.githubusercontent.com/plantuml-stdlib/Azure-PlantUML/master/dist
!includeurl AzurePuml/AzureCommon.puml
!includeurl AzurePuml/Databases/AzureSqlDatabase.puml
!includeurl AzurePuml/Compute/AzureFunction.puml

AzureFunction(f, "Process Data", "java")
AzureSqlDatabase(db, "Storage", "SQL")

f --> db
@enduml`
  },
  {
    id: "cloud-k8s",
    name: "Orchestration: Kubernetes",
    mode: "plantuml",
    category: "System: Architecture",
    code: `@startuml
!include <kubernetes/k8s-sprites-unlabeled-25pct>
package "Cluster" {
    component "<$node>
Node" as node {
        component "<$pod>
Pod" as pod
    }
    component "<$service>
Service" as svc
}
pod --> svc
@enduml`
  },
  {
    id: "data-chen",
    name: "ER Diagram (Chen)",
    mode: "graphviz",
    category: "System: Data",
    code: `graph ER {
    layout=neato;
    node [shape=box]; Entity;
    node [shape=ellipse]; Attribute;
    node [shape=diamond,style=filled,color=lightgrey]; Relationship;
    
    Entity -- Relationship -- Attribute;
}`
  },
  {
    id: "data-dfd",
    name: "Data Flow Diagram",
    mode: "graphviz",
    category: "System: Data",
    code: `digraph DFD {
    rankdir=LR;
    node [shape=box, style=rounded]; Process;
    node [shape=parallelogram, style=filled, fillcolor=lightblue]; Input;
    node [shape=cylinder]; Store;
    
    Input -> Process;
    Process -> Store;
}`
  },
  {
    id: "puml-board",
    name: "Board (Dashboard)",
    mode: "plantuml",
    category: "Business: Strategy",
    code: `@startboard
C: Use Case
B: In Progress
D: Done

C -> B
B -> D
@endboard`
  },
  {
    id: "puml-chron",
    name: "Chronology (Timeline)",
    mode: "plantuml",
    category: "UML: Behavior",
    code: `@startchronology
print "Event 1"
-> "Event 2"
@endchronology`
  },
  // --- SPECIALIZED: SYNTAX & LOGIC ---
  {
    id: "spec-ebnf",
    name: "EBNF (Railroad Diagram)",
    mode: "plantuml",
    category: "System: Engineering",
    code: `}
@enduml`
  },
  {
    id: "spec-regex",
    name: "Regex / EBNF (Standard)",
    mode: "plantuml",
    category: "System: Engineering",
    code: `@startuml
ebnf
  digit = "0" | "1" | "2" | "3" | "4" | "5" | "6" | "7" | "8" | "9" ;
  variable = letter , { letter | digit | "_" } ;
  assignment = variable , "=" , ( number | variable ) , ";" ;
@enduml`
  },
  {
    id: "spec-logic",
    name: "Logic Gates (Hardware)",
    mode: "graphviz",
    category: "System: Engineering",
    code: `digraph logic {
    rankdir=LR;
    node [shape=record, height=1];
    
    // Inputs
    a [label="A", shape=none];
    b [label="B", shape=none];
    
    // Gates
    and [label="AND", shape=box, style=filled, fillcolor="#e0e0e0"];
    or [label="OR", shape=invtrapezium, style=filled, fillcolor="#e0e0e0"];
    
    // Connections
    a -> and;
    b -> and;
    and -> or;
}`
  },
  // --- VISUAL & LAYOUT ---
  {
    id: "style-hand",
    name: "Style: Handwritten (Sketch)",
    mode: "plantuml",
    category: "PlantUML: Features",
    code: `@startuml
skinparam handwritten true
skinparam backgroundColor #EEEBDC

actor User
participant "Sketchy App" as App
database "Rough DB" as DB

User -> App : Clicks button
App -> DB : Saves data
note right: This looks like
a napkin sketch
@enduml`
  },
  {
    id: "layout-rank",
    name: "Layout: Forced Ranking",
    mode: "graphviz",
    category: "Graphviz: Features",
    code: `digraph G {
    node [shape=box];
    
    // Define nodes
    Start;
    Process1; Process2;
    End;
    
    // Standard flow
    Start -> Process1 -> End;
    Start -> Process2 -> End;
    
    // FORCE Process1 and Process2 to be on same level
    { rank=same; Process1; Process2; }
}`
  },
  {
    id: "eng-guide-dir",
    name: "Guide: Connect & Layout (CN)",
    mode: "graphviz",
    category: "Graphviz: Features",
    code: `// ============================================================
// Graphviz Direction & Layout Guide (Cheat Sheet)
//
// 1. Global Direction: rankdir=TB, BT, LR, RL
// 2. Ports: node:n, node:se
// 3. Alignment: {rank=same; A; B}
// 4. Edge Direction: dir=both, back, none
// ============================================================

/*
// --- EXAMPLE 1: BASIC DIRECTION ---
digraph G {
    rankdir=TB;
    A -> B -> C;
}

// --- EXAMPLE 2: PORTS ---
digraph G {
    A:e -> B:w;
    A:s -> C:n;
}

// --- EXAMPLE 3: PORTS + RANK ---
digraph G {
    rankdir=LR;
    {rank=same; A; B}
    A:e -> B:w;
    C:s -> F:n;
}
*/

// ============================================================
// 8. COMBINED EXAMPLE: Z-Shape Layout
// ============================================================
digraph ZShape {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fillcolor=white];
    
    // Row 1: Right
    {rank=same; A; B; C; D}
    A:e -> B:w;
    B:e -> C:w;
    C:e -> D:w;
    
    // Turn Down
    D:s -> H:n [color=red, label="Turn"];
    
    // Row 2: Left
    {rank=same; E; F; G; H}
    H:w -> G:e;
    G:w -> F:e;
    F:w -> E:e;
    
    // Turn Down
    E:s -> I:n [color=red, label="Turn"];
    
    // Row 3: Right
    {rank=same; I; J; K; L}
    I:e -> J:w;
    J:e -> K:w;
    K:e -> L:w;
}`
  },
  {
    id: "data-crows",
    name: "ERD: Crow's Foot",
    mode: "graphviz",
    category: "System: Data",
    code: `digraph ERD {
    graph [rankdir=LR, splines=ortho];
    node [shape=none, fontname="Arial"];
    
    User [label=<
    <table border="0" cellborder="1" cellspacing="0" cellpadding="4">
      <tr><td bgcolor="lightgrey"><b>User</b></td></tr>
      <tr><td align="left">PK: id</td></tr>
      <tr><td align="left">name</td></tr>
    </table>>];

    Order [label=<
    <table border="0" cellborder="1" cellspacing="0" cellpadding="4">
      <tr><td bgcolor="lightgrey"><b>Order</b></td></tr>
      <tr><td align="left">PK: id</td></tr>
      <tr><td align="left">FK: user_id</td></tr>
    </table>>];

    // Crow's foot notation
    User -> Order [dir=both, arrowtail=crow, arrowhead=none, label="places"];
}`
  },
  {
    id: "beh-concurrent",
    name: "State: Concurrent Regions",
    mode: "plantuml",
    category: "UML: Behavior",
    code: `@startuml
hide empty description
state "Car System" as Car {
    state "Engine" as Engine {
        [*] --> Idling
        Idling --> Running : Accelerate
        Running --> Idling : Brake
    }
    --
    state "Radio" as Radio {
        [*] --> Off
        Off --> FM : Power On
        FM --> AM : Switch Band
    }
}
@enduml`
  },
  // --- SPECIALIZED: SYSTEMS (SysML) ---
  {
    id: "sysml-req",
    name: "SysML Requirement",
    mode: "plantuml",
    category: "System: Engineering",
    code: `@startuml
sysml
package "Standard Requirements" {
    requirement "Performance" as R1 {
        id = "REQ-001"
        text = "The system shall respond in < 100ms."
    }
    
    requirement "Security" as R2 {
        id = "REQ-002"
        text = "All data must be encrypted."
        Risk = "High"
    }
}

element "Search Component" as C1

C1 -up-> R1 : satisfies
C1 -up-> R2 : satisfies
@enduml`
  },
  {
    id: "sysml-block",
    name: "SysML Block Definition",
    mode: "plantuml",
    category: "System: Engineering",
    code: `@startuml
sysml
block "Car" as car
block "Engine" as engine
block "Wheel" as wheel
block "Driver" as driver

car *-- "1" engine
car *-- "4" wheel
car o-- "1" driver : drives
@enduml`
  },
  // --- MANAGEMENT & ANALYSIS ---
  {
    id: "mgmt-org",
    name: "Organization Chart",
    mode: "plantuml",
    category: "Business: Strategy",
    code: `@startwbs
+ CEO
++ VP Engineering
+++ Architecture Team
+++ QA Team
++ VP Sales
+++ North America
+++ Europe
@endwbs`
  },
  {
    id: "mgmt-pert",
    name: "PERT Chart (Project)",
    mode: "graphviz",
    category: "Business: Strategy",
    code: `digraph PERT {
    rankdir=LR;
    node [shape=circle, style=filled, fillcolor=white, fixedsize=true, width=1];
    
    Start [label="Start", shape=Mdiamond];
    Finish [label="Finish", shape=Msquare];
    
    A [label="A\\n(3d)"];
    B [label="B\\n(4d)"];
    C [label="C\\n(2d)"];
    D [label="D\\n(5d)"];
    
    Start -> A;
    Start -> B;
    A -> C;
    B -> D;
    C -> Finish;
    D -> Finish;
    
    // Critical Path
    edge [color=red, penwidth=2];
    Start -> B -> D -> Finish;
}`
  },
  {
    id: "mgmt-swot",
    name: "SWOT Analysis",
    mode: "plantuml",
    category: "Business: Strategy",
    code: `@startsalt
{+
  <b>SWOT Analysis Matrix</b> | .
  . | .
  <b>Strengths</b> | <b>Weaknesses</b>
  * Innovative Tech | * Small Team
  * Agile Process | * Limited Budget
  . | .
  <b>Opportunities</b> | <b>Threats</b>
  * New Markets | * Competitors
  * AI Trends | * Regulation
}
@endsalt`
  },
  {
    id: "anal-concept",
    name: "Concept Map",
    mode: "graphviz",
    category: "Business: Strategy",
    code: `digraph ConceptMap {
    node [shape=oval, style=filled, fillcolor="#fff9c4"];
    edge [fontsize=10];
    
    "PlantUML" -> "Diagrams" [label="generates"];
    "Diagrams" -> "Visual Communication" [label="facilitates"];
    "Users" -> "PlantUML" [label="write code for"];
    "Users" -> "Visual Communication" [label="need"];
}`
  },
  {
    id: "anal-tree",
    name: "Directory / File Tree",
    mode: "plantuml",
    category: "System: Architecture",
    code: `@startsalt
{
{T
 + <&folder> src
 ++ <&folder> components
 +++ <&file> Button.svelte
 +++ <&file> Modal.svelte
 ++ <&folder> lib
 +++ <&file> utils.ts
 + <&file> package.json
 + <&file> README.md
}
}
@endsalt`
  },
  {
    id: "beh-interact",
    name: "Interaction Overview",
    mode: "plantuml",
    category: "UML: Behavior",
    code: `@startuml
title Interaction Overview

start
:Init Session;

if (Is Verified?) then (yes)
  :ref:
  <b>Sequence Diagram: </b>
  User -> API : Get Data
  API --> User : Data
  end ref;
else (no)
  :Show Error;
endif

stop
@enduml`
  },
  // --- ACTIVITY: MASTERY (MECE Control flow) ---
  {
    id: "act-guide-arrows",
    name: "Guide: Activity Arrows (CN)",
    mode: "plantuml",
    category: "UML: Behavior",
    code: `@startuml
title Activity Diagram Arrow Guide (活动图箭头指南)

' ============================================================
' 1. 基础箭头与标签 (Basic & Labels)
' ============================================================
:开始;
-> 默认向下;
:步骤 1;
-> 带有标签的箭头;
:步骤 2;

' ============================================================
' 2. 样式与颜色 (Styles & Colors)
' ============================================================
:步骤 3;
-[#blue]-> 蓝色箭头;
:步骤 4;
-[#red,dashed]-> 红色虚线;
:步骤 5;
-[#green,bold]-> 绿色加粗;
:步骤 6;

' ============================================================
' 3. 回退箭头 (Backward / Upward)
' ============================================================
' 在 repeat 循环中，可以使用 backward 关键字创建"向上"的箭头
repeat
  :主流程;
  backward :<color:red>修正/重试 (向上的逻辑)</color>;
  note right: backward 会自动反向绘制
repeat while (需重试?)

' ============================================================
' 4. 分支方向 (Branching / Sideways)
' ============================================================
' PlantUML 自动处理左右分支布局
if (检查?) then (通过)
  :向右/下流程;
else (拒绝)
  :向左/下流程;
  -[#gray,dotted]-> 终止;
  stop
endif

' ============================================================
' 5. 连接点 (Connectors / Jumps)
' ============================================================
' 当距离太远时，使用连接点代替长箭头
:生成长连接;
-> 跳转至 A;
(A)
detach

(A)
:从 A 处接续 (避免复杂连线交叉);

' ============================================================
' 6. 泳道 (Swimlanes / Grouping)
' ============================================================
' 泳道强制将节点按列排布
|#Pink|管理员|
:审批;
|#LightBlue|用户|
:查看结果;

stop
@enduml`
  },
  {
    id: "act-loops",
    name: "Activity: While/Repeat Loops",
    mode: "plantuml",
    category: "UML: Behavior",
    code: `@startuml
start
:Initialize System;

while (Data available?) is (yes)
  :Read Data Packet;
  :Process Packet;
endwhile (no)

repeat
  :Perform Health Check;
backward:Log minor error;
repeat while (System Stable?) is (no) not (yes)

stop
@enduml`
  },
  {
    id: "act-flow-ctrl",
    name: "Activity: Flow Control (Break/Jump)",
    mode: "plantuml",
    category: "UML: Behavior",
    code: `@startuml
start
:Start Batch Process;

if (Input Valid?) then (no)
  :Log Error;
  detach
endif

:Process Item;

if (Critical Failure?) then (yes)
  :Trigger Alarm;
  kill
endif

(A)
:Finalize;
detach

(A)
:Audit Log;
stop
@enduml`
  },
  {
    id: "act-partition",
    name: "Activity: Partitioning",
    mode: "plantuml",
    category: "UML: Behavior",
    code: `@startuml
partition "Initialization" {
    start
    :Load Config;
    :Init DB;
}

partition "Main Processing" #LightBlue {
    :Fetch Request;
    :Validate;
}

:Send Response;
stop
@enduml`
  },
  {
    id: "dot-iso-flow",
    name: "Flowchart: ISO Standard",
    mode: "graphviz",
    category: "UML: Behavior",
    code: `digraph G {
    node [fontname="Arial"];
    
    // ISO Shapes
    Start [shape=oval, label="Start"];
    Input [shape=parallelogram, label="Read Input"];
    Decision [shape=diamond, label="Is Valid?"];
    Process [shape=box, label="Process Data"];
    End [shape=oval, label="End"];
    
    Start -> Input;
    Input -> Decision;
    Decision -> Process [label="Yes"];
    Decision -> End [label="No"];
    Process -> End;
}`
  },
  {
    id: "dot-swimlane",
    name: "Flowchart: Swimlanes",
    mode: "graphviz",
    category: "UML: Behavior",
    code: `digraph G {
    rankdir=LR;
    node [shape=box];
    
    subgraph cluster_0 {
        label="User / Frontend";
        style=filled;
        color=lightgrey;
        Login; Submit;
    }
    
    subgraph cluster_1 {
        label="Backend / Server";
        style=filled;
        color=lightblue;
        Auth; Save;
    }
    
    Login -> Auth;
    Auth -> Submit;
    Submit -> Save;
}`
  },
  // --- REFERENCE: COMPLEX SYSTEMS (Real World) ---
  {
    id: "ref-microservices",
    name: "Ref: Microservices Trace",
    mode: "plantuml",
    category: "System: Architecture",
    code: `@startuml
title Distributed Tracing: Order Placement
autonumber
hide footbox
skinparam maxMessageSize 150

actor User
participant "Web App" as Web
participant "API Gateway" as Gate
participant "Order Svc" as Order
queue "Kafka\\nTopic: events" as Kafka
database "Redis\\nCache" as Cache
database "PostgreSQL\\nShards" as DB

User -> Web: Click "Buy Now"
activate Web
Web -> Gate: POST /orders
activate Gate

Gate -> Order: CreateOrder(Item, User)
activate Order

Order -> Cache: GET /stock/{id}
alt Cache Hit
    Cache --> Order: 200 OK (Qty: 5)
else Cache Miss
    Order -> DB: SELECT * FROM stock
    DB --> Order: Row(Qty: 5)
    Order -> Cache: SET /stock/{id}
end

Order -> DB: INSERT INTO orders
activate DB
DB --> Order: OrderID: 999
deactivate DB

Order -> Kafka: Publish(OrderCreated)
activate Kafka
Kafka --> Order: ACK
deactivate Kafka

Order --> Gate: 201 Created
deactivate Order

Gate --> Web: Success
deactivate Gate

Web --> User: Show Receipt
deactivate Web
@enduml`
  },
  {
    id: "ref-ddd-aggregate",
    name: "Ref: DDD Aggregate",
    mode: "plantuml",
    category: "UML: Structure",
    code: `@startuml
title DDD: Order Aggregate
skinparam groupInheritance 2

package "Domain Layer" {
    
    abstract class Entity<ID> {
        + id: ID
        + equals(): boolean
    }
    
    interface AggregateRoot
    
    class "Order" as Root <<Aggregate Root>> {
        - status: OrderStatus
        - items: List<OrderItem>
        + addItem(p: Product, q: int)
        + submit()
    }
    
    class "OrderItem" as Item <<Entity>> {
        - price: Money
        - quantity: int
    }
    
    class "Address" as VO <<Value Object>> {
        + street: String
        + city: String
        + zip: String
    }
    
    Root *-- "1..*" Item : contains
    Root *-- "1" VO : shipping
    Root --|> Entity
    Root ..|> AggregateRoot
}
@enduml`
  },
  {
    id: "ref-tcp-state",
    name: "Ref: TCP Lifecycle",
    mode: "plantuml",
    category: "UML: Behavior",
    code: `@startuml
title TCP Connection State Machine
hide empty description

[*] --> CLOSED

state "Active Open" as Active {
    CLOSED -> SYN_SENT : app: open\\nsend: SYN
    SYN_SENT -> ESTABLISHED : recv: SYN, ACK\\nsend: ACK
    SYN_SENT -> CLOSED : app: close
}

state "Passive Open" as Passive {
    CLOSED -> LISTEN : app: listen
    LISTEN -> SYN_RCVD : recv: SYN\\nsend: SYN, ACK
    SYN_RCVD -> ESTABLISHED : recv: ACK
}

state "Establishment" as Est {
    ESTABLISHED --> FIN_WAIT_1 : app: close\\nsend: FIN
    ESTABLISHED --> CLOSE_WAIT : recv: FIN\\nsend: ACK
}

state "Active Close" as AClose {
    FIN_WAIT_1 -> FIN_WAIT_2 : recv: ACK
    FIN_WAIT_2 -> TIME_WAIT : recv: FIN\\nsend: ACK
    FIN_WAIT_1 -> CLOSING : recv: FIN\\nsend: ACK
    CLOSING -> TIME_WAIT : recv: ACK
    TIME_WAIT --> CLOSED : wait 2MSL
}

state "Passive Close" as PClose {
    CLOSE_WAIT --> LAST_ACK : app: close\\nsend: FIN
    LAST_ACK --> CLOSED : recv: ACK
}
@enduml`
  },
  {
    id: "ref-etl-pipeline",
    name: "Ref: ETL Pipeline",
    mode: "graphviz",
    category: "System: Data",
    code: `digraph ETL {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Arial"];
    
    subgraph cluster_sources {
        label="Sources";
        style=dashed;
        CRM [shape=cylinder];
        Logs [shape=note];
        API [shape=component];
    }
    
    subgraph cluster_ingest {
        label="Ingestion Layer";
        bgcolor="#E1F5FE";
        Kafka [label="Kafka Topic", shape=parallelogram];
        S3_Raw [label="S3 (Raw)", shape=folder];
    }
    
    subgraph cluster_transform {
        label="Processing (Spark)";
        bgcolor="#E8F5E9";
        Clean [label="Data Cleaning"];
        Agg [label="Aggregation"];
        Enrich [label="Enrichment"];
    }
    
    subgraph cluster_serve {
        label="Serving";
        bgcolor="#FFF3E0";
        DW [label="Data Warehouse", shape=cylinder, style=filled, fillcolor=white];
        BI [label="Dashboard", shape=rect];
    }
    
    CRM -> Kafka;
    Logs -> Kafka;
    API -> Kafka;
    
    Kafka -> S3_Raw [label="Sink"];
    S3_Raw -> Clean [label="Batch"];
    Clean -> Enrich -> Agg;
    Agg -> DW [label="Load"];
    DW -> BI [label="Query"];
}`
  },
  {
    id: "eng-db-sharding",
    name: "DB Sharding Topology",
    mode: "graphviz",
    category: "System: Data",
    code: `graph Sharding {
    rankdir=TB;
    node [shape=box, style=filled, fillcolor="#F5F5F5"];
    
    // Application Layer
    App [label="Application Server", shape=component, fillcolor="#E1F5FE"];
    
    // Sharding Proxy
    Proxy [label="Sharding Proxy / Vitess", shape=diamond, fillcolor="#FFF9C4"];
    
    // Shards
    subgraph cluster_shard1 {
        label="Shard 1 (A-M)";
        color=blue;
        S1_Primary [label="Primary", fillcolor="#C8E6C9"];
        S1_Replica [label="Replica", style=dashed];
        S1_Primary -- S1_Replica [label="Replicate"];
    }
    
    subgraph cluster_shard2 {
        label="Shard 2 (N-Z)";
        color=red;
        S2_Primary [label="Primary", fillcolor="#C8E6C9"];
        S2_Replica [label="Replica", style=dashed];
        S2_Primary -- S2_Replica [label="Replicate"];
    }
    
    App -- Proxy;
    Proxy -- S1_Primary [label="Key: UserID"];
    Proxy -- S2_Primary [label="Key: UserID"];
}`
  },
  // --- SPECIALIZED: PROTOCOLS & PHYSICAL ---
  {
    id: "sys-packet",
    name: "Ref: Packet Protocol",
    mode: "graphviz",
    category: "System: Engineering",
    code: `digraph Packet {
    rankdir=LR;
    node [shape=record, fontname="Courier"];
    
    packet [label="{
        { <header> Header (32 bits) | <version> Ver | <type> Type | <len> Length } |
        { <src> Source IP (32 bits) } |
        { <dst> Dest IP (32 bits) } |
        { <payload> Payload (Variable Length...) } |
        { <crc> CRC (Checksum) }
    }"];
}`
  },
  {
    id: "sys-rack",
    name: "Ref: Rack Diagram",
    mode: "plantuml",
    category: "System: Architecture",
    code: `@startuml
title Physical Rack Layout
skinparam rectangle {
    BackgroundColor White
    BorderColor Black
}

rectangle "Rack A (42U)" {
    rectangle "Switch (Top)" as sw #LightBlue
    rectangle "Firewall" as fw #Pink
    
    rectangle "Server 1" as s1 {
        component "CPU"
        component "RAM"
    }
    
    rectangle "Server 2" as s2 {
        component "GPU"
    }
    
    rectangle "UPS (Bottom)" as ups #LightYellow
}

sw -- s1
sw -- s2
s1 -- fw
@enduml`
  },
  {
    id: "uml-composite",
    name: "UML: Composite Structure",
    mode: "plantuml",
    category: "UML: Structure",
    code: `@startuml
title Composite Structure with Ports
component "OrderService" {
    port "API" as p1
    port "DbConn" as p2
    
    component "Validator" as v
    component "Processor" as proc
    
    p1 -right-> v
    v -right-> proc
    proc -right-> p2
}

interface "HTTP" as http
http - p1
@enduml`
  },
  {
    id: "dot-structs",
    name: "Ref: Memory Structs",
    mode: "graphviz",
    category: "System: Engineering",
    code: `digraph Structs {
    rankdir=LR;
    node [shape=record];
    
    struct1 [label="<f0> left| <f1> middle| <f2> right"];
    struct2 [label="<f0> one| <f1> two"];
    struct3 [label="hello\\nworld |{ b |{c|<here> d|e}| f}| g | h"];
    
    struct1:f1 -> struct2:f0;
    struct1:f2 -> struct3:here;
}`
  }
];
function TemplatesModal($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { isOpen = false } = $$props;
    let selectedCategory = "All";
    let searchQuery = "";
    const categories = [
      "All",
      ...Array.from(new Set(TEMPLATES.map((t) => t.category || "Other")))
    ];
    let filteredTemplates = TEMPLATES.filter((t) => {
      const searchLower = searchQuery.toLowerCase();
      const matchesSearch = t.name.toLowerCase().includes(searchLower) || t.code.toLowerCase().includes(searchLower) || t.category && t.category.toLowerCase().includes(searchLower);
      return matchesSearch;
    });
    if (isOpen) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm transition-all"><div class="bg-white dark:bg-gray-800 rounded-xl shadow-2xl w-full max-w-2xl max-h-[80vh] flex flex-col border border-gray-200 dark:border-gray-700"><div class="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700"><h3 class="text-lg font-semibold text-gray-900 dark:text-white">Diagram Templates</h3> <button class="p-1 text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">`);
      X($$renderer2, { size: 20 });
      $$renderer2.push(`<!----></button></div> <div class="px-4 py-2 border-b border-gray-200 dark:border-gray-700 flex gap-2 overflow-x-auto no-scrollbar scroll-smooth"><!--[-->`);
      const each_array = ensure_array_like(categories);
      for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
        let cat = each_array[$$index];
        $$renderer2.push(`<button${attr_class(`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap transition-all border ${stringify(selectedCategory === cat ? "bg-indigo-600 border-indigo-600 text-white shadow-sm" : "bg-gray-100 dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700")}`)}>${escape_html(cat)}</button>`);
      }
      $$renderer2.push(`<!--]--></div> <div class="p-4 border-b border-gray-200 dark:border-gray-700 flex gap-4"><input type="text" placeholder="Search name, code, or category..."${attr("value", searchQuery)} class="flex-1 px-3 py-2 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none"/></div> <div class="flex-1 overflow-y-auto p-4 grid grid-cols-1 sm:grid-cols-2 gap-4"><!--[-->`);
      const each_array_1 = ensure_array_like(filteredTemplates);
      for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
        let template = each_array_1[$$index_1];
        $$renderer2.push(`<button class="text-left p-4 rounded-xl border border-gray-200 dark:border-gray-700 hover:border-indigo-500 dark:hover:border-indigo-500 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 transition-all group flex flex-col gap-2"><div class="flex items-center justify-between w-full"><span class="font-medium text-gray-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400">${escape_html(template.name)}</span> <span class="text-xs px-2 py-0.5 rounded bg-gray-100 dark:bg-gray-800 text-gray-500">${escape_html(template.mode)}</span></div> <div class="text-xs text-gray-500 line-clamp-3 bg-gray-50 dark:bg-gray-900/50 p-2 rounded font-mono w-full">${escape_html(template.code)}</div></button>`);
      }
      $$renderer2.push(`<!--]--> `);
      if (filteredTemplates.length === 0) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="col-span-full text-center py-8 text-gray-500">No templates found.</div>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></div></div></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
    bind_props($$props, { isOpen });
  });
}
function SettingsModal($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { isOpen = false, onClose } = $$props;
    const FONTS = [
      { name: "JetBrains Mono", value: "'JetBrains Mono', monospace" },
      { name: "Fira Code", value: "'Fira Code', monospace" },
      {
        name: "Source Code Pro",
        value: "'Source Code Pro', monospace"
      },
      { name: "Consolas", value: "Consolas, monospace" }
    ];
    if (isOpen) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"><div class="bg-white dark:bg-gray-800 rounded-xl shadow-2xl w-full max-w-sm overflow-hidden"><div class="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700"><h3 class="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2">`);
      Monitor($$renderer2, { size: 20, class: "text-indigo-500" });
      $$renderer2.push(`<!----> Editor Settings</h3> <button class="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">`);
      X($$renderer2, { size: 20 });
      $$renderer2.push(`<!----></button></div> <div class="p-6 space-y-6"><div><label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">Font Size</label> <div class="flex items-center gap-4"><button class="p-2 rounded-lg border border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700">`);
      Minus($$renderer2, { size: 18 });
      $$renderer2.push(`<!----></button> <span class="text-xl font-mono w-12 text-center">${escape_html(diagramStore.fontSize)}px</span> <button class="p-2 rounded-lg border border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700">`);
      Plus($$renderer2, { size: 18 });
      $$renderer2.push(`<!----></button></div></div> <div><label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">Font Family</label> <div class="space-y-2"><!--[-->`);
      const each_array = ensure_array_like(FONTS);
      for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
        let font = each_array[$$index];
        $$renderer2.push(`<button${attr_class(`w-full text-left px-3 py-2 rounded-lg border transition-all flex items-center justify-between ${stringify(diagramStore.fontFamily === font.value ? "border-indigo-500 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300" : "border-gray-200 dark:border-gray-700 hover:border-gray-300")}`)}><span${attr_style(`font-family: ${stringify(font.value)}`)}>${escape_html(font.name)}</span> `);
        if (diagramStore.fontFamily === font.value) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<div class="w-2 h-2 rounded-full bg-indigo-500"></div>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--></button>`);
      }
      $$renderer2.push(`<!--]--></div></div> <div><label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">PlantUML Server URL</label> <input type="text"${attr("value", diagramStore.plantumlServerUrl)} placeholder="https://www.plantuml.com/plantuml" class="w-full px-3 py-2 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg text-sm text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-indigo-500 outline-none"/> <p class="mt-1 text-xs text-gray-500">Use a custom server or invalid proxy if you have privacy
                        concerns.</p></div></div> <div class="p-4 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50 flex justify-end"><button class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-medium transition-colors">Done</button></div></div></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
    bind_props($$props, { isOpen });
  });
}
function KeyboardShortcutsModal($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
  });
}
function FindReplaceModal($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
  });
}
function ShareModal($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { isOpen = false, onClose } = $$props;
    let shareUrl = "";
    if (isOpen) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"><div class="bg-white dark:bg-gray-800 rounded-xl shadow-2xl w-full max-w-lg overflow-hidden border border-gray-200 dark:border-gray-700"><div class="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50"><h3 class="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2">`);
      Share_2($$renderer2, { size: 20, class: "text-indigo-500" });
      $$renderer2.push(`<!----> Share Diagram</h3> <button class="p-1 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-lg text-gray-500">`);
      X($$renderer2, { size: 20 });
      $$renderer2.push(`<!----></button></div> <div class="p-6"><div class="flex gap-4 border-b border-gray-200 dark:border-gray-700 mb-6"><button${attr_class(`pb-2 text-sm font-medium transition-colors relative ${stringify(
        "text-indigo-600 dark:text-indigo-400"
      )}`)}><div class="flex items-center gap-2">`);
      Link($$renderer2, { size: 16 });
      $$renderer2.push(`<!----> Share Link</div> `);
      {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="absolute bottom-0 left-0 w-full h-0.5 bg-indigo-600 dark:bg-indigo-400"></div>`);
      }
      $$renderer2.push(`<!--]--></button> <button${attr_class(`pb-2 text-sm font-medium transition-colors relative ${stringify("text-gray-500 hover:text-gray-700")}`)}><div class="flex items-center gap-2">`);
      Code($$renderer2, { size: 16 });
      $$renderer2.push(`<!----> Embed Code</div> `);
      {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></button></div> <div class="space-y-4">`);
      {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="space-y-2"><label class="block text-xs font-medium text-gray-700 dark:text-gray-300">Direct Link (Read Only)</label> <div class="flex gap-2"><input type="text" readonly${attr("value", shareUrl)} class="flex-1 px-3 py-2 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg text-xs font-mono text-gray-600 dark:text-gray-300 outline-none focus:ring-1 focus:ring-indigo-500 select-all"/> <button class="px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition-colors flex items-center justify-center min-w-[80px]">`);
        {
          $$renderer2.push("<!--[!-->");
          Copy($$renderer2, { size: 16 });
          $$renderer2.push(`<!----> <span class="ml-1 text-xs">Copy</span>`);
        }
        $$renderer2.push(`<!--]--></button></div> <p class="text-[10px] text-gray-500">This link contains the entire diagram source
                                code. It works entirely client-side.</p></div>`);
      }
      $$renderer2.push(`<!--]--></div></div></div></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
    bind_props($$props, { isOpen });
  });
}
function DiffModal($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { isOpen = false, onClose, originalCode, modifiedCode } = $$props;
    if (isOpen) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" role="presentation"><div class="bg-white dark:bg-gray-800 rounded-xl shadow-2xl w-full max-w-5xl h-[80vh] flex flex-col overflow-hidden border border-gray-200 dark:border-gray-700" role="dialog"><div class="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50 shrink-0"><h3 class="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2">`);
      Git_compare($$renderer2, { size: 20, class: "text-indigo-500" });
      $$renderer2.push(`<!----> Compare Versions</h3> <button class="p-1 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-lg text-gray-500">`);
      X($$renderer2, { size: 20 });
      $$renderer2.push(`<!----></button></div> <div class="flex-1 p-6 overflow-hidden min-h-0">`);
      DiffViewer($$renderer2, { textA: originalCode, textB: modifiedCode });
      $$renderer2.push(`<!----></div> <div class="p-4 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50 flex justify-end shrink-0"><button class="px-4 py-2 bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 text-gray-800 dark:text-gray-200 rounded-lg font-medium transition-colors">Close</button></div></div></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
    bind_props($$props, { isOpen });
  });
}
function IconModal($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { isOpen = false, onSelect } = $$props;
    let searchTerm = "";
    const ICONS = [
      "account-login",
      "account-logout",
      "action-redo",
      "action-undo",
      "align-center",
      "align-left",
      "align-right",
      "aperture",
      "arrow-bottom",
      "arrow-circle-bottom",
      "arrow-circle-left",
      "arrow-circle-right",
      "arrow-circle-top",
      "arrow-left",
      "arrow-right",
      "arrow-thick-bottom",
      "arrow-thick-left",
      "arrow-thick-right",
      "arrow-thick-top",
      "arrow-top",
      "audio-spectrum",
      "badge",
      "ban",
      "bar-chart",
      "basket",
      "battery-empty",
      "battery-full",
      "beaker",
      "bell",
      "bluetooth",
      "bold",
      "book",
      "bookmark",
      "box",
      "briefcase",
      "british-pound",
      "browser",
      "brush",
      "bug",
      "bullhorn",
      "calculator",
      "calendar",
      "camera-slr",
      "caret-bottom",
      "caret-left",
      "caret-right",
      "caret-top",
      "cart",
      "chat",
      "check",
      "chevron-bottom",
      "chevron-left",
      "chevron-right",
      "chevron-top",
      "circle-check",
      "circle-x",
      "clipboard",
      "clock",
      "cloud",
      "cloud-download",
      "cloud-upload",
      "code",
      "cog",
      "collapse-down",
      "collapse-left",
      "collapse-right",
      "collapse-up",
      "command",
      "comment-square",
      "compass",
      "contrast",
      "copywriting",
      "credit-card",
      "crop",
      "dashboard",
      "data-transfer-download",
      "data-transfer-upload",
      "delete",
      "dial",
      "document",
      "dollar",
      "double-quote-sans-left",
      "double-quote-sans-right",
      "double-quote-serif-left",
      "double-quote-serif-right",
      "droplet",
      "eject",
      "elevator",
      "ellipses",
      "envelope-closed",
      "envelope-open",
      "euro",
      "excerpt",
      "expand-down",
      "expand-left",
      "expand-right",
      "expand-up",
      "external-link",
      "eye",
      "file",
      "fire",
      "flag",
      "flash",
      "folder",
      "fork",
      "fullscreen-enter",
      "fullscreen-exit",
      "globe",
      "graph",
      "grid-four-up",
      "grid-three-up",
      "grid-two-up",
      "hard-drive",
      "header",
      "headphones",
      "heart",
      "home",
      "image",
      "inbox",
      "infinity",
      "info",
      "italic",
      "justify-center",
      "justify-left",
      "justify-right",
      "key",
      "laptop",
      "layers",
      "lightbulb",
      "link-broken",
      "link-intact",
      "list",
      "list-rich",
      "location",
      "lock-locked",
      "lock-unlocked",
      "loop",
      "loop-circular",
      "magnifying-glass",
      "map",
      "map-marker",
      "media-pause",
      "media-play",
      "media-record",
      "media-skip-backward",
      "media-skip-forward",
      "media-step-backward",
      "media-step-forward",
      "media-stop",
      "medical-cross",
      "menu",
      "microphone",
      "minus",
      "monitor",
      "moon",
      "move",
      "musical-note",
      "paperclip",
      "pencil",
      "people",
      "person",
      "phone",
      "pie-chart",
      "pin",
      "play-circle",
      "plus",
      "power-standby",
      "print",
      "project",
      "pulse",
      "puzzle-piece",
      "question-mark",
      "rain",
      "random",
      "reload",
      "resize-both",
      "resize-height",
      "resize-width",
      "rss",
      "rss-alt",
      "script",
      "share",
      "share-boxed",
      "shield",
      "signal",
      "signpost",
      "spreadsheet",
      "star",
      "sun",
      "tablet",
      "tag",
      "tags",
      "target",
      "task",
      "terminal",
      "text",
      "thumb-down",
      "thumb-up",
      "timer",
      "transfer",
      "trash",
      "underline",
      "vertical-align-bottom",
      "vertical-align-center",
      "vertical-align-top",
      "video",
      "volume-high",
      "volume-low",
      "volume-off",
      "warning",
      "wifi",
      "wrench",
      "x",
      "yen",
      "zoom-in",
      "zoom-out"
    ];
    let filteredIcons = ICONS.filter((icon) => icon.toLowerCase().includes(searchTerm.toLowerCase()));
    if (isOpen) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" role="button" tabindex="0"><div class="bg-white dark:bg-gray-800 rounded-xl shadow-2xl w-full max-w-2xl max-h-[80vh] flex flex-col overflow-hidden border border-gray-200 dark:border-gray-700" role="document" tabindex="-1"><div class="p-4 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between"><div class="flex items-center gap-2 text-indigo-600 dark:text-indigo-400">`);
      Grid_3x3($$renderer2, { size: 20 });
      $$renderer2.push(`<!----> <h2 class="font-bold text-lg">Icon Browser</h2></div> <button class="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg text-gray-500">`);
      X($$renderer2, { size: 20 });
      $$renderer2.push(`<!----></button></div> <div class="p-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50"><div class="relative">`);
      Search($$renderer2, {
        class: "absolute left-3 top-1/2 -translate-y-1/2 text-gray-400",
        size: 18
      });
      $$renderer2.push(`<!----> <input type="text"${attr("value", searchTerm)} placeholder="Search icons..." class="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm focus:ring-2 focus:ring-indigo-500 outline-none"/></div> <div class="mt-2 text-xs text-gray-500 flex items-center gap-1">`);
      Info($$renderer2, { size: 12 });
      $$renderer2.push(`<!----> <span>Click to insert PlantUML OpenIconic syntax (e.g.,
                        &lt;&amp;wifi>)</span></div></div> <div class="flex-1 overflow-y-auto p-4 custom-scrollbar svelte-2rszae"><div class="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-2"><!--[-->`);
      const each_array = ensure_array_like(filteredIcons);
      for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
        let icon = each_array[$$index];
        $$renderer2.push(`<button class="flex flex-col items-center justify-center gap-2 p-2 rounded-lg hover:bg-indigo-50 dark:hover:bg-indigo-900/20 hover:text-indigo-600 transition-colors border border-transparent hover:border-indigo-100 dark:hover:border-indigo-800 group"${attr("title", icon)}><div class="w-8 h-8 rounded bg-gray-100 dark:bg-gray-700 flex items-center justify-center text-[10px] font-mono text-gray-500 group-hover:bg-white dark:group-hover:bg-gray-800 group-hover:text-indigo-600 shadow-sm">&lt;&amp;></div> <span class="text-[10px] truncate w-full text-center opacity-70 group-hover:opacity-100">${escape_html(icon)}</span></button>`);
      }
      $$renderer2.push(`<!--]--></div> `);
      if (filteredIcons.length === 0) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="text-center py-12 text-gray-400">No icons found for "${escape_html(searchTerm)}"</div>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></div></div></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
    bind_props($$props, { isOpen });
  });
}
function StatusBar($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { line = 1, col = 1, chars = 0 } = $$props;
    let lintResults = lintDiagram(diagramStore.code, diagramStore.mode);
    let hasIssues = lintResults.length > 0;
    let topIssue = lintResults[0];
    $$renderer2.push(`<div class="flex items-center justify-between px-4 py-1.5 bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800 text-xs text-gray-500 font-mono select-none z-20"><div class="flex items-center gap-4"><span class="font-mono">${escape_html(diagramStore.mode.toUpperCase())}</span> <span class="w-px h-3 bg-gray-300 dark:bg-gray-600"></span> `);
    if (hasIssues) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="flex items-center gap-1.5 text-amber-600 dark:text-amber-400"${attr("title", topIssue.message)}>`);
      Triangle_alert($$renderer2, { size: 14 });
      $$renderer2.push(`<!----> <span class="text-xs font-medium max-w-[200px] truncate">${escape_html(topIssue.message)}</span> `);
      if (lintResults.length > 1) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<span class="text-xs">+${escape_html(lintResults.length - 1)}</span>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<div class="flex items-center gap-1.5 text-green-600 dark:text-green-400">`);
      Circle_check_big($$renderer2, { size: 14 });
      $$renderer2.push(`<!----> <span class="text-xs">Healthy</span></div>`);
    }
    $$renderer2.push(`<!--]--></div> <div class="flex items-center gap-4 text-xs tabular-nums text-gray-500 dark:text-gray-400"><span>Ln ${escape_html(line)}, Col ${escape_html(col)}</span> <span class="w-px h-3 bg-gray-300 dark:bg-gray-700"></span> <span>${escape_html(chars)} chars</span> <span class="w-px h-3 bg-gray-300 dark:bg-gray-700"></span> <span>UTF-8</span></div></div>`);
  });
}
function DiagramSidebar($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { isCollapsed = false, onDiff } = $$props;
    let activeTab = "templates";
    let searchQuery = "";
    let selectedCategory = "All";
    const categories = [
      "All",
      ...Array.from(new Set(TEMPLATES.map((t) => t.category || "Other")))
    ];
    let filteredTemplates = TEMPLATES.filter((t) => {
      const searchLower = searchQuery.toLowerCase();
      const matchesSearch = t.name.toLowerCase().includes(searchLower) || t.code.toLowerCase().includes(searchLower) || t.category && t.category.toLowerCase().includes(searchLower);
      return matchesSearch;
    });
    diagramStore.documents.find((d) => d.id === diagramStore.activeDocumentId);
    $$renderer2.push(`<aside class="h-full bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 flex transition-all duration-300 relative group"${attr_style(`width: ${stringify(isCollapsed ? "48px" : "300px")}`)}><div class="w-12 border-r border-gray-100 dark:border-gray-700/50 flex flex-col items-center py-4 gap-4 shrink-0"><button${attr_class(`p-2 rounded-lg transition-colors ${stringify(
      "bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600"
    )}`)} title="Templates">`);
    Layout_template($$renderer2, { size: 20 });
    $$renderer2.push(`<!----></button> <button${attr_class(`p-2 rounded-lg transition-colors ${stringify("text-gray-400 hover:text-gray-600")}`)} title="Snippets">`);
    Book($$renderer2, { size: 20 });
    $$renderer2.push(`<!----></button> <button${attr_class(`p-2 rounded-lg transition-colors ${stringify("text-gray-400 hover:text-gray-600")}`)} title="AI Assistant">`);
    Sparkles($$renderer2, { size: 20 });
    $$renderer2.push(`<!----></button> <button${attr_class(`p-2 rounded-lg transition-colors ${stringify("text-gray-400 hover:text-gray-600")}`)} title="Local History">`);
    History($$renderer2, { size: 20 });
    $$renderer2.push(`<!----></button> `);
    if (diagramStore.mode === "graphviz") {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<button${attr_class(`p-2 rounded-lg transition-colors ${stringify("text-gray-400 hover:text-gray-600")}`)} title="Layout Parameters">`);
      Settings_2($$renderer2, { size: 20 });
      $$renderer2.push(`<!----></button>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> <button${attr_class(`p-2 rounded-lg transition-colors ${stringify("text-gray-400 hover:text-gray-600")}`)} title="Skins &amp; Themes">`);
    Palette($$renderer2, { size: 20 });
    $$renderer2.push(`<!----></button> <div class="mt-auto"><button class="p-2 text-gray-400 hover:text-gray-600 rounded-lg">`);
    if (isCollapsed) {
      $$renderer2.push("<!--[-->");
      Chevron_right($$renderer2, { size: 20 });
    } else {
      $$renderer2.push("<!--[!-->");
      Chevron_left($$renderer2, { size: 20 });
    }
    $$renderer2.push(`<!--]--></button></div></div> `);
    if (!isCollapsed) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="flex-1 flex flex-col min-w-0"><div class="p-4 border-b border-gray-100 dark:border-gray-700/50 flex items-center justify-between"><h3 class="font-bold text-sm uppercase tracking-wider text-gray-400">${escape_html(activeTab)}</h3></div> <div class="flex-1 overflow-y-auto">`);
      {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="p-3 space-y-3"><div class="relative">`);
        Search($$renderer2, {
          size: 14,
          class: "absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
        });
        $$renderer2.push(`<!----> <input type="text" placeholder="Search templates..."${attr("value", searchQuery)} class="w-full pl-9 pr-3 py-1.5 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg text-xs focus:ring-1 focus:ring-indigo-500 outline-none"/></div> <div class="flex gap-1.5 overflow-x-auto no-scrollbar pb-1 svelte-1x0nv9i"><!--[-->`);
        const each_array = ensure_array_like(categories);
        for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
          let cat = each_array[$$index];
          $$renderer2.push(`<button${attr_class(`px-2 py-0.5 rounded-full text-[10px] font-medium whitespace-nowrap border transition-all ${stringify(selectedCategory === cat ? "bg-indigo-600 border-indigo-600 text-white" : "bg-gray-100 dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-gray-500")}`)}>${escape_html(cat)}</button>`);
        }
        $$renderer2.push(`<!--]--></div> <div class="space-y-2"><!--[-->`);
        const each_array_1 = ensure_array_like(filteredTemplates);
        for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
          let t = each_array_1[$$index_1];
          $$renderer2.push(`<div class="w-full text-left p-2 rounded-lg border border-transparent hover:border-indigo-200 dark:hover:border-indigo-900/50 hover:bg-indigo-50/50 dark:hover:bg-indigo-900/10 transition-all group relative cursor-grab active:cursor-grabbing" role="button" tabindex="0" draggable="true"><div class="flex items-center justify-between mb-1"><div class="flex items-center gap-1.5 overflow-hidden">`);
          Grip_vertical($$renderer2, {
            size: 12,
            class: "text-gray-300 opacity-0 group-hover:opacity-100 transition-opacity"
          });
          $$renderer2.push(`<!----> <span class="text-xs font-semibold text-gray-700 dark:text-gray-300 group-hover:text-indigo-600 truncate">${escape_html(t.name)}</span></div> <span class="text-[9px] uppercase px-1 rounded bg-gray-100 dark:bg-gray-700 text-gray-400">${escape_html(t.mode)}</span></div> <p class="text-[10px] text-gray-400 line-clamp-1 font-mono pl-4">${escape_html(t.code)}</p></div>`);
        }
        $$renderer2.push(`<!--]--></div></div>`);
      }
      $$renderer2.push(`<!--]--></div></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--></aside>`);
    bind_props($$props, { isCollapsed });
  });
}
function HistoryModal($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { isOpen = false, onClose, onDiff } = $$props;
    let activeHistory = diagramStore.documents.find((d) => d.id === diagramStore.activeDocumentId)?.history || [];
    let sortedHistory = [...activeHistory].reverse();
    function formatTime(ts) {
      return new Date(ts).toLocaleTimeString();
    }
    if (isOpen) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" role="button" tabindex="0"><div class="bg-white dark:bg-gray-800 rounded-xl shadow-2xl w-full max-w-lg overflow-hidden border border-gray-200 dark:border-gray-700 max-h-[80vh] flex flex-col" role="dialog" aria-modal="true" tabindex="-1"><div class="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50 shrink-0"><h3 class="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2">`);
      History($$renderer2, { size: 20, class: "text-indigo-500" });
      $$renderer2.push(`<!----> Local History</h3> <button class="p-1 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-lg text-gray-500">`);
      X($$renderer2, { size: 20 });
      $$renderer2.push(`<!----></button></div> <div class="flex-1 overflow-y-auto p-2 space-y-2">`);
      if (sortedHistory.length === 0) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="text-center py-10 text-gray-500">`);
        Clock($$renderer2, { class: "mx-auto mb-2 opacity-50" });
        $$renderer2.push(`<!----> <p>No history yet.</p></div>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> <!--[-->`);
      const each_array = ensure_array_like(sortedHistory);
      for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
        let item = each_array[$$index];
        $$renderer2.push(`<div class="p-3 bg-white dark:bg-gray-900/30 rounded-lg border border-gray-100 dark:border-gray-700 hover:border-indigo-300 dark:hover:border-indigo-700 transition-colors group flex items-center justify-between"><div class="flex items-center gap-3"><div class="p-2 rounded-full bg-indigo-50 dark:bg-indigo-900/20 text-indigo-500 font-mono text-xs">${escape_html(formatTime(item.timestamp))}</div> <div class="text-xs text-gray-500">${escape_html(item.code.length)} chars</div></div> <div class="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity"><button class="p-1.5 text-gray-500 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 rounded" title="Diff with Current">`);
        Git_compare($$renderer2, { size: 14 });
        $$renderer2.push(`<!----></button> <button class="p-1.5 text-gray-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/30 rounded" title="Restore Version">`);
        Rotate_ccw($$renderer2, { size: 14 });
        $$renderer2.push(`<!----></button></div></div>`);
      }
      $$renderer2.push(`<!--]--></div> <div class="p-3 text-xs text-center text-gray-400 border-t border-gray-100 dark:border-gray-800 shrink-0">Snapshots are taken automatically after changes.</div></div></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
    bind_props($$props, { isOpen });
  });
}
function AccessibilityViewModal($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { isOpen = false, onClose } = $$props;
    let nodes = (() => {
      const matches = diagramStore.code.matchAll(/^(?:class|interface|component|node|state)\s+(\w+)(?:\s+as\s+(\w+))?/gm);
      return Array.from(matches).map((m) => ({ type: "Node", id: m[1], label: m[2] || m[1] }));
    })();
    let edges = (() => {
      const matches = diagramStore.code.matchAll(/(\w+)\s*-+>\s*(\w+)(?:\s*:\s*(.+))?/g);
      return Array.from(matches).map((m) => ({ source: m[1], target: m[2], label: m[3] || "" }));
    })();
    if (isOpen) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" role="button" tabindex="0"><div class="bg-white dark:bg-gray-800 rounded-xl shadow-2xl w-full max-w-2xl overflow-hidden border border-gray-200 dark:border-gray-700 flex flex-col max-h-[85vh]" role="dialog" aria-label="Accessibility View" tabindex="-1"><div class="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50 shrink-0"><h3 class="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2">`);
      Table($$renderer2, { size: 20, class: "text-indigo-500" });
      $$renderer2.push(`<!----> Structure View (Accessibility)</h3> <button class="p-1 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-lg text-gray-500">`);
      X($$renderer2, { size: 20 });
      $$renderer2.push(`<!----></button></div> <div class="flex-1 overflow-y-auto p-6 space-y-6"><div><h4 class="font-bold text-gray-700 dark:text-gray-300 mb-2 flex items-center gap-2">`);
      List($$renderer2, { size: 16 });
      $$renderer2.push(`<!----> Nodes (${escape_html(nodes.length)})</h4> <div class="border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden"><table class="w-full text-sm text-left"><thead class="bg-gray-50 dark:bg-gray-900 text-gray-500 font-medium border-b border-gray-200 dark:border-gray-700"><tr><th class="px-4 py-2">ID</th><th class="px-4 py-2">Label</th><th class="px-4 py-2">Type</th></tr></thead><tbody><!--[-->`);
      const each_array = ensure_array_like(nodes);
      for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
        let node = each_array[$$index];
        $$renderer2.push(`<tr class="border-b border-gray-100 dark:border-gray-800 last:border-0 hover:bg-gray-50 dark:hover:bg-gray-800/50"><td class="px-4 py-2 font-mono text-indigo-600 dark:text-indigo-400">${escape_html(node.id)}</td><td class="px-4 py-2 text-gray-700 dark:text-gray-300">${escape_html(node.label)}</td><td class="px-4 py-2 text-gray-500">${escape_html(node.type)}</td></tr>`);
      }
      $$renderer2.push(`<!--]-->`);
      if (nodes.length === 0) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<tr><td colspan="3" class="px-4 py-4 text-center text-gray-500 text-xs italic">No explicit nodes detected.</td></tr>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></tbody></table></div></div> <div><h4 class="font-bold text-gray-700 dark:text-gray-300 mb-2 flex items-center gap-2">`);
      List($$renderer2, { size: 16 });
      $$renderer2.push(`<!----> Relationships (${escape_html(edges.length)})</h4> <div class="border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden"><table class="w-full text-sm text-left"><thead class="bg-gray-50 dark:bg-gray-900 text-gray-500 font-medium border-b border-gray-200 dark:border-gray-700"><tr><th class="px-4 py-2">Source</th><th class="px-4 py-2">Target</th><th class="px-4 py-2">Label</th></tr></thead><tbody><!--[-->`);
      const each_array_1 = ensure_array_like(edges);
      for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
        let edge = each_array_1[$$index_1];
        $$renderer2.push(`<tr class="border-b border-gray-100 dark:border-gray-800 last:border-0 hover:bg-gray-50 dark:hover:bg-gray-800/50"><td class="px-4 py-2 font-mono text-indigo-600 dark:text-indigo-400">${escape_html(edge.source)}</td><td class="px-4 py-2 font-mono text-indigo-600 dark:text-indigo-400">${escape_html(edge.target)}</td><td class="px-4 py-2 text-gray-700 dark:text-gray-300">${escape_html(edge.label || "-")}</td></tr>`);
      }
      $$renderer2.push(`<!--]-->`);
      if (edges.length === 0) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<tr><td colspan="3" class="px-4 py-4 text-center text-gray-500 text-xs italic">No explicit edges detected.</td></tr>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></tbody></table></div></div></div></div></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
    bind_props($$props, { isOpen });
  });
}
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let isSidebarCollapsed = false;
    let isSnippetModalOpen = false;
    let isExportModalOpen = false;
    let isTemplatesModalOpen = false;
    let isSettingsModalOpen = false;
    let isShareModalOpen = false;
    let isDiffModalOpen = false;
    let isIconModalOpen = false;
    let isHistoryModalOpen = false;
    let isAccessibilityViewOpen = false;
    let diffOriginal = "";
    let diffModified = "";
    let cursorLine = 1;
    let cursorCol = 1;
    let splitPercent = 50;
    function handleRender() {
      diagramStore.render();
    }
    function handleCursorChange(line, col) {
      cursorLine = line;
      cursorCol = col;
    }
    function handleDiff(originalCode) {
      diffOriginal = originalCode;
      diffModified = diagramStore.code;
      isDiffModalOpen = true;
    }
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      head("19w7mte", $$renderer3, ($$renderer4) => {
        $$renderer4.title(($$renderer5) => {
          $$renderer5.push(`<title>Diagram Editor</title>`);
        });
      });
      $$renderer3.push(`<div${attr_class(`h-[calc(100vh-3rem)] w-full flex flex-col bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100 overflow-hidden font-sans rounded-xl border border-gray-200 dark:border-gray-800 shadow-sm transition-all duration-300 ${stringify(diagramStore.focusMode ? "fixed inset-0 z-50 h-screen rounded-none border-none" : "")}`)}><div${attr_class(`transition-all duration-300 ${stringify(diagramStore.focusMode ? "hidden" : "")}`)}>`);
      Header($$renderer3);
      $$renderer3.push(`<!----> `);
      TabsBar($$renderer3);
      $$renderer3.push(`<!----></div> <div class="flex-1 flex min-h-0 relative"><div${attr_class(`transition-all duration-300 ${stringify(diagramStore.focusMode ? "hidden" : "")}`)}>`);
      DiagramSidebar($$renderer3, {
        onDiff: handleDiff,
        get isCollapsed() {
          return isSidebarCollapsed;
        },
        set isCollapsed($$value) {
          isSidebarCollapsed = $$value;
          $$settled = false;
        }
      });
      $$renderer3.push(`<!----></div> <div${attr_style(`width: ${stringify(diagramStore.focusMode ? 50 : splitPercent)}%`)} class="h-full flex flex-col min-w-0 transition-all duration-300"><div class="relative h-full flex flex-col">`);
      if (diagramStore.focusMode) {
        $$renderer3.push("<!--[-->");
        $$renderer3.push(`<button class="absolute top-2 right-4 z-50 bg-black/50 hover:bg-black/70 text-white px-3 py-1 rounded-full text-xs backdrop-blur-sm transition-colors">Exit Zen Mode (Esc)</button>`);
      } else {
        $$renderer3.push("<!--[!-->");
      }
      $$renderer3.push(`<!--]--> `);
      Editor($$renderer3, {
        mode: diagramStore.mode,
        onRender: handleRender,
        onCursorChange: handleCursorChange,
        get code() {
          return diagramStore.code;
        },
        set code($$value) {
          diagramStore.code = $$value;
          $$settled = false;
        }
      });
      $$renderer3.push(`<!----></div></div>  <div${attr_class(`w-2 hover:bg-indigo-500/50 hover:cursor-col-resize flex items-center justify-center bg-gray-200 dark:bg-gray-800 transition-colors z-10 focus:outline-none ${stringify(diagramStore.focusMode ? "pointer-events-none opacity-0 w-0" : "")}`)} role="separator"><div class="w-0.5 h-8 bg-gray-400 rounded"></div></div> <div class="flex-1 h-full min-w-0">`);
      Preview($$renderer3, {
        svg: diagramStore.svg,
        isRendering: diagramStore.isRendering
      });
      $$renderer3.push(`<!----></div> `);
      if (diagramStore.isInspectorOpen && !diagramStore.focusMode) {
        $$renderer3.push("<!--[-->");
        Inspector($$renderer3, {
          get isPinned() {
            return diagramStore.isSidebarPinned;
          },
          set isPinned($$value) {
            diagramStore.isSidebarPinned = $$value;
            $$settled = false;
          }
        });
      } else {
        $$renderer3.push("<!--[!-->");
      }
      $$renderer3.push(`<!--]--></div> <div${attr_class(`transition-all duration-300 ${stringify(diagramStore.focusMode ? "hidden" : "")}`)}>`);
      StatusBar($$renderer3, {
        line: cursorLine,
        col: cursorCol,
        chars: diagramStore.code.length
      });
      $$renderer3.push(`<!----></div> `);
      {
        $$renderer3.push("<!--[!-->");
      }
      $$renderer3.push(`<!--]--> `);
      SnippetModal($$renderer3, {
        onClose: () => isSnippetModalOpen = false,
        get isOpen() {
          return isSnippetModalOpen;
        },
        set isOpen($$value) {
          isSnippetModalOpen = $$value;
          $$settled = false;
        }
      });
      $$renderer3.push(`<!----> `);
      ExportModal($$renderer3, {
        onClose: () => isExportModalOpen = false,
        get isOpen() {
          return isExportModalOpen;
        },
        set isOpen($$value) {
          isExportModalOpen = $$value;
          $$settled = false;
        }
      });
      $$renderer3.push(`<!----> `);
      TemplatesModal($$renderer3, {
        get isOpen() {
          return isTemplatesModalOpen;
        },
        set isOpen($$value) {
          isTemplatesModalOpen = $$value;
          $$settled = false;
        }
      });
      $$renderer3.push(`<!----> `);
      SettingsModal($$renderer3, {
        onClose: () => isSettingsModalOpen = false,
        get isOpen() {
          return isSettingsModalOpen;
        },
        set isOpen($$value) {
          isSettingsModalOpen = $$value;
          $$settled = false;
        }
      });
      $$renderer3.push(`<!----> `);
      KeyboardShortcutsModal($$renderer3);
      $$renderer3.push(`<!----> `);
      FindReplaceModal($$renderer3, {
        code: diagramStore.code
      });
      $$renderer3.push(`<!----> `);
      ShareModal($$renderer3, {
        isOpen: isShareModalOpen,
        onClose: () => isShareModalOpen = false
      });
      $$renderer3.push(`<!----> `);
      DiffModal($$renderer3, {
        isOpen: isDiffModalOpen,
        onClose: () => isDiffModalOpen = false,
        originalCode: diffOriginal,
        modifiedCode: diffModified
      });
      $$renderer3.push(`<!----> `);
      IconModal($$renderer3, {
        isOpen: isIconModalOpen,
        onSelect: (icon) => {
          const insertion = ` <&${icon}> `;
          diagramStore.code += insertion;
          diagramStore.render();
        }
      });
      $$renderer3.push(`<!----> `);
      HistoryModal($$renderer3, {
        isOpen: isHistoryModalOpen,
        onClose: () => isHistoryModalOpen = false,
        onDiff: (code) => {
          handleDiff(code);
          isHistoryModalOpen = false;
        }
      });
      $$renderer3.push(`<!----> `);
      AccessibilityViewModal($$renderer3, {
        isOpen: isAccessibilityViewOpen,
        onClose: () => isAccessibilityViewOpen = false
      });
      $$renderer3.push(`<!----> `);
      {
        $$renderer3.push("<!--[!-->");
      }
      $$renderer3.push(`<!--]--></div>`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
  });
}
export {
  _page as default
};
