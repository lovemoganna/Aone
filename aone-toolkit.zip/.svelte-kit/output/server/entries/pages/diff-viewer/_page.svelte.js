import { Z as sanitize_props, _ as spread_props, $ as slot, a7 as head, a0 as attr_class, a4 as ensure_array_like, a1 as stringify } from "../../../chunks/index2.js";
import "diff";
import { I as Icon } from "../../../chunks/Icon.js";
import { T as Trash_2 } from "../../../chunks/trash-2.js";
import { e as escape_html } from "../../../chunks/context.js";
function Arrow_right_left($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    ["path", { "d": "m16 3 4 4-4 4" }],
    ["path", { "d": "M20 7H4" }],
    ["path", { "d": "m8 21-4-4 4-4" }],
    ["path", { "d": "M4 17h16" }]
  ];
  Icon($$renderer, spread_props([
    { name: "arrow-right-left" },
    $$sanitized_props,
    {
      /**
       * @component @name ArrowRightLeft
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJtMTYgMyA0IDQtNCA0IiAvPgogIDxwYXRoIGQ9Ik0yMCA3SDQiIC8+CiAgPHBhdGggZD0ibTggMjEtNC00IDQtNCIgLz4KICA8cGF0aCBkPSJNNCAxN2gxNiIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/arrow-right-left
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Split($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    ["path", { "d": "M16 3h5v5" }],
    ["path", { "d": "M8 3H3v5" }],
    ["path", { "d": "M12 22v-8.3a4 4 0 0 0-1.172-2.872L3 3" }],
    ["path", { "d": "m15 9 6-6" }]
  ];
  Icon($$renderer, spread_props([
    { name: "split" },
    $$sanitized_props,
    {
      /**
       * @component @name Split
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTYgM2g1djUiIC8+CiAgPHBhdGggZD0iTTggM0gzdjUiIC8+CiAgPHBhdGggZD0iTTEyIDIydi04LjNhNCA0IDAgMCAwLTEuMTcyLTIuODcyTDMgMyIgLz4KICA8cGF0aCBkPSJtMTUgOSA2LTYiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/split
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let oldText = "";
    let newText = "";
    let diffs = [];
    head("by6mnr", $$renderer2, ($$renderer3) => {
      $$renderer3.title(($$renderer4) => {
        $$renderer4.push(`<title>Diff Viewer</title>`);
      });
    });
    $$renderer2.push(`<div class="min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100 p-4 lg:p-8 flex flex-col gap-6"><div class="flex items-center justify-between"><h1 class="text-2xl font-bold flex items-center gap-3"><div class="w-10 h-10 rounded-xl bg-orange-500 flex items-center justify-center text-white shadow-lg shadow-orange-500/30">`);
    Split($$renderer2, { size: 24 });
    $$renderer2.push(`<!----></div> Diff Viewer</h1> <div class="flex items-center gap-2"><div class="flex bg-gray-200 dark:bg-gray-800 rounded-lg p-1"><button${attr_class(`px-3 py-1.5 rounded-md text-sm font-medium transition-all ${stringify(
      "bg-white dark:bg-gray-700 shadow-sm text-indigo-600 dark:text-indigo-400"
    )}`)}>Lines</button> <button${attr_class(`px-3 py-1.5 rounded-md text-sm font-medium transition-all ${stringify("text-gray-500 hover:text-gray-700 dark:text-gray-400")}`)}>Chars</button></div></div></div> <div class="grid grid-cols-1 md:grid-cols-2 gap-4 h-96"><div class="flex flex-col gap-2 h-full"><label class="text-sm font-medium text-gray-600 dark:text-gray-400">Original Text</label> <textarea class="flex-1 w-full bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl p-4 font-mono text-sm resize-none focus:ring-2 focus:ring-indigo-500 outline-none" placeholder="Paste original text here...">`);
    const $$body = escape_html(oldText);
    if ($$body) {
      $$renderer2.push(`${$$body}`);
    }
    $$renderer2.push(`</textarea></div> <div class="flex flex-col gap-2 h-full"><label class="text-sm font-medium text-gray-600 dark:text-gray-400">New Text</label> <textarea class="flex-1 w-full bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl p-4 font-mono text-sm resize-none focus:ring-2 focus:ring-indigo-500 outline-none" placeholder="Paste new text here...">`);
    const $$body_1 = escape_html(newText);
    if ($$body_1) {
      $$renderer2.push(`${$$body_1}`);
    }
    $$renderer2.push(`</textarea></div></div> <div class="flex items-center gap-4"><button class="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-medium shadow-sm transition-colors flex items-center gap-2">`);
    Split($$renderer2, { size: 18 });
    $$renderer2.push(`<!----> Compare</button> <button class="px-4 py-2.5 bg-white dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-200 border border-gray-200 dark:border-gray-700 rounded-lg font-medium transition-colors flex items-center gap-2">`);
    Arrow_right_left($$renderer2, { size: 18 });
    $$renderer2.push(`<!----> Swap</button> <button class="px-4 py-2.5 bg-white dark:bg-gray-800 hover:bg-red-50 dark:hover:bg-red-900/10 text-red-600 dark:text-red-400 border border-gray-200 dark:border-gray-700 rounded-lg font-medium transition-colors flex items-center gap-2 ml-auto">`);
    Trash_2($$renderer2, { size: 18 });
    $$renderer2.push(`<!----> Clear</button></div> `);
    if (diffs.length > 0) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="flex flex-col gap-2"><h2 class="text-lg font-semibold text-gray-800 dark:text-gray-200">Differences</h2> <div class="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl overflow-hidden font-mono text-sm"><!--[-->`);
      const each_array = ensure_array_like(diffs);
      for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
        let part = each_array[$$index];
        $$renderer2.push(`<div${attr_class(`px-4 py-1 whitespace-pre-wrap break-all border-b last:border-0 border-gray-100 dark:border-gray-700/50 ${stringify(part.added ? "bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-300" : part.removed ? "bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-300" : "text-gray-600 dark:text-gray-400")}`)}><span class="mr-2 select-none opacity-50 font-bold">${escape_html(part.added ? "+" : part.removed ? "-" : " ")}</span> ${escape_html(part.value)}</div>`);
      }
      $$renderer2.push(`<!--]--></div></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--></div>`);
  });
}
export {
  _page as default
};
