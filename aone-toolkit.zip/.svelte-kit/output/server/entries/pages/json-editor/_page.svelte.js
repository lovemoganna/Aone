import { a0 as attr_class, a6 as bind_props, a4 as ensure_array_like, a7 as head } from "../../../chunks/index2.js";
import { B as Button } from "../../../chunks/Button.js";
import { o as onDestroy } from "../../../chunks/index-server.js";
import { Compartment } from "@codemirror/state";
import { I as Input } from "../../../chunks/Input.js";
import { JSONPath } from "jsonpath-plus";
import { e as escape_html } from "../../../chunks/context.js";
import { T as TypeGenModal } from "../../../chunks/TypeGenModal.js";
import "clsx";
import "js-yaml";
import "../../../chunks/sidebar.js";
function JsonCodeEditor($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { value = void 0, isDark, onChange } = $$props;
    new Compartment();
    onDestroy(() => {
    });
    $$renderer2.push(`<div${attr_class("h-full w-full text-base", void 0, { "cm-dark": isDark })}></div>`);
    bind_props($$props, { value });
  });
}
function JsonPathPanel($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { data, isHidden } = $$props;
    let query = "";
    let results = [];
    let error = "";
    function executeQuery() {
      error = "";
      results = [];
      if (!query.trim()) return;
      try {
        const res = JSONPath({ path: query, json: data, wrap: true });
        results = res;
      } catch (e) {
        error = e.message;
      }
    }
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      if (!isHidden) {
        $$renderer3.push("<!--[-->");
        $$renderer3.push(`<div class="absolute bottom-4 right-4 z-40 w-96 bg-white dark:bg-slate-900 rounded-lg shadow-xl border border-slate-200 dark:border-slate-800 flex flex-col max-h-[500px]"><div class="flex items-center justify-between p-3 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 rounded-t-lg"><h3 class="font-medium text-sm text-slate-700 dark:text-slate-200">JSONPath Query</h3> <button class="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200" aria-label="Close query panel"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-x"><path d="M18 6 6 18"></path><path d="m6 6 18 18"></path></svg></button></div> <div class="p-3 space-y-3 flex-1 overflow-hidden flex flex-col"><div class="relative">`);
        Input($$renderer3, {
          placeholder: "$.store.book[*].author",
          onkeydown: (e) => e.key === "Enter" && executeQuery(),
          get value() {
            return query;
          },
          set value($$value) {
            query = $$value;
            $$settled = false;
          }
        });
        $$renderer3.push(`<!----> <button class="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-primary-500" aria-label="Execute query"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-play"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg></button></div> <div class="text-xs text-slate-500 space-x-2"><button class="hover:underline">$</button> <button class="hover:underline">$..*</button></div> `);
        if (error) {
          $$renderer3.push("<!--[-->");
          $$renderer3.push(`<div class="text-xs text-red-500 bg-red-50 dark:bg-red-900/20 p-2 rounded">${escape_html(error)}</div>`);
        } else {
          $$renderer3.push("<!--[!-->");
        }
        $$renderer3.push(`<!--]--> <div class="flex-1 overflow-auto bg-slate-50 dark:bg-slate-950 rounded p-2 border border-slate-100 dark:border-slate-800 font-mono text-xs">`);
        if (results.length > 0) {
          $$renderer3.push("<!--[-->");
          $$renderer3.push(`<div class="space-y-1"><!--[-->`);
          const each_array = ensure_array_like(results);
          for (let i = 0, $$length = each_array.length; i < $$length; i++) {
            let res = each_array[i];
            $$renderer3.push(`<div class="border-b border-slate-200 dark:border-slate-800 last:border-0 pb-1 mb-1"><span class="text-slate-400 select-none mr-2">[${escape_html(i)}]</span> <span class="text-slate-700 dark:text-slate-300 break-all">${escape_html(typeof res === "object" ? JSON.stringify(res) : String(res))}</span></div>`);
          }
          $$renderer3.push(`<!--]--></div>`);
        } else {
          $$renderer3.push("<!--[!-->");
          if (query && !error) {
            $$renderer3.push("<!--[-->");
            $$renderer3.push(`<div class="text-slate-400 italic text-center mt-4">No matches</div>`);
          } else {
            $$renderer3.push("<!--[!-->");
          }
          $$renderer3.push(`<!--]-->`);
        }
        $$renderer3.push(`<!--]--></div></div></div>`);
      } else {
        $$renderer3.push("<!--[!-->");
      }
      $$renderer3.push(`<!--]-->`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
  });
}
function ToolsModal($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { isOpen, jsonData, onUpdate, onClose } = $$props;
    function sortKeys(obj) {
      if (Array.isArray(obj)) {
        return obj.map(sortKeys);
      } else if (obj !== null && typeof obj === "object") {
        return Object.keys(obj).sort().reduce(
          (acc, key) => {
            acc[key] = sortKeys(obj[key]);
            return acc;
          },
          {}
        );
      }
      return obj;
    }
    function cleanData(obj) {
      if (Array.isArray(obj)) {
        return obj.map(cleanData).filter((v) => v !== null && v !== void 0);
      } else if (obj !== null && typeof obj === "object") {
        return Object.keys(obj).reduce(
          (acc, key) => {
            const val = cleanData(obj[key]);
            if (val !== null && val !== void 0) {
              acc[key] = val;
            }
            return acc;
          },
          {}
        );
      }
      return obj;
    }
    function downloadCsv() {
      if (!jsonData) return;
      let data = Array.isArray(jsonData) ? jsonData : [jsonData];
      if (data.length === 0) return;
      const headers = Array.from(new Set(data.flatMap((row) => row && typeof row === "object" ? Object.keys(row) : [])));
      const csvRows = [
        headers.join(","),
        ...data.map((row) => {
          return headers.map((header) => {
            const val = row[header];
            if (val === null || val === void 0) return "";
            const str = typeof val === "object" ? JSON.stringify(val) : String(val);
            return `"${str.replace(/"/g, '""')}"`;
          }).join(",");
        })
      ];
      const blob = new Blob([csvRows.join("\n")], { type: "text/csv" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "export.csv";
      a.click();
      URL.revokeObjectURL(url);
      onClose();
    }
    function copyEscaped() {
      JSON.stringify(jsonData);
      const escaped = JSON.stringify(JSON.stringify(jsonData));
      const content = escaped.slice(1, -1);
      navigator.clipboard.writeText(content);
      alert("Escaped JSON copied to clipboard!");
      onClose();
    }
    function handleUpdate(action) {
      let newData = jsonData;
      if (action === "sort") newData = sortKeys(jsonData);
      if (action === "clean") newData = cleanData(jsonData);
      onUpdate(newData);
      onClose();
    }
    if (isOpen) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"><div class="bg-white dark:bg-slate-900 rounded-lg shadow-xl w-full max-w-md"><div class="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between"><h3 class="text-lg font-semibold text-slate-900 dark:text-white">JSON Tools</h3> <button class="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-x"><path d="M18 6 6 18"></path><path d="m6 6 18 18"></path></svg></button></div> <div class="p-4 grid grid-cols-1 gap-3"><h4 class="text-xs font-semibold text-slate-500 uppercase mt-1">Structure</h4> `);
      Button($$renderer2, {
        variant: "secondary",
        onclick: () => handleUpdate("sort"),
        class: "justify-start",
        children: ($$renderer3) => {
          $$renderer3.push(`<span class="mr-2">🔤</span> Sort Keys (Recursive)`);
        },
        $$slots: { default: true }
      });
      $$renderer2.push(`<!----> `);
      Button($$renderer2, {
        variant: "secondary",
        onclick: () => handleUpdate("clean"),
        class: "justify-start",
        children: ($$renderer3) => {
          $$renderer3.push(`<span class="mr-2">🧹</span> Clean Data (Remove Nulls)`);
        },
        $$slots: { default: true }
      });
      $$renderer2.push(`<!----> <h4 class="text-xs font-semibold text-slate-500 uppercase mt-2">Export / Util</h4> `);
      Button($$renderer2, {
        variant: "secondary",
        onclick: downloadCsv,
        class: "justify-start",
        children: ($$renderer3) => {
          $$renderer3.push(`<span class="mr-2">📊</span> Download as CSV`);
        },
        $$slots: { default: true }
      });
      $$renderer2.push(`<!----> `);
      Button($$renderer2, {
        variant: "secondary",
        onclick: copyEscaped,
        class: "justify-start",
        children: ($$renderer3) => {
          $$renderer3.push(`<span class="mr-2">📋</span> Copy Escaped String`);
        },
        $$slots: { default: true }
      });
      $$renderer2.push(`<!----></div></div></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
  });
}
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let jsonContent = '{\n  "name": "Example",\n  "version": 1,\n  "items": [\n    {"id": 1, "active": true},\n    {"id": 2, "active": false}\n  ]\n}';
    let parsedData = null;
    let isDark = false;
    let showPathQuery = false;
    let showTypeGen = false;
    let showTools = false;
    function handleToolsUpdate(newData) {
      if (newData) {
        jsonContent = JSON.stringify(newData, null, 2);
      }
    }
    function format() {
    }
    function minify() {
    }
    function save() {
      const blob = new Blob([jsonContent], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "data.json";
      a.click();
      URL.revokeObjectURL(url);
    }
    function convertToYaml() {
    }
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      head("1skhz2r", $$renderer3, ($$renderer4) => {
        $$renderer4.title(($$renderer5) => {
          $$renderer5.push(`<title>JSON Editor - Aone Toolkit</title>`);
        });
      });
      $$renderer3.push(`<div class="h-[calc(100vh-3rem)]"><div class="h-full flex flex-col bg-white dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 shadow-soft"><div class="px-4 py-3 border-b border-slate-200 dark:border-slate-700 shrink-0"><div class="flex items-center justify-between"><div class="flex items-center gap-3"><div class="w-8 h-8 rounded-lg bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center text-emerald-600 dark:text-emerald-400"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h-5"><path stroke-linecap="round" stroke-linejoin="round" d="M17.25 6.75 22.5 12l-5.25 5.25m-10.5 0L1.5 12l5.25-5.25m7.5-3-4.5 16.5"></path></svg></div> <div class="flex flex-col"><h1 class="text-lg font-semibold text-slate-900 dark:text-white">JSON Editor</h1> `);
      {
        $$renderer3.push("<!--[!-->");
      }
      $$renderer3.push(`<!--]--></div></div> <div class="flex items-center gap-2">`);
      Button($$renderer3, {
        variant: "ghost",
        size: "sm",
        onclick: () => showPathQuery = !showPathQuery,
        children: ($$renderer4) => {
          $$renderer4.push(`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-search mr-2"><circle cx="11" cy="11" r="8"></circle><path d="m21 21-4.3-4.3"></path></svg> Query`);
        },
        $$slots: { default: true }
      });
      $$renderer3.push(`<!----> <div class="h-4 w-px bg-slate-200 dark:bg-slate-700 mx-1"></div> `);
      Button($$renderer3, {
        variant: "secondary",
        size: "sm",
        onclick: () => showTools = true,
        children: ($$renderer4) => {
          $$renderer4.push(`<!---->Tools`);
        },
        $$slots: { default: true }
      });
      $$renderer3.push(`<!----> `);
      Button($$renderer3, {
        variant: "secondary",
        size: "sm",
        onclick: format,
        children: ($$renderer4) => {
          $$renderer4.push(`<!---->Format`);
        },
        $$slots: { default: true }
      });
      $$renderer3.push(`<!----> `);
      Button($$renderer3, {
        variant: "secondary",
        size: "sm",
        onclick: minify,
        children: ($$renderer4) => {
          $$renderer4.push(`<!---->Minify`);
        },
        $$slots: { default: true }
      });
      $$renderer3.push(`<!----> `);
      Button($$renderer3, {
        variant: "secondary",
        size: "sm",
        onclick: () => showTypeGen = true,
        children: ($$renderer4) => {
          $$renderer4.push(`<!---->Gen Types`);
        },
        $$slots: { default: true }
      });
      $$renderer3.push(`<!----> `);
      Button($$renderer3, {
        variant: "secondary",
        size: "sm",
        onclick: convertToYaml,
        children: ($$renderer4) => {
          $$renderer4.push(`<!---->Copy YAML`);
        },
        $$slots: { default: true }
      });
      $$renderer3.push(`<!----> `);
      Button($$renderer3, {
        variant: "primary",
        size: "sm",
        onclick: save,
        children: ($$renderer4) => {
          $$renderer4.push(`<!---->Save`);
        },
        $$slots: { default: true }
      });
      $$renderer3.push(`<!----></div></div></div> <div class="flex-1 flex overflow-hidden"><div class="flex-1 border-r border-slate-200 dark:border-slate-800 relative group min-w-0">`);
      JsonCodeEditor($$renderer3, {
        isDark,
        get value() {
          return jsonContent;
        },
        set value($$value) {
          jsonContent = $$value;
          $$settled = false;
        }
      });
      $$renderer3.push(`<!----> `);
      {
        $$renderer3.push("<!--[!-->");
      }
      $$renderer3.push(`<!--]--></div> <div class="w-1/3 min-w-[300px] max-w-[500px] bg-slate-50 dark:bg-slate-900 flex flex-col border-l border-slate-200 dark:border-slate-800"><div class="p-2 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center shrink-0"><span class="text-xs font-semibold text-slate-500 uppercase">Structure</span> <div class="flex gap-2"><button class="text-xs text-blue-500 hover:underline">Expand All</button> <span class="text-slate-300">|</span> <button class="text-xs text-blue-500 hover:underline">Collapse All</button></div></div> <div class="flex-1 overflow-auto p-2">`);
      {
        $$renderer3.push("<!--[!-->");
        $$renderer3.push(`<div class="h-full flex items-center justify-center text-slate-400 text-sm italic">${escape_html("Empty")}</div>`);
      }
      $$renderer3.push(`<!--]--></div></div></div> `);
      JsonPathPanel($$renderer3, {
        data: parsedData,
        isHidden: !showPathQuery
      });
      $$renderer3.push(`<!----> `);
      TypeGenModal($$renderer3, {
        isOpen: showTypeGen,
        jsonData: parsedData,
        onClose: () => showTypeGen = false
      });
      $$renderer3.push(`<!----> `);
      ToolsModal($$renderer3, {
        isOpen: showTools,
        jsonData: parsedData,
        onUpdate: handleToolsUpdate,
        onClose: () => showTools = false
      });
      $$renderer3.push(`<!----></div></div>`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
  });
}
export {
  _page as default
};
