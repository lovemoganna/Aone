import { Z as sanitize_props, _ as spread_props, $ as slot, a7 as head, a4 as ensure_array_like, a3 as attr } from "../../../chunks/index2.js";
import { B as Button } from "../../../chunks/Button.js";
import { P as Panel } from "../../../chunks/Panel.js";
import { faker } from "@faker-js/faker";
import { t as toMarkdown, a as toSQL, b as toCSV, c as toJSON } from "../../../chunks/converters.js";
import { T as Trash_2 } from "../../../chunks/trash-2.js";
import { P as Play } from "../../../chunks/play.js";
import { P as Plus } from "../../../chunks/plus.js";
import { D as Download } from "../../../chunks/download.js";
import { I as Icon } from "../../../chunks/Icon.js";
import { e as escape_html } from "../../../chunks/context.js";
function Refresh_cw($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "path",
      { "d": "M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8" }
    ],
    ["path", { "d": "M21 3v5h-5" }],
    [
      "path",
      { "d": "M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16" }
    ],
    ["path", { "d": "M8 16H3v5" }]
  ];
  Icon($$renderer, spread_props([
    { name: "refresh-cw" },
    $$sanitized_props,
    {
      /**
       * @component @name RefreshCw
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMyAxMmE5IDkgMCAwIDEgOS05IDkuNzUgOS43NSAwIDAgMSA2Ljc0IDIuNzRMMjEgOCIgLz4KICA8cGF0aCBkPSJNMjEgM3Y1aC01IiAvPgogIDxwYXRoIGQ9Ik0yMSAxMmE5IDkgMCAwIDEtOSA5IDkuNzUgOS43NSAwIDAgMS02Ljc0LTIuNzRMMyAxNiIgLz4KICA8cGF0aCBkPSJNOCAxNkgzdjUiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/refresh-cw
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let rowCount = 10;
    let tableName = "users";
    let fields = [
      { id: crypto.randomUUID(), name: "id", type: "string_uuid" },
      {
        id: crypto.randomUUID(),
        name: "name",
        type: "person_fullName"
      },
      {
        id: crypto.randomUUID(),
        name: "email",
        type: "internet_email"
      },
      {
        id: crypto.randomUUID(),
        name: "company",
        type: "company_name"
      },
      {
        id: crypto.randomUUID(),
        name: "created_at",
        type: "date_past"
      }
    ];
    let generatedData = [];
    let isGenerating = false;
    const FIELD_TYPES = [
      {
        group: "Common",
        types: [
          {
            id: "string_uuid",
            label: "UUID",
            fn: () => faker.string.uuid()
          },
          {
            id: "number_int",
            label: "Integer",
            fn: () => faker.number.int({ min: 1, max: 1e3 })
          },
          {
            id: "number_float",
            label: "Float",
            fn: () => faker.number.float({ min: 0, max: 1, fractionDigits: 2 })
          },
          {
            id: "boolean",
            label: "Boolean",
            fn: () => faker.datatype.boolean()
          }
        ]
      },
      {
        group: "Person",
        types: [
          {
            id: "person_fullName",
            label: "Full Name",
            fn: () => faker.person.fullName()
          },
          {
            id: "person_firstName",
            label: "First Name",
            fn: () => faker.person.firstName()
          },
          {
            id: "person_lastName",
            label: "Last Name",
            fn: () => faker.person.lastName()
          },
          {
            id: "person_jobTitle",
            label: "Job Title",
            fn: () => faker.person.jobTitle()
          }
        ]
      },
      {
        group: "Contact",
        types: [
          {
            id: "internet_email",
            label: "Email",
            fn: () => faker.internet.email()
          },
          {
            id: "phone_number",
            label: "Phone Number",
            fn: () => faker.phone.number()
          },
          {
            id: "internet_userName",
            label: "Username",
            fn: () => faker.internet.userName()
          },
          {
            id: "internet_url",
            label: "URL",
            fn: () => faker.internet.url()
          }
        ]
      },
      {
        group: "Company",
        types: [
          {
            id: "company_name",
            label: "Company Name",
            fn: () => faker.company.name()
          },
          {
            id: "company_catchPhrase",
            label: "Catch Phrase",
            fn: () => faker.company.catchPhrase()
          }
        ]
      },
      {
        group: "Date",
        types: [
          {
            id: "date_past",
            label: "Past Date",
            fn: () => faker.date.past().toISOString()
          },
          {
            id: "date_future",
            label: "Future Date",
            fn: () => faker.date.future().toISOString()
          },
          {
            id: "date_any",
            label: "Any Date",
            fn: () => faker.date.anytime().toISOString()
          }
        ]
      }
    ];
    function addField() {
      fields.push({
        id: crypto.randomUUID(),
        name: `field_${fields.length + 1}`,
        type: "person_fullName"
      });
    }
    function generate() {
      isGenerating = true;
      setTimeout(
        () => {
          const data = [];
          const header = fields.map((f) => f.name);
          data.push(header);
          for (let i = 0; i < rowCount; i++) {
            const row = fields.map((f) => {
              const typeDef = FIELD_TYPES.flatMap((g) => g.types).find((t) => t.id === f.type);
              return typeDef ? typeDef.fn() : "";
            });
            data.push(row);
          }
          generatedData = data;
          isGenerating = false;
        },
        100
      );
    }
    function copyAs(format) {
      let text = "";
      switch (format) {
        case "json":
          text = toJSON(generatedData);
          break;
        case "csv":
          text = toCSV(generatedData);
          break;
        case "sql":
          text = toSQL(generatedData, tableName);
          break;
        case "markdown":
          text = toMarkdown(generatedData);
          break;
      }
      navigator.clipboard.writeText(text);
    }
    function downloadAs(format) {
      let text = "";
      let ext = "";
      switch (format) {
        case "json":
          text = toJSON(generatedData);
          ext = "json";
          break;
        case "csv":
          text = toCSV(generatedData);
          ext = "csv";
          break;
        case "sql":
          text = toSQL(generatedData, tableName);
          ext = "sql";
          break;
      }
      const blob = new Blob([text], { type: "text/plain" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${tableName}_mock.${ext}`;
      a.click();
    }
    head("1a38g8b", $$renderer2, ($$renderer3) => {
      $$renderer3.title(($$renderer4) => {
        $$renderer4.push(`<title>Mock Data Generator - Aone Toolkit</title>`);
      });
    });
    $$renderer2.push(`<div class="h-[calc(100vh-3rem)] p-4 overflow-hidden"><div class="h-full grid grid-cols-1 lg:grid-cols-12 gap-6"><div class="lg:col-span-4 flex flex-col min-h-0 space-y-4">`);
    {
      let header = function($$renderer3) {
        $$renderer3.push(`<div class="flex items-center justify-between w-full"><div class="flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">`);
        Plus($$renderer3, { size: 16 });
        $$renderer3.push(`<!----></div> <h2 class="font-semibold text-slate-900 dark:text-white">Fields Configuration</h2></div> `);
        Button($$renderer3, {
          variant: "ghost",
          size: "sm",
          onclick: addField,
          children: ($$renderer4) => {
            Plus($$renderer4, { size: 14, class: "mr-1" });
            $$renderer4.push(`<!----> Add`);
          },
          $$slots: { default: true }
        });
        $$renderer3.push(`<!----></div>`);
      };
      Panel($$renderer2, {
        class: "flex-1 flex flex-col min-h-0 overflow-hidden",
        header,
        children: ($$renderer3) => {
          $$renderer3.push(`<div class="flex-1 overflow-y-auto p-4 space-y-3"><!--[-->`);
          const each_array = ensure_array_like(fields);
          for (let $$index_2 = 0, $$length = each_array.length; $$index_2 < $$length; $$index_2++) {
            let field = each_array[$$index_2];
            $$renderer3.push(`<div class="flex items-center gap-2 p-2 bg-slate-50 dark:bg-slate-800/50 rounded-lg group border border-transparent hover:border-indigo-500/30 transition-all"><input type="text"${attr("value", field.name)} class="flex-1 bg-transparent text-sm font-medium focus:outline-none" placeholder="Field name"/> `);
            $$renderer3.select(
              {
                value: field.type,
                class: "form-select bg-white dark:bg-slate-700 text-xs py-1 px-2 pr-6 rounded border-slate-200 dark:border-slate-600 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              },
              ($$renderer4) => {
                $$renderer4.push(`<!--[-->`);
                const each_array_1 = ensure_array_like(FIELD_TYPES);
                for (let $$index_1 = 0, $$length2 = each_array_1.length; $$index_1 < $$length2; $$index_1++) {
                  let group = each_array_1[$$index_1];
                  $$renderer4.push(`<optgroup${attr("label", group.group)}><!--[-->`);
                  const each_array_2 = ensure_array_like(group.types);
                  for (let $$index = 0, $$length3 = each_array_2.length; $$index < $$length3; $$index++) {
                    let type = each_array_2[$$index];
                    $$renderer4.option({ value: type.id }, ($$renderer5) => {
                      $$renderer5.push(`${escape_html(type.label)}`);
                    });
                  }
                  $$renderer4.push(`<!--]--></optgroup>`);
                }
                $$renderer4.push(`<!--]-->`);
              }
            );
            $$renderer3.push(` <button class="text-slate-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity">`);
            Trash_2($$renderer3, { size: 14 });
            $$renderer3.push(`<!----></button></div>`);
          }
          $$renderer3.push(`<!--]--></div> <div class="p-4 border-t border-slate-100 dark:border-slate-800 space-y-4 bg-white dark:bg-slate-900"><div class="grid grid-cols-2 gap-4"><div class="space-y-1"><span class="text-[10px] font-bold text-slate-400 uppercase ml-1">Table Name</span> <input type="text"${attr("value", tableName)} class="w-full text-xs p-2 bg-slate-50 dark:bg-slate-800 border rounded"/></div> <div class="space-y-1"><span class="text-[10px] font-bold text-slate-400 uppercase ml-1">Rows</span> <input type="number"${attr("value", rowCount)} min="1" max="1000" class="w-full text-xs p-2 bg-slate-50 dark:bg-slate-800 border rounded"/></div></div> `);
          Button($$renderer3, {
            class: "w-full",
            onclick: generate,
            children: ($$renderer4) => {
              if (isGenerating) {
                $$renderer4.push("<!--[-->");
                Refresh_cw($$renderer4, { size: 16, class: "mr-2 animate-spin" });
                $$renderer4.push(`<!----> Generating...`);
              } else {
                $$renderer4.push("<!--[!-->");
                Play($$renderer4, { size: 16, class: "mr-2" });
                $$renderer4.push(`<!----> Generate Data`);
              }
              $$renderer4.push(`<!--]-->`);
            },
            $$slots: { default: true }
          });
          $$renderer3.push(`<!----></div>`);
        }
      });
    }
    $$renderer2.push(`<!----></div> <div class="lg:col-span-8 flex flex-col min-h-0">`);
    {
      let header = function($$renderer3) {
        $$renderer3.push(`<div class="flex items-center justify-between w-full"><div class="flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">`);
        Play($$renderer3, { size: 16 });
        $$renderer3.push(`<!----></div> <h2 class="font-semibold text-slate-900 dark:text-white">Generated Data Preview</h2></div> `);
        if (generatedData.length > 0) {
          $$renderer3.push("<!--[-->");
          $$renderer3.push(`<div class="flex gap-2"><div class="flex p-0.5 bg-slate-100 dark:bg-slate-800 rounded-lg">`);
          Button($$renderer3, {
            variant: "ghost",
            size: "sm",
            onclick: () => copyAs("json"),
            children: ($$renderer4) => {
              $$renderer4.push(`<!---->JSON`);
            },
            $$slots: { default: true }
          });
          $$renderer3.push(`<!----> `);
          Button($$renderer3, {
            variant: "ghost",
            size: "sm",
            onclick: () => copyAs("csv"),
            children: ($$renderer4) => {
              $$renderer4.push(`<!---->CSV`);
            },
            $$slots: { default: true }
          });
          $$renderer3.push(`<!----> `);
          Button($$renderer3, {
            variant: "ghost",
            size: "sm",
            onclick: () => copyAs("sql"),
            children: ($$renderer4) => {
              $$renderer4.push(`<!---->SQL`);
            },
            $$slots: { default: true }
          });
          $$renderer3.push(`<!----></div> `);
          Button($$renderer3, {
            size: "sm",
            variant: "secondary",
            onclick: () => downloadAs("csv"),
            children: ($$renderer4) => {
              Download($$renderer4, { size: 14, class: "mr-1" });
              $$renderer4.push(`<!----> Download`);
            },
            $$slots: { default: true }
          });
          $$renderer3.push(`<!----></div>`);
        } else {
          $$renderer3.push("<!--[!-->");
        }
        $$renderer3.push(`<!--]--></div>`);
      };
      Panel($$renderer2, {
        class: "flex-1 flex flex-col min-h-0 overflow-hidden",
        header,
        children: ($$renderer3) => {
          if (generatedData.length > 0) {
            $$renderer3.push("<!--[-->");
            $$renderer3.push(`<div class="flex-1 overflow-auto"><table class="w-full text-sm text-left font-mono"><thead class="bg-slate-50 dark:bg-slate-800/50 sticky top-0 z-10"><tr><!--[-->`);
            const each_array_3 = ensure_array_like(generatedData[0]);
            for (let $$index_3 = 0, $$length = each_array_3.length; $$index_3 < $$length; $$index_3++) {
              let header2 = each_array_3[$$index_3];
              $$renderer3.push(`<th class="p-3 border-b border-slate-200 dark:border-slate-700 text-slate-500 font-bold uppercase text-[10px]">${escape_html(header2)}</th>`);
            }
            $$renderer3.push(`<!--]--></tr></thead><tbody class="divide-y divide-slate-100 dark:divide-slate-800"><!--[-->`);
            const each_array_4 = ensure_array_like(generatedData.slice(1));
            for (let $$index_5 = 0, $$length = each_array_4.length; $$index_5 < $$length; $$index_5++) {
              let row = each_array_4[$$index_5];
              $$renderer3.push(`<tr class="hover:bg-slate-50/50 dark:hover:bg-white/5 transition-colors"><!--[-->`);
              const each_array_5 = ensure_array_like(row);
              for (let $$index_4 = 0, $$length2 = each_array_5.length; $$index_4 < $$length2; $$index_4++) {
                let cell = each_array_5[$$index_4];
                $$renderer3.push(`<td class="p-3 border-b border-slate-50 dark:border-slate-900 truncate max-w-[200px]"${attr("title", cell)}>${escape_html(cell)}</td>`);
              }
              $$renderer3.push(`<!--]--></tr>`);
            }
            $$renderer3.push(`<!--]--></tbody></table></div>`);
          } else {
            $$renderer3.push("<!--[!-->");
            $$renderer3.push(`<div class="flex-1 flex flex-col items-center justify-center text-slate-400 p-8 text-center space-y-4"><div class="w-20 h-20 rounded-full bg-slate-50 dark:bg-slate-800/50 flex items-center justify-center">`);
            Play($$renderer3, { size: 40, class: "text-slate-200 dark:text-slate-700" });
            $$renderer3.push(`<!----></div> <div><p class="font-medium text-slate-600 dark:text-slate-300">No data generated yet</p> <p class="text-sm">Configure fields and click "Generate Data" to
                                start.</p></div></div>`);
          }
          $$renderer3.push(`<!--]-->`);
        }
      });
    }
    $$renderer2.push(`<!----></div></div></div>`);
  });
}
export {
  _page as default
};
