import { Z as sanitize_props, _ as spread_props, $ as slot, a4 as ensure_array_like, a0 as attr_class, a1 as stringify, a7 as head } from "../../../chunks/index2.js";
import { B as Button } from "../../../chunks/Button.js";
import { P as Panel } from "../../../chunks/Panel.js";
import "clsx";
import { P as Plus } from "../../../chunks/plus.js";
import { C as Check } from "../../../chunks/check.js";
import { I as Icon } from "../../../chunks/Icon.js";
import { S as Shield_check } from "../../../chunks/shield-check.js";
import { C as Code } from "../../../chunks/code.js";
import { e as escape_html } from "../../../chunks/context.js";
import { marked } from "marked";
import { h as html } from "../../../chunks/html.js";
import { L as Loader_circle } from "../../../chunks/loader-circle.js";
function Bot($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    ["path", { "d": "M12 8V4H8" }],
    [
      "rect",
      { "width": "16", "height": "12", "x": "4", "y": "8", "rx": "2" }
    ],
    ["path", { "d": "M2 14h2" }],
    ["path", { "d": "M20 14h2" }],
    ["path", { "d": "M15 13v2" }],
    ["path", { "d": "M9 13v2" }]
  ];
  Icon($$renderer, spread_props([
    { name: "bot" },
    $$sanitized_props,
    {
      /**
       * @component @name Bot
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTIgOFY0SDgiIC8+CiAgPHJlY3Qgd2lkdGg9IjE2IiBoZWlnaHQ9IjEyIiB4PSI0IiB5PSI4IiByeD0iMiIgLz4KICA8cGF0aCBkPSJNMiAxNGgyIiAvPgogIDxwYXRoIGQ9Ik0yMCAxNGgyIiAvPgogIDxwYXRoIGQ9Ik0xNSAxM3YyIiAvPgogIDxwYXRoIGQ9Ik05IDEzdjIiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/bot
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Map($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "path",
      {
        "d": "M14.106 5.553a2 2 0 0 0 1.788 0l3.659-1.83A1 1 0 0 1 21 4.619v12.764a1 1 0 0 1-.553.894l-4.553 2.277a2 2 0 0 1-1.788 0l-4.212-2.106a2 2 0 0 0-1.788 0l-3.659 1.83A1 1 0 0 1 3 19.381V6.618a1 1 0 0 1 .553-.894l4.553-2.277a2 2 0 0 1 1.788 0z"
      }
    ],
    ["path", { "d": "M15 5.764v15" }],
    ["path", { "d": "M9 3.236v15" }]
  ];
  Icon($$renderer, spread_props([
    { name: "map" },
    $$sanitized_props,
    {
      /**
       * @component @name Map
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTQuMTA2IDUuNTUzYTIgMiAwIDAgMCAxLjc4OCAwbDMuNjU5LTEuODNBMSAxIDAgMCAxIDIxIDQuNjE5djEyLjc2NGExIDEgMCAwIDEtLjU1My44OTRsLTQuNTUzIDIuMjc3YTIgMiAwIDAgMS0xLjc4OCAwbC00LjIxMi0yLjEwNmEyIDIgMCAwIDAtMS43ODggMGwtMy42NTkgMS44M0ExIDEgMCAwIDEgMyAxOS4zODFWNi42MThhMSAxIDAgMCAxIC41NTMtLjg5NGw0LjU1My0yLjI3N2EyIDIgMCAwIDEgMS43ODggMHoiIC8+CiAgPHBhdGggZD0iTTE1IDUuNzY0djE1IiAvPgogIDxwYXRoIGQ9Ik05IDMuMjM2djE1IiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/map
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Send($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "path",
      {
        "d": "M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z"
      }
    ],
    ["path", { "d": "m21.854 2.147-10.94 10.939" }]
  ];
  Icon($$renderer, spread_props([
    { name: "send" },
    $$sanitized_props,
    {
      /**
       * @component @name Send
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTQuNTM2IDIxLjY4NmEuNS41IDAgMCAwIC45MzctLjAyNGw2LjUtMTlhLjQ5Ni40OTYgMCAwIDAtLjYzNS0uNjM1bC0xOSA2LjVhLjUuNSAwIDAgMC0uMDI0LjkzN2w3LjkzIDMuMThhMiAyIDAgMCAxIDEuMTEyIDEuMTF6IiAvPgogIDxwYXRoIGQ9Im0yMS44NTQgMi4xNDctMTAuOTQgMTAuOTM5IiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/send
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function User($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    ["path", { "d": "M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" }],
    ["circle", { "cx": "12", "cy": "7", "r": "4" }]
  ];
  Icon($$renderer, spread_props([
    { name: "user" },
    $$sanitized_props,
    {
      /**
       * @component @name User
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTkgMjF2LTJhNCA0IDAgMCAwLTQtNEg5YTQgNCAwIDAgMC00IDR2MiIgLz4KICA8Y2lyY2xlIGN4PSIxMiIgY3k9IjciIHI9IjQiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/user
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
class AgentStore {
  agents = [
    {
      id: "1",
      name: "Architect",
      role: "System Designer",
      systemPrompt: "You are a software architect. Focus on high-level design, patterns, and trade-offs.",
      color: "bg-blue-500",
      avatar: "sitemap"
    },
    {
      id: "2",
      name: "Coder",
      role: "Developer",
      systemPrompt: "You are a senior developer. Write clean, efficient code.",
      color: "bg-green-500",
      avatar: "code"
    },
    {
      id: "3",
      name: "Reviewer",
      role: "QA & Audit",
      systemPrompt: "You are a code reviewer. Find bugs, security issues, and style violations.",
      color: "bg-red-500",
      avatar: "shield-check"
    }
  ];
  currentSession = {
    id: "default",
    title: "New Session",
    messages: [],
    activeAgentIds: ["1", "2"]
    // Default active
  };
  isThinking = false;
  constructor() {
  }
  addMessage(role, content, agentId) {
    this.currentSession.messages.push({
      id: crypto.randomUUID(),
      role,
      content,
      agentId,
      timestamp: Date.now()
    });
  }
  toggleAgentActive(agentId) {
    if (this.currentSession.activeAgentIds.includes(agentId)) {
      this.currentSession.activeAgentIds = this.currentSession.activeAgentIds.filter((id) => id !== agentId);
    } else {
      this.currentSession.activeAgentIds.push(agentId);
    }
  }
  getActiveAgents() {
    return this.agents.filter((a) => this.currentSession.activeAgentIds.includes(a.id));
  }
  getAgent(id) {
    return this.agents.find((a) => a.id === id);
  }
}
const agentStore = new AgentStore();
function AgentSidebar($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const iconMap = {
      code: Code,
      sitemap: Map,
      "shield-check": Shield_check,
      default: Bot
    };
    function getIcon(name) {
      return iconMap[name] || iconMap.default;
    }
    let agents = agentStore.agents;
    let activeIds = agentStore.currentSession.activeAgentIds;
    function isActive(id) {
      return activeIds.includes(id);
    }
    $$renderer2.push(`<div class="w-64 border-r border-slate-200 dark:border-slate-800 flex flex-col bg-slate-50 dark:bg-slate-900/50"><div class="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between"><h2 class="font-semibold text-slate-800 dark:text-slate-200">Agents</h2> `);
    Button($$renderer2, {
      variant: "ghost",
      size: "sm",
      class: "h-8 w-8 p-0",
      children: ($$renderer3) => {
        Plus($$renderer3, { class: "w-4 h-4" });
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----></div> <div class="flex-1 overflow-y-auto p-3 space-y-2"><!--[-->`);
    const each_array = ensure_array_like(agents);
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      let agent = each_array[$$index];
      const Icon2 = getIcon(agent.avatar);
      const active = isActive(agent.id);
      $$renderer2.push(`<button${attr_class(`w-full text-left p-2 rounded-lg border transition-all duration-200 flex items-center gap-3 group relative ${stringify(active ? "bg-white dark:bg-slate-800 border-primary-200 dark:border-primary-800 shadow-sm" : "border-transparent hover:bg-slate-100 dark:hover:bg-slate-800/50 opacity-70 hover:opacity-100")}`)}><div${attr_class(`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${stringify(agent.color)} text-white shadow-sm`)}><!---->`);
      Icon2($$renderer2, { class: "w-5 h-5" });
      $$renderer2.push(`<!----></div> <div class="flex-1 min-w-0"><div class="font-medium text-sm text-slate-900 dark:text-slate-100 truncate">${escape_html(agent.name)}</div> <div class="text-xs text-slate-500 truncate">${escape_html(agent.role)}</div></div> <div${attr_class(`w-5 h-5 rounded-full border flex items-center justify-center transition-colors ${stringify(active ? "bg-primary-500 border-primary-500" : "border-slate-300 dark:border-slate-600")}`)}>`);
      if (active) {
        $$renderer2.push("<!--[-->");
        Check($$renderer2, { class: "w-3 h-3 text-white" });
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></div></button>`);
    }
    $$renderer2.push(`<!--]--></div> <div class="p-4 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900"><div class="text-xs text-slate-500">Current Session</div> <div class="font-medium text-sm truncate">${escape_html(agentStore.currentSession.title)}</div></div></div>`);
  });
}
function MessageBubble($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { message } = $$props;
    const iconMap = {
      code: Code,
      sitemap: Map,
      "shield-check": Shield_check,
      default: Bot
    };
    function getAgent(id) {
      if (!id) return null;
      return agentStore.getAgent(id);
    }
    function getIcon(name) {
      return iconMap[name] || iconMap.default;
    }
    let agent = getAgent(message.agentId);
    let isUser = message.role === "user";
    let htmlContent = marked.parse(message.content);
    $$renderer2.push(`<div${attr_class(`flex gap-4 p-4 ${stringify(isUser ? "flex-row-reverse" : "")} group hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors`)}><div class="shrink-0">`);
    if (isUser) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center text-slate-500">`);
      User($$renderer2, { class: "w-5 h-5" });
      $$renderer2.push(`<!----></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
      if (agent) {
        $$renderer2.push("<!--[-->");
        const Icon2 = getIcon(agent.avatar);
        $$renderer2.push(`<div${attr_class(`w-8 h-8 rounded-full flex items-center justify-center text-white ${stringify(agent.color)}`)}><!---->`);
        Icon2($$renderer2, { class: "w-5 h-5" });
        $$renderer2.push(`<!----></div>`);
      } else {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push(`<div class="w-8 h-8 rounded-full bg-gray-500 flex items-center justify-center text-white">`);
        Bot($$renderer2, { class: "w-5 h-5" });
        $$renderer2.push(`<!----></div>`);
      }
      $$renderer2.push(`<!--]-->`);
    }
    $$renderer2.push(`<!--]--></div> <div class="flex-1 max-w-3xl space-y-1"><div${attr_class(`flex items-center gap-2 ${stringify(isUser ? "justify-end" : "")}`)}><span class="text-sm font-semibold text-slate-900 dark:text-slate-100">${escape_html(isUser ? "You" : agent?.name || "System")}</span> `);
    if (agent) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<span class="text-xs text-slate-400 bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded">${escape_html(agent.role)}</span>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> <span class="text-xs text-slate-400">${escape_html(new Date(message.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }))}</span></div> <div${attr_class(`prose prose-sm dark:prose-invert max-w-none ${stringify(isUser ? "bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg rounded-tr-none" : "")}`)}>${html(htmlContent)}</div></div></div>`);
  });
}
function ChatArea($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let input = "";
    let messages = agentStore.currentSession.messages;
    let isThinking = agentStore.isThinking;
    async function handleSend() {
      if (!input.trim() || isThinking) return;
      const text = input;
      input = "";
      agentStore.addMessage("user", text);
      const activeAgents = agentStore.getActiveAgents();
      if (activeAgents.length === 0) {
        setTimeout(
          () => {
            agentStore.addMessage("system", "No active agents selected. Please select agents from the sidebar.");
          },
          500
        );
        return;
      }
      agentStore.isThinking = true;
      for (const agent of activeAgents) {
        const delay = 1e3 + Math.random() * 1500;
        await new Promise((r) => setTimeout(r, delay));
        const response = generateMockResponse(agent, text);
        agentStore.addMessage("assistant", response, agent.id);
      }
      agentStore.isThinking = false;
    }
    function generateMockResponse(agent, input2) {
      const prefixes = [
        `As a **${agent.role}**, I believe...`,
        `From my perspective...`,
        `Evaluating this request...`
      ];
      const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
      return `${prefix}

I have analyzed your input: "${input2}".

**My Analysis:**
- Point 1 specific to ${agent.name}
- Point 2 regarding ${agent.role}

Recommending next steps based on my system prompt.`;
    }
    $$renderer2.push(`<div class="flex flex-col h-full bg-slate-50 dark:bg-slate-950"><div class="flex-1 overflow-y-auto p-4 space-y-4 scroll-smooth">`);
    if (messages.length === 0) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="h-full flex flex-col items-center justify-center text-slate-400 space-y-4"><div class="w-16 h-16 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-8 h-8"><path stroke-linecap="round" stroke-linejoin="round" d="M20.25 8.511c.884.284 1.5 1.128 1.5 2.097v4.286c0 1.136-.847 2.1-1.98 2.193-.34.027-.68.052-1.02.072v3.091l-3-3c-1.354 0-2.694-.055-4.02-.163a2.115 2.115 0 0 1-.825-.242m9.345-8.334a2.126 2.126 0 0 0-.476-.095 48.64 48.64 0 0 0-8.048 0c-1.131.094-1.976 1.057-1.976 2.192v4.286c0 .837.46 1.58 1.155 1.951m9.345-8.334V6.637c0-1.621-1.152-3.026-2.76-3.235A48.455 48.455 0 0 0 11.25 3c-2.115 0-4.198.137-6.24.402-1.608.209-2.76 1.614-2.76 3.235v6.226c0 1.621 1.152 3.026 2.76 3.235.577.075 1.157.14 1.74.194V21l4.155-4.155"></path></svg></div> <div class="text-center"><h3 class="font-medium text-slate-900 dark:text-slate-100">Start a new conversation</h3> <p class="text-sm mt-1">Select agents from the sidebar and say hello.</p></div></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<!--[-->`);
      const each_array = ensure_array_like(messages);
      for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
        let msg = each_array[$$index];
        MessageBubble($$renderer2, { message: msg });
      }
      $$renderer2.push(`<!--]--> `);
      if (isThinking) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="flex gap-4 p-4 animate-pulse"><div class="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-800"></div> <div class="space-y-2 flex-1 max-w-sm"><div class="h-4 bg-gray-200 dark:bg-gray-800 rounded w-3/4"></div> <div class="h-4 bg-gray-200 dark:bg-gray-800 rounded w-1/2"></div></div></div>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]-->`);
    }
    $$renderer2.push(`<!--]--></div> <div class="p-4 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800"><div class="relative max-w-4xl mx-auto flex items-end gap-2"><div class="flex-1 relative"><textarea placeholder="Message the active agents..." class="w-full min-h-[50px] max-h-[200px] p-3 pr-10 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-primary-500 resize-none scrollbar-hide text-sm" rows="1">`);
    const $$body = escape_html(input);
    if ($$body) {
      $$renderer2.push(`${$$body}`);
    }
    $$renderer2.push(`</textarea></div> `);
    Button($$renderer2, {
      onclick: handleSend,
      disabled: !input.trim() || isThinking,
      size: "md",
      class: "h-[50px] w-[50px] shrink-0 rounded-xl p-0",
      children: ($$renderer3) => {
        if (isThinking) {
          $$renderer3.push("<!--[-->");
          Loader_circle($$renderer3, { class: "w-5 h-5 animate-spin" });
        } else {
          $$renderer3.push("<!--[!-->");
          Send($$renderer3, { class: "w-5 h-5" });
        }
        $$renderer3.push(`<!--]-->`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----></div> <div class="text-xs text-center text-slate-400 mt-2"><strong>Enter</strong> to send, <strong>Shift + Enter</strong> for new
            line</div></div></div>`);
  });
}
function _page($$renderer) {
  head("2tuxuy", $$renderer, ($$renderer2) => {
    $$renderer2.title(($$renderer3) => {
      $$renderer3.push(`<title>Multi-Agent - Aone Toolkit</title>`);
    });
  });
  $$renderer.push(`<div class="h-[calc(100vh-3rem)]">`);
  {
    let header = function($$renderer2) {
      $$renderer2.push(`<div class="flex items-center justify-between"><div class="flex items-center gap-3"><div class="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-violet-500 flex items-center justify-center"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4 text-white"><path stroke-linecap="round" stroke-linejoin="round" d="M9.813 15.904 9 18.75l-.813-2.846a4.5 4.5 0 0 0-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 0 0 3.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 0 0 3.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 0 0-3.09 3.09ZM18.259 8.715 18 9.75l-.259-1.035a3.375 3.375 0 0 0-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 0 0 2.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 0 0 2.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 0 0-2.456 2.456ZM16.894 20.567 16.5 21.75l-.394-1.183a2.25 2.25 0 0 0-1.423-1.423L13.5 18.75l1.183-.394a2.25 2.25 0 0 0 1.423-1.423l.394-1.183.394 1.183a2.25 2.25 0 0 0 1.423 1.423l1.183.394-1.183.394a2.25 2.25 0 0 0-1.423 1.423Z"></path></svg></div> <div class="flex flex-col"><h1 class="text-lg font-semibold text-slate-900 dark:text-white">Multi-Agent Orchestration</h1> <span class="text-xs text-slate-500">Collaborative Chat Environment</span></div></div> <div class="flex items-center gap-2">`);
      Button($$renderer2, {
        variant: "secondary",
        size: "sm",
        children: ($$renderer3) => {
          $$renderer3.push(`<!---->Manage Agents`);
        },
        $$slots: { default: true }
      });
      $$renderer2.push(`<!----> `);
      Button($$renderer2, {
        variant: "primary",
        size: "sm",
        children: ($$renderer3) => {
          $$renderer3.push(`<!---->New Session`);
        },
        $$slots: { default: true }
      });
      $$renderer2.push(`<!----></div></div>`);
    };
    Panel($$renderer, {
      class: "h-full flex flex-col",
      header,
      children: ($$renderer2) => {
        $$renderer2.push(`<div class="flex-1 flex overflow-hidden">`);
        AgentSidebar($$renderer2);
        $$renderer2.push(`<!----> `);
        ChatArea($$renderer2);
        $$renderer2.push(`<!----></div>`);
      }
    });
  }
  $$renderer.push(`<!----></div>`);
}
export {
  _page as default
};
