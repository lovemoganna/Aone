import { Z as sanitize_props, _ as spread_props, $ as slot, a4 as ensure_array_like, a9 as attr_style, a0 as attr_class, a1 as stringify, a3 as attr, a6 as bind_props } from "../../../chunks/index2.js";
import { e as escape_html } from "../../../chunks/context.js";
import "clsx";
import { C as Chevron_right } from "../../../chunks/chevron-right.js";
import { I as Icon } from "../../../chunks/Icon.js";
import { H as Hash } from "../../../chunks/hash.js";
import { T as Trash_2 } from "../../../chunks/trash-2.js";
import { P as Plus } from "../../../chunks/plus.js";
import { C as Check } from "../../../chunks/check.js";
import { X, F as File_text } from "../../../chunks/x.js";
import { D as Database } from "../../../chunks/database.js";
import { D as Download } from "../../../chunks/download.js";
import { F as File_braces } from "../../../chunks/file-braces.js";
import { U as Upload, M as Moon, T as Triangle_alert } from "../../../chunks/upload.js";
import { B as Brain_circuit } from "../../../chunks/brain-circuit.js";
import { S as Search } from "../../../chunks/search.js";
import { P as Play } from "../../../chunks/play.js";
import { C as Copy } from "../../../chunks/copy.js";
import { marked } from "marked";
import { S as Sparkles } from "../../../chunks/sparkles.js";
import { C as Code_xml } from "../../../chunks/code-xml.js";
import { T as Terminal } from "../../../chunks/terminal.js";
import { C as Code } from "../../../chunks/code.js";
import { h as html } from "../../../chunks/html.js";
import { T as Tag } from "../../../chunks/tag.js";
function Archive_restore($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "rect",
      { "width": "20", "height": "5", "x": "2", "y": "3", "rx": "1" }
    ],
    ["path", { "d": "M4 8v11a2 2 0 0 0 2 2h2" }],
    ["path", { "d": "M20 8v11a2 2 0 0 1-2 2h-2" }],
    ["path", { "d": "m9 15 3-3 3 3" }],
    ["path", { "d": "M12 12v9" }]
  ];
  Icon($$renderer, spread_props([
    { name: "archive-restore" },
    $$sanitized_props,
    {
      /**
       * @component @name ArchiveRestore
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cmVjdCB3aWR0aD0iMjAiIGhlaWdodD0iNSIgeD0iMiIgeT0iMyIgcng9IjEiIC8+CiAgPHBhdGggZD0iTTQgOHYxMWEyIDIgMCAwIDAgMiAyaDIiIC8+CiAgPHBhdGggZD0iTTIwIDh2MTFhMiAyIDAgMCAxLTIgMmgtMiIgLz4KICA8cGF0aCBkPSJtOSAxNSAzLTMgMyAzIiAvPgogIDxwYXRoIGQ9Ik0xMiAxMnY5IiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/archive-restore
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Archive($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "rect",
      { "width": "20", "height": "5", "x": "2", "y": "3", "rx": "1" }
    ],
    ["path", { "d": "M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8" }],
    ["path", { "d": "M10 12h4" }]
  ];
  Icon($$renderer, spread_props([
    { name: "archive" },
    $$sanitized_props,
    {
      /**
       * @component @name Archive
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cmVjdCB3aWR0aD0iMjAiIGhlaWdodD0iNSIgeD0iMiIgeT0iMyIgcng9IjEiIC8+CiAgPHBhdGggZD0iTTQgOHYxMWEyIDIgMCAwIDAgMiAyaDEyYTIgMiAwIDAgMCAyLTJWOCIgLz4KICA8cGF0aCBkPSJNMTAgMTJoNCIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/archive
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Chevron_down($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [["path", { "d": "m6 9 6 6 6-6" }]];
  Icon($$renderer, spread_props([
    { name: "chevron-down" },
    $$sanitized_props,
    {
      /**
       * @component @name ChevronDown
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJtNiA5IDYgNiA2LTYiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/chevron-down
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Circle_question_mark($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    ["circle", { "cx": "12", "cy": "12", "r": "10" }],
    ["path", { "d": "M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" }],
    ["path", { "d": "M12 17h.01" }]
  ];
  Icon($$renderer, spread_props([
    { name: "circle-question-mark" },
    $$sanitized_props,
    {
      /**
       * @component @name CircleQuestionMark
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8Y2lyY2xlIGN4PSIxMiIgY3k9IjEyIiByPSIxMCIgLz4KICA8cGF0aCBkPSJNOS4wOSA5YTMgMyAwIDAgMSA1LjgzIDFjMCAyLTMgMy0zIDMiIC8+CiAgPHBhdGggZD0iTTEyIDE3aC4wMSIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/circle-question-mark
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Files($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "path",
      {
        "d": "M15 2h-4a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V8"
      }
    ],
    [
      "path",
      {
        "d": "M16.706 2.706A2.4 2.4 0 0 0 15 2v5a1 1 0 0 0 1 1h5a2.4 2.4 0 0 0-.706-1.706z"
      }
    ],
    [
      "path",
      {
        "d": "M5 7a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2h8a2 2 0 0 0 1.732-1"
      }
    ]
  ];
  Icon($$renderer, spread_props([
    { name: "files" },
    $$sanitized_props,
    {
      /**
       * @component @name Files
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTUgMmgtNGEyIDIgMCAwIDAtMiAydjExYTIgMiAwIDAgMCAyIDJoOGEyIDIgMCAwIDAgMi0yVjgiIC8+CiAgPHBhdGggZD0iTTE2LjcwNiAyLjcwNkEyLjQgMi40IDAgMCAwIDE1IDJ2NWExIDEgMCAwIDAgMSAxaDVhMi40IDIuNCAwIDAgMC0uNzA2LTEuNzA2eiIgLz4KICA8cGF0aCBkPSJNNSA3YTIgMiAwIDAgMC0yIDJ2MTFhMiAyIDAgMCAwIDIgMmg4YTIgMiAwIDAgMCAxLjczMi0xIiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/files
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Folder_input($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "path",
      {
        "d": "M2 9V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H20a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-1"
      }
    ],
    ["path", { "d": "M2 13h10" }],
    ["path", { "d": "m9 16 3-3-3-3" }]
  ];
  Icon($$renderer, spread_props([
    { name: "folder-input" },
    $$sanitized_props,
    {
      /**
       * @component @name FolderInput
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMiA5VjVhMiAyIDAgMCAxIDItMmgzLjlhMiAyIDAgMCAxIDEuNjkuOWwuODEgMS4yYTIgMiAwIDAgMCAxLjY3LjlIMjBhMiAyIDAgMCAxIDIgMnYxMGEyIDIgMCAwIDEtMiAySDRhMiAyIDAgMCAxLTItMnYtMSIgLz4KICA8cGF0aCBkPSJNMiAxM2gxMCIgLz4KICA8cGF0aCBkPSJtOSAxNiAzLTMtMy0zIiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/folder-input
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Folder_open($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "path",
      {
        "d": "m6 14 1.5-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.54 6a2 2 0 0 1-1.95 1.5H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H18a2 2 0 0 1 2 2v2"
      }
    ]
  ];
  Icon($$renderer, spread_props([
    { name: "folder-open" },
    $$sanitized_props,
    {
      /**
       * @component @name FolderOpen
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJtNiAxNCAxLjUtMi45QTIgMiAwIDAgMSA5LjI0IDEwSDIwYTIgMiAwIDAgMSAxLjk0IDIuNWwtMS41NCA2YTIgMiAwIDAgMS0xLjk1IDEuNUg0YTIgMiAwIDAgMS0yLTJWNWEyIDIgMCAwIDEgMi0yaDMuOWEyIDIgMCAwIDEgMS42OS45bC44MSAxLjJhMiAyIDAgMCAwIDEuNjcuOUgxOGEyIDIgMCAwIDEgMiAydjIiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/folder-open
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Folder($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "path",
      {
        "d": "M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"
      }
    ]
  ];
  Icon($$renderer, spread_props([
    { name: "folder" },
    $$sanitized_props,
    {
      /**
       * @component @name Folder
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMjAgMjBhMiAyIDAgMCAwIDItMlY4YTIgMiAwIDAgMC0yLTJoLTcuOWEyIDIgMCAwIDEtMS42OS0uOUw5LjYgMy45QTIgMiAwIDAgMCA3LjkzIDNINGEyIDIgMCAwIDAtMiAydjEzYTIgMiAwIDAgMCAyIDJaIiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/folder
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Layout_list($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "rect",
      { "width": "7", "height": "7", "x": "3", "y": "3", "rx": "1" }
    ],
    [
      "rect",
      { "width": "7", "height": "7", "x": "3", "y": "14", "rx": "1" }
    ],
    ["path", { "d": "M14 4h7" }],
    ["path", { "d": "M14 9h7" }],
    ["path", { "d": "M14 15h7" }],
    ["path", { "d": "M14 20h7" }]
  ];
  Icon($$renderer, spread_props([
    { name: "layout-list" },
    $$sanitized_props,
    {
      /**
       * @component @name LayoutList
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cmVjdCB3aWR0aD0iNyIgaGVpZ2h0PSI3IiB4PSIzIiB5PSIzIiByeD0iMSIgLz4KICA8cmVjdCB3aWR0aD0iNyIgaGVpZ2h0PSI3IiB4PSIzIiB5PSIxNCIgcng9IjEiIC8+CiAgPHBhdGggZD0iTTE0IDRoNyIgLz4KICA8cGF0aCBkPSJNMTQgOWg3IiAvPgogIDxwYXRoIGQ9Ik0xNCAxNWg3IiAvPgogIDxwYXRoIGQ9Ik0xNCAyMGg3IiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/layout-list
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Lightbulb($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "path",
      {
        "d": "M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5"
      }
    ],
    ["path", { "d": "M9 18h6" }],
    ["path", { "d": "M10 22h4" }]
  ];
  Icon($$renderer, spread_props([
    { name: "lightbulb" },
    $$sanitized_props,
    {
      /**
       * @component @name Lightbulb
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTUgMTRjLjItMSAuNy0xLjcgMS41LTIuNSAxLS45IDEuNS0yLjIgMS41LTMuNUE2IDYgMCAwIDAgNiA4YzAgMSAuMiAyLjIgMS41IDMuNS43LjcgMS4zIDEuNSAxLjUgMi41IiAvPgogIDxwYXRoIGQ9Ik05IDE4aDYiIC8+CiAgPHBhdGggZD0iTTEwIDIyaDQiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/lightbulb
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Message_square($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "path",
      {
        "d": "M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z"
      }
    ]
  ];
  Icon($$renderer, spread_props([
    { name: "message-square" },
    $$sanitized_props,
    {
      /**
       * @component @name MessageSquare
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMjIgMTdhMiAyIDAgMCAxLTIgMkg2LjgyOGEyIDIgMCAwIDAtMS40MTQuNTg2bC0yLjIwMiAyLjIwMkEuNzEuNzEgMCAwIDEgMiAyMS4yODZWNWEyIDIgMCAwIDEgMi0yaDE2YTIgMiAwIDAgMSAyIDJ6IiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/message-square
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Pen($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "path",
      {
        "d": "M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"
      }
    ]
  ];
  Icon($$renderer, spread_props([
    { name: "pen" },
    $$sanitized_props,
    {
      /**
       * @component @name Pen
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMjEuMTc0IDYuODEyYTEgMSAwIDAgMC0zLjk4Ni0zLjk4N0wzLjg0MiAxNi4xNzRhMiAyIDAgMCAwLS41LjgzbC0xLjMyMSA0LjM1MmEuNS41IDAgMCAwIC42MjMuNjIybDQuMzUzLTEuMzJhMiAyIDAgMCAwIC44My0uNDk3eiIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/pen
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Pencil($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "path",
      {
        "d": "M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"
      }
    ],
    ["path", { "d": "m15 5 4 4" }]
  ];
  Icon($$renderer, spread_props([
    { name: "pencil" },
    $$sanitized_props,
    {
      /**
       * @component @name Pencil
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMjEuMTc0IDYuODEyYTEgMSAwIDAgMC0zLjk4Ni0zLjk4N0wzLjg0MiAxNi4xNzRhMiAyIDAgMCAwLS41LjgzbC0xLjMyMSA0LjM1MmEuNS41IDAgMCAwIC42MjMuNjIybDQuMzUzLTEuMzJhMiAyIDAgMCAwIC44My0uNDk3eiIgLz4KICA8cGF0aCBkPSJtMTUgNSA0IDQiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/pencil
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Square_pen($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "path",
      {
        "d": "M12 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"
      }
    ],
    [
      "path",
      {
        "d": "M18.375 2.625a1 1 0 0 1 3 3l-9.013 9.014a2 2 0 0 1-.853.505l-2.873.84a.5.5 0 0 1-.62-.62l.84-2.873a2 2 0 0 1 .506-.852z"
      }
    ]
  ];
  Icon($$renderer, spread_props([
    { name: "square-pen" },
    $$sanitized_props,
    {
      /**
       * @component @name SquarePen
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTIgM0g1YTIgMiAwIDAgMC0yIDJ2MTRhMiAyIDAgMCAwIDIgMmgxNGEyIDIgMCAwIDAgMi0ydi03IiAvPgogIDxwYXRoIGQ9Ik0xOC4zNzUgMi42MjVhMSAxIDAgMCAxIDMgM2wtOS4wMTMgOS4wMTRhMiAyIDAgMCAxLS44NTMuNTA1bC0yLjg3My44NGEuNS41IDAgMCAxLS42Mi0uNjJsLjg0LTIuODczYTIgMiAwIDAgMSAuNTA2LS44NTJ6IiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/square-pen
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Star($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "path",
      {
        "d": "M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z"
      }
    ]
  ];
  Icon($$renderer, spread_props([
    { name: "star" },
    $$sanitized_props,
    {
      /**
       * @component @name Star
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTEuNTI1IDIuMjk1YS41My41MyAwIDAgMSAuOTUgMGwyLjMxIDQuNjc5YTIuMTIzIDIuMTIzIDAgMCAwIDEuNTk1IDEuMTZsNS4xNjYuNzU2YS41My41MyAwIDAgMSAuMjk0LjkwNGwtMy43MzYgMy42MzhhMi4xMjMgMi4xMjMgMCAwIDAtLjYxMSAxLjg3OGwuODgyIDUuMTRhLjUzLjUzIDAgMCAxLS43NzEuNTZsLTQuNjE4LTIuNDI4YTIuMTIyIDIuMTIyIDAgMCAwLTEuOTczIDBMNi4zOTYgMjEuMDFhLjUzLjUzIDAgMCAxLS43Ny0uNTZsLjg4MS01LjEzOWEyLjEyMiAyLjEyMiAwIDAgMC0uNjExLTEuODc5TDIuMTYgOS43OTVhLjUzLjUzIDAgMCAxIC4yOTQtLjkwNmw1LjE2NS0uNzU1YTIuMTIyIDIuMTIyIDAgMCAwIDEuNTk3LTEuMTZ6IiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/star
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
class PromptStore {
  prompts = [];
  tags = [];
  collections = [];
  versions = [];
  searchTerm = "";
  activeFilter = "all";
  activeTagId = null;
  activeCollectionId = null;
  sortOrder = "created_desc";
  get filteredPrompts() {
    return this.prompts.filter((p) => {
      const isArchived = !!p.archived;
      if (this.activeFilter === "archived") {
        if (!isArchived) return false;
      } else {
        if (isArchived) return false;
      }
      const term = this.searchTerm.toLowerCase();
      const matchesSearch = p.title.toLowerCase().includes(term) || p.content.toLowerCase().includes(term) || p.description?.toLowerCase().includes(term);
      if (!matchesSearch) return false;
      if (this.activeFilter === "favorites") return p.favorite;
      if (this.activeFilter === "untagged") return p.tags.length === 0 && !p.collectionId;
      if (this.activeTagId) {
        return p.tags.includes(this.activeTagId);
      }
      if (this.activeCollectionId) {
        return p.collectionId === this.activeCollectionId;
      }
      return true;
    }).sort((a, b) => {
      switch (this.sortOrder) {
        case "updated_desc":
          return b.updatedAt - a.updatedAt;
        case "created_asc":
          return a.createdAt - b.createdAt;
        case "title_asc":
          return a.title.localeCompare(b.title);
        case "usage_desc":
          return (b.usageCount || 0) - (a.usageCount || 0);
        case "created_desc":
        default:
          return b.createdAt - a.createdAt;
      }
    });
  }
  constructor() {
  }
  load() {
    if (typeof localStorage === "undefined") return;
    try {
      const data = localStorage.getItem("prompthub_data");
      if (data) {
        const parsed = JSON.parse(data);
        this.prompts = parsed.prompts || [];
        this.tags = parsed.tags || [];
        this.collections = parsed.collections || [];
        this.versions = parsed.versions || [];
      } else {
        this.initSampleData();
      }
    } catch (e) {
      console.error("Failed to load data", e);
      this.initSampleData();
    }
  }
  save() {
    if (typeof localStorage === "undefined") return;
    try {
      localStorage.setItem("prompthub_data", JSON.stringify({
        prompts: this.prompts,
        tags: this.tags,
        collections: this.collections,
        versions: this.versions
      }));
    } catch (e) {
      console.error("Failed to save data", e);
    }
  }
  initSampleData() {
    this.tags = [
      { id: "work", name: "工作", parentId: null, level: 0 },
      { id: "personal", name: "个人", parentId: null, level: 0 }
    ];
    this.collections = [{ id: "c1", name: "My Project", createdAt: Date.now() }];
    this.prompts = [
      {
        id: "p1",
        title: "示例提示词",
        content: "这是一个**示例**提示词。",
        description: "欢迎使用 PromptHub",
        tags: ["work"],
        favorite: true,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        usageCount: 0
      }
    ];
    this.save();
  }
  // CRUD
  addPrompt(prompt) {
    this.prompts.push(prompt);
    this.save();
  }
  updatePrompt(id, updates, createVersion = false) {
    const index = this.prompts.findIndex((p) => p.id === id);
    if (index !== -1) {
      if (createVersion) {
        const original = this.prompts[index];
        this.versions.push({
          versionId: crypto.randomUUID(),
          promptId: id,
          content: original.content,
          timestamp: Date.now(),
          title: original.title
        });
      }
      this.prompts[index] = { ...this.prompts[index], ...updates, updatedAt: Date.now() };
      this.save();
    }
  }
  deletePrompt(id) {
    this.prompts = this.prompts.filter((p) => p.id !== id);
    this.versions = this.versions.filter((v) => v.promptId !== id);
    this.save();
  }
  toggleFavorite(id) {
    const p = this.prompts.find((p2) => p2.id === id);
    if (p) {
      this.updatePrompt(id, { favorite: !p.favorite });
    }
  }
  toggleArchive(id) {
    const p = this.prompts.find((p2) => p2.id === id);
    if (p) {
      this.updatePrompt(id, { archived: !p.archived });
    }
  }
  duplicatePrompt(id) {
    const original = this.prompts.find((p) => p.id === id);
    if (original) {
      const duplicate = {
        ...original,
        id: crypto.randomUUID(),
        title: `${original.title} (Copy)`,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        usageCount: 0
      };
      this.prompts.push(duplicate);
      this.save();
    }
  }
  addTagsToPrompts(ids, tagIds) {
    for (const id of ids) {
      const p = this.prompts.find((p2) => p2.id === id);
      if (p) {
        const newTags = [.../* @__PURE__ */ new Set([...p.tags, ...tagIds])];
        this.updatePrompt(id, { tags: newTags });
      }
    }
  }
  // Collection CRUD
  addCollection(name) {
    this.collections.push({ id: crypto.randomUUID(), name, createdAt: Date.now() });
    this.save();
  }
  updateCollection(id, updates) {
    const index = this.collections.findIndex((c) => c.id === id);
    if (index !== -1) {
      this.collections[index] = { ...this.collections[index], ...updates };
      this.save();
    }
  }
  deleteCollection(id) {
    this.collections = this.collections.filter((c) => c.id !== id);
    this.prompts.forEach((p) => {
      if (p.collectionId === id) {
        this.updatePrompt(p.id, { collectionId: void 0 });
      }
    });
    this.save();
  }
  // Versioning Helpers
  getVersions(promptId) {
    return this.versions.filter((v) => v.promptId === promptId).sort((a, b) => b.timestamp - a.timestamp);
  }
  restoreVersion(versionId) {
    const v = this.versions.find((v2) => v2.versionId === versionId);
    if (v) {
      this.updatePrompt(v.promptId, { content: v.content, title: v.title }, true);
    }
  }
  // Batch Operations
  archivePrompts(ids, archive = true) {
    ids.forEach((id) => {
      this.updatePrompt(id, { archived: archive });
    });
  }
  movePromptsToCollection(ids, collectionId) {
    ids.forEach((id) => {
      this.updatePrompt(id, { collectionId });
    });
  }
  setFavoritePrompts(ids, favorite) {
    ids.forEach((id) => {
      this.updatePrompt(id, { favorite });
    });
  }
  deletePrompts(ids) {
    ids.forEach((id) => {
      this.deletePrompt(id);
    });
  }
  // Tag CRUD
  addTag(name, parentId) {
    const id = name.toLowerCase().replace(/\s+/g, "-");
    if (this.tags.some((t) => t.id === id)) return null;
    const level = parentId ? (this.tags.find((t) => t.id === parentId)?.level || 0) + 1 : 0;
    const newTag = { id, name, parentId, level };
    this.tags.push(newTag);
    this.save();
    return newTag;
  }
  updateTag(id, updates) {
    const index = this.tags.findIndex((t) => t.id === id);
    if (index !== -1) {
      this.tags[index] = { ...this.tags[index], ...updates };
      this.save();
    }
  }
  deleteTag(id) {
    const toDelete = /* @__PURE__ */ new Set();
    const collect = (tid) => {
      toDelete.add(tid);
      this.tags.filter((t) => t.parentId === tid).forEach((t) => collect(t.id));
    };
    collect(id);
    this.tags = this.tags.filter((t) => !toDelete.has(t.id));
    this.prompts = this.prompts.map((p) => ({ ...p, tags: p.tags.filter((t) => !toDelete.has(t)) }));
    this.save();
  }
  // Data Management
  exportData() {
    return JSON.stringify(
      {
        prompts: this.prompts,
        tags: this.tags,
        collections: this.collections,
        versions: this.versions,
        timestamp: Date.now()
      },
      null,
      2
    );
  }
  importData(json, mode) {
    try {
      const data = JSON.parse(json);
      if (!Array.isArray(data.prompts)) throw new Error("Invalid format: missing prompts array");
      if (mode === "replace") {
        this.prompts = data.prompts || [];
        this.tags = data.tags || [];
        this.collections = data.collections || [];
        this.versions = data.versions || [];
      } else {
        const mergeList = (current, incoming) => {
          const ids = new Set(current.map((i) => i.id));
          return [...current, ...incoming.filter((i) => !ids.has(i.id))];
        };
        this.prompts = mergeList(this.prompts, data.prompts || []);
        this.tags = mergeList(this.tags, data.tags || []);
        this.collections = mergeList(this.collections, data.collections || []);
        const vIds = new Set(this.versions.map((v) => v.versionId));
        this.versions = [
          ...this.versions,
          ...(data.versions || []).filter((v) => !vIds.has(v.versionId))
        ];
      }
      this.save();
      return { success: true };
    } catch (e) {
      console.error("Import failed", e);
      return { success: false, error: e.message };
    }
  }
}
const promptStore = new PromptStore();
function TagTree_1($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { tags, level = 0, onEditTag } = $$props;
    let expanded = /* @__PURE__ */ new Set();
    function getChildren(parentId) {
      return promptStore.tags.filter((t) => t.parentId === parentId);
    }
    $$renderer2.push(`<div class="space-y-0.5"><!--[-->`);
    const each_array = ensure_array_like(tags);
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      let tag = each_array[$$index];
      const children = getChildren(tag.id);
      const hasChildren = children.length > 0;
      $$renderer2.push(`<div class="group relative"><div class="w-full text-left px-2 py-1.5 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700 flex items-center gap-2 text-sm transition-colors cursor-pointer"${attr_style(`padding-left: ${stringify(level * 12 + 8)}px`)} role="button" tabindex="0">`);
      if (hasChildren) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<span${attr_class("text-gray-400 group-hover:text-gray-600 transition-transform duration-200", void 0, { "rotate-90": expanded.has(tag.id) })}>`);
        Chevron_right($$renderer2, { size: 14 });
        $$renderer2.push(`<!----></span>`);
      } else {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push(`<span class="w-[14px]"></span>`);
      }
      $$renderer2.push(`<!--]--> `);
      if (hasChildren) {
        $$renderer2.push("<!--[-->");
        Folder($$renderer2, { size: 14, class: "text-blue-500" });
      } else {
        $$renderer2.push("<!--[!-->");
        Hash($$renderer2, { size: 14, class: "text-gray-400" });
      }
      $$renderer2.push(`<!--]--> <span class="truncate flex-1">${escape_html(tag.name)}</span></div> <div class="absolute right-2 top-1/2 -translate-y-1/2 hidden group-hover:flex items-center gap-1 bg-gray-100 dark:bg-gray-800 rounded shadow-sm px-1"><button class="p-1 text-gray-500 hover:text-indigo-500 transition-colors">`);
      Pencil($$renderer2, { size: 12 });
      $$renderer2.push(`<!----></button> <button class="p-1 text-gray-500 hover:text-red-500 transition-colors">`);
      Trash_2($$renderer2, { size: 12 });
      $$renderer2.push(`<!----></button></div> `);
      if (hasChildren && expanded.has(tag.id)) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div>`);
        TagTree_1($$renderer2, { tags: children, level: level + 1, onEditTag });
        $$renderer2.push(`<!----></div>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></div>`);
    }
    $$renderer2.push(`<!--]--></div>`);
  });
}
function CollectionTree($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let editingId = null;
    let editingName = "";
    $$renderer2.push(`<div class="mt-6"><div class="flex items-center justify-between px-2 mb-2"><h3 class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Collections</h3> <button class="text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors" title="New Collection">`);
    Plus($$renderer2, { size: 14 });
    $$renderer2.push(`<!----></button></div> <div class="space-y-0.5"><!--[-->`);
    const each_array = ensure_array_like(promptStore.collections);
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      let collection = each_array[$$index];
      const isActive = promptStore.activeCollectionId === collection.id;
      if (editingId === collection.id) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="flex items-center gap-1 px-2 py-1 bg-white dark:bg-gray-800 border border-indigo-500 rounded-lg"><input type="text"${attr("value", editingName)} class="w-full text-sm bg-transparent outline-none text-gray-900 dark:text-gray-100 min-w-0"/> <button class="text-green-500" aria-label="Confirm update">`);
        Check($$renderer2, { size: 14 });
        $$renderer2.push(`<!----></button> <button class="text-gray-400" aria-label="Cancel edit">`);
        X($$renderer2, { size: 14 });
        $$renderer2.push(`<!----></button></div>`);
      } else {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push(`<div${attr_class(`group flex items-center justify-between px-2 py-2 rounded-lg cursor-pointer transition-colors text-sm ${stringify(isActive ? "bg-indigo-50 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-300" : "text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800")}`)} role="button" tabindex="0"><div class="flex items-center gap-2 min-w-0">`);
        if (isActive) {
          $$renderer2.push("<!--[-->");
          Folder_open($$renderer2, { size: 16, class: "flex-shrink-0" });
        } else {
          $$renderer2.push("<!--[!-->");
          Folder($$renderer2, { size: 16, class: "flex-shrink-0" });
        }
        $$renderer2.push(`<!--]--> <span class="truncate">${escape_html(collection.name)}</span></div> <div class="hidden group-hover:flex items-center gap-1"><button class="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors">`);
        Pen($$renderer2, { size: 12 });
        $$renderer2.push(`<!----></button> <button class="p-1 text-gray-400 hover:text-red-500 transition-colors">`);
        Trash_2($$renderer2, { size: 12 });
        $$renderer2.push(`<!----></button></div></div>`);
      }
      $$renderer2.push(`<!--]-->`);
    }
    $$renderer2.push(`<!--]--> `);
    {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> `);
    if (promptStore.collections.length === 0 && true) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="px-2 py-4 text-center text-xs text-gray-400 border border-dashed border-gray-200 dark:border-gray-800 rounded-lg">No collections yet</div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--></div></div>`);
  });
}
function DataModal($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { isOpen = false, onClose } = $$props;
    let importMode = "merge";
    if (isOpen) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" role="button" tabindex="-1" aria-label="Close modal"><div class="bg-white dark:bg-gray-800 rounded-xl shadow-2xl w-full max-w-lg overflow-hidden"><div class="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-800"><h3 class="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2">`);
      Database($$renderer2, { size: 20, class: "text-indigo-500" });
      $$renderer2.push(`<!----> Data Management</h3> <button class="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">`);
      X($$renderer2, { size: 20 });
      $$renderer2.push(`<!----></button></div> <div class="p-6 space-y-8"><div><h4 class="text-sm font-semibold text-gray-900 dark:text-white mb-2 flex items-center gap-2">`);
      Download($$renderer2, { size: 16 });
      $$renderer2.push(`<!----> Export Data</h4> <p class="text-xs text-gray-500 mb-3">Download a backup of all your prompts, tags, and
                        collections as a JSON file.</p> <button class="w-full py-2.5 px-4 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-900 dark:text-white rounded-lg font-medium flex items-center justify-center gap-2 transition-colors border border-gray-200 dark:border-gray-600">`);
      File_braces($$renderer2, { size: 18 });
      $$renderer2.push(`<!----> Download Backup</button></div> <div class="h-px bg-gray-200 dark:bg-gray-700"></div> <div><h4 class="text-sm font-semibold text-gray-900 dark:text-white mb-2 flex items-center gap-2">`);
      Upload($$renderer2, { size: 16 });
      $$renderer2.push(`<!----> Import Data</h4> <div class="bg-indigo-50 dark:bg-indigo-900/20 p-4 rounded-lg border border-indigo-100 dark:border-indigo-900/50 mb-4"><div class="flex gap-4 mb-4"><label class="flex items-center gap-2 cursor-pointer"><input type="radio"${attr("checked", importMode === "merge", true)} value="merge" class="text-indigo-600"/> <span class="text-sm text-gray-700 dark:text-gray-300">Merge (Safe)</span></label> <label class="flex items-center gap-2 cursor-pointer"><input type="radio"${attr("checked", importMode === "replace", true)} value="replace" class="text-red-600"/> <span class="text-sm text-gray-700 dark:text-gray-300">Replace (Overwrite)</span></label></div> `);
      {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push(`<p class="text-xs text-indigo-600 dark:text-indigo-400">Adds missing items. Existing items are kept.</p>`);
      }
      $$renderer2.push(`<!--]--></div> <div class="relative"><input type="file" accept=".json" class="hidden"/> <button class="w-full py-2.5 px-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-medium flex items-center justify-center gap-2 transition-colors">`);
      Upload($$renderer2, { size: 18 });
      $$renderer2.push(`<!----> Select Backup File</button></div> `);
      {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></div></div></div></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
    bind_props($$props, { isOpen });
  });
}
function Sidebar($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let isDataModalOpen = false;
    function getRootTags() {
      return promptStore.tags.filter((t) => t.parentId === null);
    }
    let { onEditTag } = $$props;
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      $$renderer3.push(`<div class="w-80 bg-gray-50 dark:bg-gray-900/50 border-r border-gray-200 dark:border-gray-800 flex flex-col h-full glass-sidebar svelte-1xnymc"><div class="p-6 border-b border-gray-200 dark:border-gray-800 flex items-center justify-between cursor-pointer" role="button" tabindex="0"><div><h1 class="text-2xl font-bold text-primary flex items-center gap-2">`);
      Brain_circuit($$renderer3, { class: "text-indigo-500" });
      $$renderer3.push(`<!----> PromptHub</h1> <p class="text-sm text-gray-500 mt-1">Personal Prompt Manager</p></div> <button class="p-2 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-800 text-gray-500 transition-colors" title="Toggle Theme">`);
      {
        $$renderer3.push("<!--[!-->");
        Moon($$renderer3, { size: 20 });
      }
      $$renderer3.push(`<!--]--></button></div> <div class="p-4 border-b border-gray-200 dark:border-gray-800"><div class="relative">`);
      Search($$renderer3, {
        class: "absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4"
      });
      $$renderer3.push(`<!----> <input id="search-input" type="text"${attr("value", promptStore.searchTerm)} placeholder="Search prompts..." class="w-full pl-10 pr-4 py-2 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none transition-all"/></div></div> <div class="p-4 border-b border-gray-200 dark:border-gray-800"><h3 class="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">Quick Filters</h3> <div class="space-y-1"><button${attr_class("w-full text-left px-3 py-2 rounded-lg flex items-center gap-2 text-sm transition-colors", void 0, {
        "bg-indigo-50": promptStore.activeFilter === "favorites",
        "text-indigo-600": promptStore.activeFilter === "favorites",
        "hover:bg-gray-200": promptStore.activeFilter !== "favorites",
        "hover:dark:bg-gray-800": promptStore.activeFilter !== "favorites"
      })}>`);
      Star($$renderer3, { size: 16 });
      $$renderer3.push(`<!----> Favorites</button> <button${attr_class("w-full text-left px-3 py-2 rounded-lg flex items-center gap-2 text-sm transition-colors", void 0, {
        "bg-indigo-50": promptStore.activeFilter === "untagged",
        "text-indigo-600": promptStore.activeFilter === "untagged",
        "hover:bg-gray-200": promptStore.activeFilter !== "untagged",
        "hover:dark:bg-gray-800": promptStore.activeFilter !== "untagged"
      })}>`);
      Circle_question_mark($$renderer3, { size: 16 });
      $$renderer3.push(`<!----> Untagged</button> <button${attr_class("w-full text-left px-3 py-2 rounded-lg flex items-center gap-2 text-sm transition-colors", void 0, {
        "bg-indigo-50": promptStore.activeFilter === "archived",
        "text-indigo-600": promptStore.activeFilter === "archived",
        "hover:bg-gray-200": promptStore.activeFilter !== "archived",
        "hover:dark:bg-gray-800": promptStore.activeFilter !== "archived"
      })}>`);
      Archive($$renderer3, { size: 16 });
      $$renderer3.push(`<!----> Archived</button></div></div> <div class="flex-1 overflow-y-auto p-4 space-y-6">`);
      CollectionTree($$renderer3);
      $$renderer3.push(`<!----> <div><div class="flex items-center justify-between mb-3 px-2"><h3 class="text-xs font-semibold text-gray-500 uppercase tracking-wider">Tags</h3> <button class="p-1 rounded hover:bg-gray-200 dark:hover:bg-gray-800 text-gray-500 transition-colors">`);
      Plus($$renderer3, { size: 14 });
      $$renderer3.push(`<!----></button></div> `);
      TagTree_1($$renderer3, { tags: getRootTags(), onEditTag });
      $$renderer3.push(`<!----></div></div> <div class="p-4 border-t border-gray-200 dark:border-gray-800"><button class="w-full text-left px-3 py-2 rounded-lg flex items-center gap-2 text-sm text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">`);
      Database($$renderer3, { size: 16 });
      $$renderer3.push(`<!----> Data Management</button></div> `);
      DataModal($$renderer3, {
        onClose: () => isDataModalOpen = false,
        get isOpen() {
          return isDataModalOpen;
        },
        set isOpen($$value) {
          isDataModalOpen = $$value;
          $$settled = false;
        }
      });
      $$renderer3.push(`<!----></div>`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
  });
}
function PromptCard($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      prompt,
      isSelected = false
    } = $$props;
    let copied = false;
    $$renderer2.push(`<div${attr_class("prompt-card p-5 flex flex-col h-full group relative svelte-45mstk", void 0, { "ring-2": isSelected, "ring-indigo-500": isSelected })}><div class="flex items-start justify-between mb-3"><div class="flex items-center gap-2"><input type="checkbox"${attr("checked", isSelected, true)}${attr_class("w-4 h-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer opacity-0 group-hover:opacity-100 transition-opacity", void 0, { "!opacity-100": isSelected })}/> <h3 class="font-semibold text-lg text-gray-800 dark:text-gray-100 line-clamp-1">${escape_html(prompt.title)}</h3></div> <button${attr_class("text-gray-400 hover:text-yellow-500 transition-colors", void 0, { "text-yellow-500": prompt.favorite })}>`);
    Star($$renderer2, { size: 18, fill: prompt.favorite ? "currentColor" : "none" });
    $$renderer2.push(`<!----></button></div> <p class="text-sm text-gray-600 dark:text-gray-300 mb-4 line-clamp-2 min-h-[2.5em]">${escape_html(prompt.description || prompt.content)}</p> <div class="flex flex-wrap gap-2 mb-4"><!--[-->`);
    const each_array = ensure_array_like(prompt.tags);
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      let tag = each_array[$$index];
      $$renderer2.push(`<span class="px-2 py-0.5 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 text-xs rounded-full">#${escape_html(tag)}</span>`);
    }
    $$renderer2.push(`<!--]--></div> <div class="mt-auto flex items-center justify-between pt-4 border-t border-gray-100 dark:border-gray-700/50"><span class="text-xs text-gray-400">Used ${escape_html(prompt.usageCount)} times</span> <div class="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity relative"><button class="p-1.5 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-100 dark:hover:bg-indigo-900/50 rounded-md transition-colors" title="Run Prompt">`);
    Play($$renderer2, { size: 16, fill: "currentColor" });
    $$renderer2.push(`<!----></button> <div class="w-px h-6 bg-gray-200 dark:bg-gray-700 mx-1"></div> <div class="relative"><button${attr_class("p-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-md transition-colors flex items-center gap-1", void 0, { "text-green-500": copied, "text-gray-500": !copied })} title="Copy Options">`);
    {
      $$renderer2.push("<!--[!-->");
      Copy($$renderer2, { size: 16 });
    }
    $$renderer2.push(`<!--]--> `);
    Chevron_down($$renderer2, { size: 12, class: "opacity-50" });
    $$renderer2.push(`<!----></button> `);
    {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--></div> <button class="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-md text-gray-500"${attr("title", prompt.archived ? "Restore" : "Archive")}>`);
    if (prompt.archived) {
      $$renderer2.push("<!--[-->");
      Archive_restore($$renderer2, { size: 16 });
    } else {
      $$renderer2.push("<!--[!-->");
      Archive($$renderer2, { size: 16 });
    }
    $$renderer2.push(`<!--]--></button> <button class="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-md text-gray-500" title="Duplicate">`);
    Files($$renderer2, { size: 16 });
    $$renderer2.push(`<!----></button> <button class="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-md text-gray-500" title="Edit">`);
    Square_pen($$renderer2, { size: 16 });
    $$renderer2.push(`<!----></button> <button class="p-1.5 hover:bg-red-50 dark:hover:bg-red-900/30 rounded-md text-red-500" title="Delete">`);
    Trash_2($$renderer2, { size: 16 });
    $$renderer2.push(`<!----></button></div></div></div>`);
  });
}
function PromptList($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      prompts,
      selectedIds = /* @__PURE__ */ new Set(),
      viewMode = "grid"
    } = $$props;
    if (prompts.length === 0) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="h-full flex flex-col items-center justify-center text-gray-400">`);
      File_text($$renderer2, { size: 64, class: "mb-4 opacity-50" });
      $$renderer2.push(`<!----> <h3 class="text-lg font-medium text-gray-600 dark:text-gray-300">No prompts found</h3> <p>Create your first prompt to get started.</p></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<div${attr_class("p-6 pb-20", void 0, {
        "grid": viewMode === "grid",
        "grid-cols-1": viewMode === "grid",
        "md:grid-cols-2": viewMode === "grid",
        "lg:grid-cols-3": viewMode === "grid",
        "xl:grid-cols-4": viewMode === "grid",
        "gap-6": viewMode === "grid",
        "flex": viewMode === "list",
        "flex-col": viewMode === "list",
        "gap-4": viewMode === "list"
      })}><!--[-->`);
      const each_array = ensure_array_like(prompts);
      for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
        let prompt = each_array[$$index];
        PromptCard($$renderer2, {
          prompt,
          isSelected: selectedIds.has(prompt.id)
        });
      }
      $$renderer2.push(`<!--]--></div>`);
    }
    $$renderer2.push(`<!--]-->`);
  });
}
function TagModal($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { tagToEdit = null } = $$props;
    let name = tagToEdit?.name || "";
    let parentId = tagToEdit?.parentId || null;
    $$renderer2.push(`<div class="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"><div class="bg-white dark:bg-gray-800 w-full max-w-md rounded-xl shadow-2xl flex flex-col"><div class="p-6 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center"><h2 class="text-xl font-semibold text-gray-900 dark:text-gray-100">${escape_html(tagToEdit ? "Edit Tag" : "New Tag")}</h2> <button class="text-gray-500 hover:text-gray-700 dark:hover:text-gray-300">`);
    X($$renderer2, { size: 20 });
    $$renderer2.push(`<!----></button></div> <div class="p-6 space-y-4"><div><label class="block text-sm font-medium mb-1 text-gray-700 dark:text-gray-300">Name</label> <input type="text"${attr("value", name)} class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-indigo-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 outline-none" placeholder="e.g. Work"/></div> <div><label class="block text-sm font-medium mb-1 text-gray-700 dark:text-gray-300">Parent Tag</label> `);
    $$renderer2.select(
      {
        value: parentId,
        class: "w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-indigo-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 outline-none"
      },
      ($$renderer3) => {
        $$renderer3.option({ value: null }, ($$renderer4) => {
          $$renderer4.push(`None (Top Level)`);
        });
        $$renderer3.push(`<!--[-->`);
        const each_array = ensure_array_like(promptStore.tags);
        for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
          let tag = each_array[$$index];
          $$renderer3.option({ value: tag.id }, ($$renderer4) => {
            $$renderer4.push(`${escape_html("--".repeat(tag.level))} ${escape_html(tag.name)}`);
          });
        }
        $$renderer3.push(`<!--]-->`);
      }
    );
    $$renderer2.push(`</div></div> <div class="p-6 border-t border-gray-200 dark:border-gray-700 flex justify-end gap-3"><button class="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300 transition-colors">Cancel</button> <button class="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 shadow-md transition-colors">Save</button></div></div></div>`);
  });
}
function ConfirmModal($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      isOpen = false,
      title = "Confirm Action",
      message = "Are you sure you want to proceed?",
      confirmText = "Confirm",
      cancelText = "Cancel",
      variant = "danger"
    } = $$props;
    const variantStyles = {
      danger: { icon: "text-red-500", button: "bg-red-600 hover:bg-red-700" },
      warning: {
        icon: "text-amber-500",
        button: "bg-amber-600 hover:bg-amber-700"
      },
      info: {
        icon: "text-blue-500",
        button: "bg-blue-600 hover:bg-blue-700"
      }
    };
    if (isOpen) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center" role="dialog" aria-modal="true"><div class="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl w-full max-w-md mx-4 overflow-hidden" role="alertdialog"><div class="flex items-center justify-between p-5 border-b border-gray-200 dark:border-gray-700"><div class="flex items-center gap-3"><div${attr_class(`p-2 rounded-full bg-gray-100 dark:bg-gray-700 ${variantStyles[variant].icon}`)}>`);
      Triangle_alert($$renderer2, { size: 20 });
      $$renderer2.push(`<!----></div> <h3 class="text-lg font-semibold text-gray-900 dark:text-gray-100">${escape_html(title)}</h3></div> <button class="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">`);
      X($$renderer2, { size: 18, class: "text-gray-500" });
      $$renderer2.push(`<!----></button></div> <div class="p-5"><p class="text-gray-600 dark:text-gray-300">${escape_html(message)}</p></div> <div class="flex justify-end gap-3 p-5 pt-0"><button class="px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors font-medium">${escape_html(cancelText)}</button> <button${attr_class(`px-4 py-2 text-white rounded-lg transition-colors font-medium ${variantStyles[variant].button}`)}>${escape_html(confirmText)}</button></div></div></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
  });
}
function TemplateLibrary($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { isOpen = false } = $$props;
    const templates = [
      {
        icon: "Sparkles",
        category: "General",
        title: "Brainstorming Assistant",
        description: "Generate creative ideas on any topic",
        content: `Help me brainstorm ideas for {{topic}}.

Consider:
- Innovative approaches
- Potential challenges
- Quick wins vs long-term solutions

Provide at least 5 unique ideas with brief explanations.`,
        tags: ["creativity", "brainstorming"]
      },
      {
        icon: "Code2",
        category: "Development",
        title: "Code Reviewer",
        description: "Get thorough code review feedback",
        content: `Review this {{language}} code:

\`\`\`
{{code}}
\`\`\`

Analyze for:
1. Bugs or potential issues
2. Performance improvements
3. Code style and best practices
4. Security concerns

Provide specific suggestions with examples.`,
        tags: ["development", "code-review"]
      },
      {
        icon: "Pencil",
        category: "Writing",
        title: "Content Rewriter",
        description: "Improve and rewrite any text",
        content: `Rewrite the following text to be more {{style}}:

Original:
{{text}}

Requirements:
- Maintain the core message
- Improve clarity and flow
- Target audience: {{audience}}`,
        tags: ["writing", "editing"]
      },
      {
        icon: "MessageSquare",
        category: "Communication",
        title: "Email Composer",
        description: "Draft professional emails quickly",
        content: `Write a {{tone}} email for the following situation:

Purpose: {{purpose}}
Key points to include:
{{key_points}}

Keep it concise and professional.`,
        tags: ["email", "communication"]
      },
      {
        icon: "FileText",
        category: "Documentation",
        title: "README Generator",
        description: "Create project documentation",
        content: `Generate a README.md for a project with these details:

Project Name: {{project_name}}
Description: {{description}}
Tech Stack: {{tech_stack}}
Features: {{features}}

Include sections for: Installation, Usage, Contributing, License.`,
        tags: ["documentation", "development"]
      },
      {
        icon: "Lightbulb",
        category: "Learning",
        title: "Concept Explainer",
        description: "Get clear explanations of complex topics",
        content: `Explain {{concept}} in simple terms.

Requirements:
- Use analogies when helpful
- Provide practical examples
- Target knowledge level: {{level}}

Break down complex parts step by step.`,
        tags: ["learning", "education"]
      }
    ];
    const iconMap = { Sparkles, Code2: Code_xml, Pencil, MessageSquare: Message_square, FileText: File_text, Lightbulb };
    if (isOpen) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4" role="dialog" aria-modal="true" tabindex="-1"><div class="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl w-full max-w-3xl max-h-[85vh] overflow-hidden flex flex-col" role="document" tabindex="-1"><div class="flex items-center justify-between p-5 border-b border-gray-200 dark:border-gray-700"><div class="flex items-center gap-3"><div class="p-2 rounded-full bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400">`);
      Sparkles($$renderer2, { size: 20 });
      $$renderer2.push(`<!----></div> <div><h2 class="text-lg font-semibold text-gray-900 dark:text-gray-100">Template Library</h2> <p class="text-sm text-gray-500 dark:text-gray-400">Pre-built prompts to get you started</p></div></div> <button class="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors" aria-label="Close">`);
      X($$renderer2, { size: 18, class: "text-gray-500" });
      $$renderer2.push(`<!----></button></div> <div class="flex-1 overflow-y-auto p-5"><div class="grid grid-cols-1 md:grid-cols-2 gap-4"><!--[-->`);
      const each_array = ensure_array_like(templates);
      for (let $$index_1 = 0, $$length = each_array.length; $$index_1 < $$length; $$index_1++) {
        let template = each_array[$$index_1];
        const IconComponent = iconMap[template.icon];
        $$renderer2.push(`<div class="group border border-gray-200 dark:border-gray-700 rounded-xl p-4 hover:border-indigo-300 dark:hover:border-indigo-500 hover:shadow-lg transition-all cursor-pointer bg-white dark:bg-gray-800/50" role="button" tabindex="0"><div class="flex items-start justify-between mb-3"><div class="flex items-center gap-3"><div class="p-2 rounded-lg bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 group-hover:bg-indigo-100 dark:group-hover:bg-indigo-900/30 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors"><!---->`);
        IconComponent($$renderer2, { size: 18 });
        $$renderer2.push(`<!----></div> <div><span class="text-xs text-gray-400 dark:text-gray-500">${escape_html(template.category)}</span> <h3 class="font-medium text-gray-900 dark:text-gray-100">${escape_html(template.title)}</h3></div></div> <button class="opacity-0 group-hover:opacity-100 p-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition-all" title="Add to library" aria-label="Add template to library">`);
        Plus($$renderer2, { size: 16 });
        $$renderer2.push(`<!----></button></div> <p class="text-sm text-gray-500 dark:text-gray-400 mb-3">${escape_html(template.description)}</p> <div class="flex flex-wrap gap-1.5"><!--[-->`);
        const each_array_1 = ensure_array_like(template.tags);
        for (let $$index = 0, $$length2 = each_array_1.length; $$index < $$length2; $$index++) {
          let tag = each_array_1[$$index];
          $$renderer2.push(`<span class="px-2 py-0.5 bg-gray-100 dark:bg-gray-700 text-gray-500 dark:text-gray-400 rounded text-xs">${escape_html(tag)}</span>`);
        }
        $$renderer2.push(`<!--]--></div></div>`);
      }
      $$renderer2.push(`<!--]--></div></div></div></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
  });
}
function RunPromptModal($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { isOpen = false, prompt } = $$props;
    let variables = [];
    let values = {};
    let copied = false;
    let viewMode = "preview";
    let compiledPrompt = (() => {
      if (!prompt) return "";
      let text = prompt.content;
      for (const [key, val] of Object.entries(values)) {
        const regex = new RegExp(`\\{\\{\\s*${key}\\s*\\}\\}`, "g");
        if (val) {
          text = text.replace(regex, val);
        }
      }
      return text;
    })();
    let renderedHtml = (() => {
      try {
        return marked.parse(compiledPrompt);
      } catch (e) {
        return compiledPrompt;
      }
    })();
    if (isOpen && prompt) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4" role="dialog" aria-modal="true" tabindex="-1"><div class="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden" role="document" tabindex="-1"><div class="flex items-center justify-between p-5 border-b border-gray-200 dark:border-gray-700"><div class="flex items-center gap-3"><div class="p-2 rounded-full bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400">`);
      Play($$renderer2, { size: 20 });
      $$renderer2.push(`<!----></div> <div><h3 class="text-lg font-semibold text-gray-900 dark:text-gray-100">Run Prompt</h3> <p class="text-sm text-gray-500 dark:text-gray-400 line-clamp-1 max-w-sm">${escape_html(prompt.title)}</p></div></div> <button class="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">`);
      X($$renderer2, { size: 18, class: "text-gray-500" });
      $$renderer2.push(`<!----></button></div> <div class="flex-1 overflow-y-auto p-0 flex flex-col md:flex-row divide-y md:divide-y-0 md:divide-x divide-gray-200 dark:divide-gray-700"><div class="p-6 bg-gray-50 dark:bg-gray-800/50 w-full md:w-1/3 flex-shrink-0 overflow-y-auto"><h4 class="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-4">Variables</h4> `);
      if (variables.length > 0) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="space-y-4"><!--[-->`);
        const each_array = ensure_array_like(variables);
        for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
          let variable = each_array[$$index];
          $$renderer2.push(`<div><label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">${escape_html(variable)}</label> <textarea rows="2" class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-indigo-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 outline-none resize-none text-sm shadow-sm"${attr("placeholder", `Enter value for ${variable}...`)}>`);
          const $$body = escape_html(values[variable]);
          if ($$body) {
            $$renderer2.push(`${$$body}`);
          }
          $$renderer2.push(`</textarea></div>`);
        }
        $$renderer2.push(`<!--]--></div>`);
      } else {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push(`<div class="flex flex-col items-center justify-center h-40 text-gray-400 text-center border-2 border-dashed border-gray-200 dark:border-gray-700 rounded-lg">`);
        Terminal($$renderer2, { size: 32, class: "mb-2 opacity-50" });
        $$renderer2.push(`<!----> <p class="text-sm">No variables detected.</p> <p class="text-xs mt-1 px-4">Use <code>{{variable}}</code> syntax in your
                                prompt content.</p></div>`);
      }
      $$renderer2.push(`<!--]--></div> <div class="flex-1 flex flex-col min-h-[50vh] bg-white dark:bg-gray-900"><div class="flex items-center justify-between p-3 border-b border-gray-100 dark:border-gray-800"><div class="flex bg-gray-100 dark:bg-gray-800 rounded-lg p-1"><button${attr_class("px-3 py-1 text-xs font-medium rounded-md transition-all flex items-center gap-1.5", void 0, {
        "bg-white": viewMode === "preview",
        "dark:bg-gray-700": viewMode === "preview",
        "shadow-sm": viewMode === "preview",
        "text-gray-900": viewMode === "preview",
        "dark:text-gray-100": viewMode === "preview",
        "text-gray-500": viewMode !== "preview"
      })}>`);
      File_text($$renderer2, { size: 14 });
      $$renderer2.push(`<!----> Preview</button> <button${attr_class("px-3 py-1 text-xs font-medium rounded-md transition-all flex items-center gap-1.5", void 0, {
        "bg-white": viewMode === "raw",
        "dark:bg-gray-700": viewMode === "raw",
        "shadow-sm": viewMode === "raw",
        "text-gray-900": viewMode === "raw",
        "dark:text-gray-100": viewMode === "raw",
        "text-gray-500": viewMode !== "raw"
      })}>`);
      Code($$renderer2, { size: 14 });
      $$renderer2.push(`<!----> Raw</button></div> <button${attr_class("flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors", void 0, {
        "bg-green-100": copied,
        "text-green-700": copied,
        "bg-indigo-50": !copied,
        "text-indigo-600": !copied,
        "hover:bg-indigo-100": !copied
      })}>`);
      {
        $$renderer2.push("<!--[!-->");
        Copy($$renderer2, { size: 14 });
        $$renderer2.push(`<!----> Copy`);
      }
      $$renderer2.push(`<!--]--></button></div> <div class="flex-1 p-6 overflow-y-auto">`);
      {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="prose dark:prose-invert max-w-none text-sm">${html(renderedHtml)}</div>`);
      }
      $$renderer2.push(`<!--]--></div></div></div></div></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
  });
}
function ThemeToggle($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    $$renderer2.push(`<button class="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"${attr("title", "Switch to Dark Mode")}>`);
    {
      $$renderer2.push("<!--[!-->");
      Moon($$renderer2, { size: 18, class: "text-gray-600" });
    }
    $$renderer2.push(`<!--]--></button>`);
  });
}
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { prompts, filteredPrompts } = promptStore;
    let isTagModalOpen = false;
    let isTemplateLibraryOpen = false;
    let editingTag = null;
    let selectedIds = /* @__PURE__ */ new Set();
    let viewMode = "grid";
    let isConfirmOpen = false;
    let confirmConfig = { title: "", message: "" };
    let isRunOpen = false;
    let runPrompt = null;
    $$renderer2.push(`<div class="flex h-screen w-full bg-white dark:bg-gray-900 overflow-hidden text-gray-900 dark:text-gray-100 font-sans">`);
    Sidebar($$renderer2, {
      onEditTag: (tag) => {
        editingTag = tag;
        isTagModalOpen = true;
      }
    });
    $$renderer2.push(`<!----> <main class="flex-1 flex flex-col min-w-0 bg-gray-50/50 dark:bg-black/20"><div class="p-4 border-b border-gray-200 dark:border-gray-800 flex justify-between items-center bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm sticky top-0 z-10"><div class="flex items-center gap-4"><button class="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 flex items-center gap-2 shadow-lg shadow-indigo-500/20 transition-all font-medium">`);
    Plus($$renderer2, { size: 18 });
    $$renderer2.push(`<!----> New Prompt</button> <button class="px-3 py-2 bg-gradient-to-r from-purple-500 to-indigo-500 text-white rounded-lg hover:from-purple-600 hover:to-indigo-600 flex items-center gap-2 text-sm transition-all font-medium">`);
    Sparkles($$renderer2, { size: 16 });
    $$renderer2.push(`<!----> Templates</button> <div class="flex gap-2 border-l pl-4 border-gray-200 dark:border-gray-700"><button class="px-3 py-2 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 flex items-center gap-2 text-sm transition-colors">`);
    Download($$renderer2, { size: 16 });
    $$renderer2.push(`<!----> Export</button> <button class="px-3 py-2 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 flex items-center gap-2 text-sm transition-colors">`);
    Upload($$renderer2, { size: 16 });
    $$renderer2.push(`<!----> Import</button></div></div> <div class="flex items-center gap-4">`);
    ThemeToggle($$renderer2);
    $$renderer2.push(`<!----> <div class="flex items-center gap-2"><span class="text-xs text-gray-500">Sort:</span> `);
    $$renderer2.select(
      {
        value: promptStore.sortOrder,
        class: "text-sm bg-transparent border-none outline-none text-gray-700 dark:text-gray-300 cursor-pointer focus:ring-0"
      },
      ($$renderer3) => {
        $$renderer3.option({ value: "created_desc" }, ($$renderer4) => {
          $$renderer4.push(`Newest`);
        });
        $$renderer3.option({ value: "created_asc" }, ($$renderer4) => {
          $$renderer4.push(`Oldest`);
        });
        $$renderer3.option({ value: "updated_desc" }, ($$renderer4) => {
          $$renderer4.push(`Recently Updated`);
        });
        $$renderer3.option({ value: "title_asc" }, ($$renderer4) => {
          $$renderer4.push(`A-Z`);
        });
        $$renderer3.option({ value: "usage_desc" }, ($$renderer4) => {
          $$renderer4.push(`Most Used`);
        });
      }
    );
    $$renderer2.push(`</div> <div class="w-px h-4 bg-gray-200 dark:bg-gray-700"></div> <span class="text-sm text-gray-500">${escape_html(filteredPrompts.length)} prompts</span> <button class="p-2 rounded hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"${attr("title", "Switch to List View")}>`);
    {
      $$renderer2.push("<!--[-->");
      Layout_list($$renderer2, { size: 18 });
    }
    $$renderer2.push(`<!--]--></button></div></div> <div class="flex-1 overflow-y-auto">`);
    PromptList($$renderer2, {
      prompts: filteredPrompts,
      selectedIds,
      viewMode
    });
    $$renderer2.push(`<!----></div> `);
    if (selectedIds.size > 0) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="fixed bottom-6 left-1/2 -translate-x-1/2 bg-white dark:bg-gray-800 text-gray-900 dark:text-white px-4 py-2 rounded-full shadow-2xl border border-gray-200 dark:border-gray-700 flex items-center gap-2 z-50"><span class="text-xs font-semibold text-gray-500 uppercase tracking-wider px-2">${escape_html(selectedIds.size)} selected</span> <div class="w-px h-4 bg-gray-300 dark:bg-gray-600 mx-1"></div> <button class="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full text-amber-500 transition-colors" title="Toggle Favorite">`);
      Star($$renderer2, {
        size: 18,
        fill: Array.from(selectedIds).every((id) => promptStore.prompts.find((p) => p.id === id)?.favorite) ? "currentColor" : "none"
      });
      $$renderer2.push(`<!----></button> <button class="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full text-gray-600 dark:text-gray-300 transition-colors" title="Archive">`);
      Archive($$renderer2, { size: 18 });
      $$renderer2.push(`<!----></button> <div class="w-px h-4 bg-gray-300 dark:bg-gray-600 mx-1"></div> <button class="flex items-center gap-2 px-3 py-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg text-sm transition-colors text-gray-700 dark:text-gray-200">`);
      Folder_input($$renderer2, { size: 16 });
      $$renderer2.push(`<!----> Move</button> <div class="relative"><button class="flex items-center gap-2 px-3 py-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg text-sm transition-colors text-gray-700 dark:text-gray-200">`);
      Tag($$renderer2, { size: 16 });
      $$renderer2.push(`<!----> Tag</button> `);
      {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></div> <div class="w-px h-4 bg-gray-300 dark:bg-gray-600 mx-1"></div> <button class="flex items-center gap-2 px-3 py-1.5 bg-red-50 hover:bg-red-100 dark:bg-red-900/20 dark:hover:bg-red-900/30 text-red-600 dark:text-red-400 rounded-lg text-sm transition-colors">`);
      Trash_2($$renderer2, { size: 16 });
      $$renderer2.push(`<!----> Delete</button> <button class="ml-2 p-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full text-gray-400 transition-colors">`);
      X($$renderer2, { size: 16 });
      $$renderer2.push(`<!----></button></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--></main> `);
    {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> `);
    {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> `);
    {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> `);
    if (isTagModalOpen) {
      $$renderer2.push("<!--[-->");
      TagModal($$renderer2, {
        tagToEdit: editingTag
      });
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> `);
    ConfirmModal($$renderer2, {
      isOpen: isConfirmOpen,
      title: confirmConfig.title,
      message: confirmConfig.message,
      confirmText: "Delete",
      variant: "danger"
    });
    $$renderer2.push(`<!----> `);
    TemplateLibrary($$renderer2, {
      isOpen: isTemplateLibraryOpen
    });
    $$renderer2.push(`<!----> `);
    RunPromptModal($$renderer2, {
      isOpen: isRunOpen,
      prompt: runPrompt
    });
    $$renderer2.push(`<!----></div>`);
  });
}
export {
  _page as default
};
