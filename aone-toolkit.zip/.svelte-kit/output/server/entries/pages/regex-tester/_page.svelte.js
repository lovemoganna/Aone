import { Z as sanitize_props, _ as spread_props, $ as slot, a7 as head, a3 as attr, a4 as ensure_array_like, a0 as attr_class, a1 as stringify } from "../../../chunks/index2.js";
import { I as Icon } from "../../../chunks/Icon.js";
import { I as Info } from "../../../chunks/info.js";
import { e as escape_html } from "../../../chunks/context.js";
function Flag($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "path",
      {
        "d": "M4 22V4a1 1 0 0 1 .4-.8A6 6 0 0 1 8 2c3 0 5 2 7.333 2q2 0 3.067-.8A1 1 0 0 1 20 4v10a1 1 0 0 1-.4.8A6 6 0 0 1 16 16c-3 0-5-2-8-2a6 6 0 0 0-4 1.528"
      }
    ]
  ];
  Icon($$renderer, spread_props([
    { name: "flag" },
    $$sanitized_props,
    {
      /**
       * @component @name Flag
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNNCAyMlY0YTEgMSAwIDAgMSAuNC0uOEE2IDYgMCAwIDEgOCAyYzMgMCA1IDIgNy4zMzMgMnEyIDAgMy4wNjctLjhBMSAxIDAgMCAxIDIwIDR2MTBhMSAxIDAgMCAxLS40LjhBNiA2IDAgMCAxIDE2IDE2Yy0zIDAtNS0yLTgtMmE2IDYgMCAwIDAtNCAxLjUyOCIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/flag
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Regex($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    ["path", { "d": "M17 3v10" }],
    ["path", { "d": "m12.67 5.5 8.66 5" }],
    ["path", { "d": "m12.67 10.5 8.66-5" }],
    [
      "path",
      {
        "d": "M9 17a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v2a2 2 0 0 0 2 2h2a2 2 0 0 0 2-2v-2z"
      }
    ]
  ];
  Icon($$renderer, spread_props([
    { name: "regex" },
    $$sanitized_props,
    {
      /**
       * @component @name Regex
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTcgM3YxMCIgLz4KICA8cGF0aCBkPSJtMTIuNjcgNS41IDguNjYgNSIgLz4KICA8cGF0aCBkPSJtMTIuNjcgMTAuNSA4LjY2LTUiIC8+CiAgPHBhdGggZD0iTTkgMTdhMiAyIDAgMCAwLTItMkg1YTIgMiAwIDAgMC0yIDJ2MmEyIDIgMCAwIDAgMiAyaDJhMiAyIDAgMCAwIDItMnYtMnoiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/regex
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let pattern = "";
    let flags = "gm";
    let text = "";
    const flagOptions = [
      {
        char: "g",
        label: "Global",
        desc: "Don't return after first match"
      },
      {
        char: "m",
        label: "Multi line",
        desc: "^ and $ match start/end of line"
      },
      {
        char: "i",
        label: "Insensitive",
        desc: "Case insensitive match"
      },
      { char: "s", label: "Single line", desc: "Dot matches newline" },
      { char: "u", label: "Unicode", desc: "Match full unicode" },
      { char: "y", label: "Sticky", desc: "Anchor to last match" }
    ];
    let matches = /* @__PURE__ */ (() => {
      return [];
    })();
    head("fglsru", $$renderer2, ($$renderer3) => {
      $$renderer3.title(($$renderer4) => {
        $$renderer4.push(`<title>Regex Tester</title>`);
      });
    });
    $$renderer2.push(`<div class="min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100 p-4 lg:p-8 flex flex-col gap-6"><div class="flex items-center gap-3"><div class="w-10 h-10 rounded-xl bg-pink-500 flex items-center justify-center text-white shadow-lg shadow-pink-500/30">`);
    Regex($$renderer2, { size: 24 });
    $$renderer2.push(`<!----></div> <h1 class="text-2xl font-bold">Regex Tester</h1></div> <div class="grid grid-cols-1 lg:grid-cols-3 gap-6"><div class="lg:col-span-2 flex flex-col gap-6"><div class="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm border border-gray-200 dark:border-gray-700 flex flex-col gap-4"><div class="flex items-center gap-2 text-gray-500 text-sm font-medium">`);
    Regex($$renderer2, { size: 16 });
    $$renderer2.push(`<!----> Regular Expression</div> <div class="flex items-center gap-2 bg-gray-50 dark:bg-gray-900/50 p-2 rounded-lg border border-gray-200 dark:border-gray-700 focus-within:ring-2 focus-within:ring-pink-500 transition-all"><span class="text-gray-400 font-mono text-lg select-none">/</span> <input type="text"${attr("value", pattern)} class="flex-1 bg-transparent border-none outline-none font-mono text-lg text-gray-900 dark:text-white placeholder-gray-400" placeholder="Expression..."/> <span class="text-gray-400 font-mono text-lg select-none">/</span> <input type="text"${attr("value", flags)} class="w-16 bg-transparent border-none outline-none font-mono text-lg text-gray-500" placeholder="gmi"/></div> `);
    {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> <div class="flex flex-wrap gap-2"><!--[-->`);
    const each_array = ensure_array_like(flagOptions);
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      let opt = each_array[$$index];
      $$renderer2.push(`<button${attr_class(`px-2 py-1 flex items-center gap-2 rounded text-xs font-mono border transition-all ${stringify(flags.includes(opt.char) ? "bg-pink-50 dark:bg-pink-900/20 border-pink-200 dark:border-pink-800 text-pink-700 dark:text-pink-300" : "bg-transparent border-gray-200 dark:border-gray-700 text-gray-500 hover:border-gray-300")}`)}${attr("title", opt.desc)}>`);
      Flag($$renderer2, { size: 10 });
      $$renderer2.push(`<!----> ${escape_html(opt.char)}</button>`);
    }
    $$renderer2.push(`<!--]--></div></div> <div class="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm border border-gray-200 dark:border-gray-700 flex flex-col gap-4 flex-1"><div class="flex items-center gap-2 text-gray-500 text-sm font-medium">`);
    Info($$renderer2, { size: 16 });
    $$renderer2.push(`<!----> Test String</div> <textarea class="flex-1 w-full bg-gray-50 dark:bg-gray-900/50 border border-gray-200 dark:border-gray-700 rounded-lg p-4 font-mono text-sm resize-none focus:ring-2 focus:ring-pink-500 outline-none min-h-[200px]" placeholder="Paste text to test against...">`);
    const $$body = escape_html(text);
    if ($$body) {
      $$renderer2.push(`${$$body}`);
    }
    $$renderer2.push(`</textarea></div></div> <div class="flex flex-col gap-6"><div class="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm border border-gray-200 dark:border-gray-700 flex flex-col gap-4 h-full"><div class="flex items-center justify-between text-gray-500 text-sm font-medium"><span class="flex items-center gap-2">`);
    Info($$renderer2, { size: 16 });
    $$renderer2.push(`<!----> Matches</span> <span class="bg-gray-100 dark:bg-gray-700 px-2 py-0.5 rounded-full text-xs">${escape_html(matches ? matches.length : 0)} found</span></div> <div class="flex-1 overflow-y-auto space-y-2 max-h-[calc(100vh-250px)]">`);
    if (matches.length > 0) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<!--[-->`);
      const each_array_1 = ensure_array_like(matches);
      for (let i = 0, $$length = each_array_1.length; i < $$length; i++) {
        let match = each_array_1[i];
        $$renderer2.push(`<div class="p-3 bg-gray-50 dark:bg-gray-900/50 rounded-lg border border-gray-100 dark:border-gray-700/50 text-sm font-mono break-all group relative"><div class="absolute top-2 right-2 text-[10px] text-gray-400 opacity-0 group-hover:opacity-100">Idx: ${escape_html(match.index)}</div> <div class="text-pink-600 dark:text-pink-400 font-semibold mb-1">Match ${escape_html(i + 1)}: "${escape_html(match[0])}"</div> `);
        if (match.length > 1) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<div class="mt-2 pl-3 border-l-2 border-gray-200 dark:border-gray-700 space-y-1"><!--[-->`);
          const each_array_2 = ensure_array_like(Array.from(match).slice(1));
          for (let gIndex = 0, $$length2 = each_array_2.length; gIndex < $$length2; gIndex++) {
            let group = each_array_2[gIndex];
            $$renderer2.push(`<div class="text-gray-500 text-xs flex gap-2"><span class="text-gray-400">G${escape_html(gIndex + 1)}:</span> <span class="text-gray-700 dark:text-gray-300">${escape_html(group)}</span></div>`);
          }
          $$renderer2.push(`<!--]--></div>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--></div>`);
      }
      $$renderer2.push(`<!--]-->`);
    } else {
      $$renderer2.push("<!--[!-->");
      {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push(`<div class="text-center py-8 text-gray-400 text-sm">Enter a pattern and text to see matches.</div>`);
      }
      $$renderer2.push(`<!--]-->`);
    }
    $$renderer2.push(`<!--]--></div></div></div></div></div>`);
  });
}
export {
  _page as default
};
