import { Z as sanitize_props, _ as spread_props, $ as slot, a7 as head, a4 as ensure_array_like, a0 as attr_class, a1 as stringify } from "../../../chunks/index2.js";
import { B as Button } from "../../../chunks/Button.js";
import { P as Panel } from "../../../chunks/Panel.js";
import { S as Search } from "../../../chunks/search.js";
import { I as Icon } from "../../../chunks/Icon.js";
import { S as Shield_check } from "../../../chunks/shield-check.js";
import { a as Eye_off, E as Eye } from "../../../chunks/eye.js";
import { T as Trash_2 } from "../../../chunks/trash-2.js";
import { e as escape_html } from "../../../chunks/context.js";
function Shield_alert($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "path",
      {
        "d": "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"
      }
    ],
    ["path", { "d": "M12 8v4" }],
    ["path", { "d": "M12 16h.01" }]
  ];
  Icon($$renderer, spread_props([
    { name: "shield-alert" },
    $$sanitized_props,
    {
      /**
       * @component @name ShieldAlert
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMjAgMTNjMCA1LTMuNSA3LjUtNy42NiA4Ljk1YTEgMSAwIDAgMS0uNjctLjAxQzcuNSAyMC41IDQgMTggNCAxM1Y2YTEgMSAwIDAgMSAxLTFjMiAwIDQuNS0xLjIgNi4yNC0yLjcyYTEuMTcgMS4xNyAwIDAgMSAxLjUyIDBDMTQuNTEgMy44MSAxNyA1IDE5IDVhMSAxIDAgMCAxIDEgMXoiIC8+CiAgPHBhdGggZD0iTTEyIDh2NCIgLz4KICA8cGF0aCBkPSJNMTIgMTZoLjAxIiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/shield-alert
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function _page($$renderer) {
  let input = "";
  let showSecrets = false;
  const PATTERNS = [
    {
      name: "AWS Access Key",
      regex: /AKIA[0-9A-Z]{16}/g,
      severity: "high"
    },
    {
      name: "AWS Secret Key",
      regex: /[0-9a-zA-Z]{40}/g,
      severity: "high",
      manual: true
    },
    // High false positive, usually checked with context
    {
      name: "GitHub Token",
      regex: /gh[pous]_[a-zA-Z0-9]{36,255}/g,
      severity: "high"
    },
    {
      name: "Private Key",
      regex: /-----BEGIN [A-Z ]+ PRIVATE KEY-----/g,
      severity: "critical"
    },
    {
      name: "Google API Key",
      regex: /AIza[0-9A-Za-z-_]{35}/g,
      severity: "medium"
    },
    {
      name: "Slack Webhook",
      regex: /https:\/\/hooks\.slack\.com\/services\/[A-Z0-9]+\/[A-Z0-9]+\/[A-Z0-9]+/g,
      severity: "high"
    },
    {
      name: "Stripe API Key",
      regex: /[rk]s_live_[0-9a-zA-Z]{24}/g,
      severity: "critical"
    }
  ];
  let findings = (() => {
    if (!input) return [];
    const results = [];
    PATTERNS.forEach((p) => {
      const matches = input.matchAll(p.regex);
      for (const match of matches) {
        results.push({
          name: p.name,
          value: match[0],
          pos: match.index,
          severity: p.severity
        });
      }
    });
    return results;
  })();
  function mask(text) {
    if (showSecrets) return text;
    return text.substring(0, 4) + "****" + text.substring(text.length - 4);
  }
  head("xx9mq0", $$renderer, ($$renderer2) => {
    $$renderer2.title(($$renderer3) => {
      $$renderer3.push(`<title>Secret Scanner - Aone Toolkit</title>`);
    });
  });
  $$renderer.push(`<div class="h-[calc(100vh-3rem)] p-4 flex flex-col space-y-4">`);
  {
    let header = function($$renderer2) {
      $$renderer2.push(`<div class="flex items-center justify-between w-full"><div class="flex items-center gap-2"><div${attr_class(`w-7 h-7 rounded-lg ${stringify(findings.length > 0 ? "bg-red-100 text-red-600" : "bg-emerald-100 text-emerald-600")} flex items-center justify-center border`)}>`);
      if (findings.length > 0) {
        $$renderer2.push("<!--[-->");
        Shield_alert($$renderer2, { size: 16 });
      } else {
        $$renderer2.push("<!--[!-->");
        Shield_check($$renderer2, { size: 16 });
      }
      $$renderer2.push(`<!--]--></div> <h2 class="font-semibold text-slate-900 dark:text-white">Secret Scanner</h2></div> <div class="flex gap-2">`);
      Button($$renderer2, {
        variant: "ghost",
        size: "sm",
        onclick: () => showSecrets = !showSecrets,
        children: ($$renderer3) => {
          if (showSecrets) {
            $$renderer3.push("<!--[-->");
            Eye_off($$renderer3, { size: 14 });
          } else {
            $$renderer3.push("<!--[!-->");
            Eye($$renderer3, { size: 14 });
          }
          $$renderer3.push(`<!--]-->`);
        },
        $$slots: { default: true }
      });
      $$renderer2.push(`<!----> `);
      Button($$renderer2, {
        variant: "ghost",
        size: "sm",
        onclick: () => input = "",
        children: ($$renderer3) => {
          Trash_2($$renderer3, { size: 14 });
        },
        $$slots: { default: true }
      });
      $$renderer2.push(`<!----></div></div>`);
    };
    Panel($$renderer, {
      class: "flex-1 flex flex-col min-h-0",
      header,
      children: ($$renderer2) => {
        $$renderer2.push(`<div class="flex-1 grid grid-cols-1 md:grid-cols-2 divide-x divide-slate-100 dark:divide-slate-800"><div class="flex flex-col p-6 space-y-4"><div class="text-xs font-bold text-slate-400 uppercase tracking-wider">Paste Text to Scan</div> <textarea class="flex-1 p-4 font-mono text-xs bg-slate-50 dark:bg-black/20 border-none rounded-2xl resize-none focus:outline-none dark:text-slate-300" placeholder="Paste logs, code, or config files here...">`);
        const $$body = escape_html(input);
        if ($$body) {
          $$renderer2.push(`${$$body}`);
        }
        $$renderer2.push(`</textarea></div> <div class="flex flex-col p-6 space-y-4 bg-slate-50/30 dark:bg-black/10 overflow-y-auto"><div class="text-xs font-bold text-slate-400 uppercase tracking-wider">Detection Results (${escape_html(findings.length)})</div> `);
        if (findings.length > 0) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<div class="space-y-3"><!--[-->`);
          const each_array = ensure_array_like(findings);
          for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
            let finding = each_array[$$index];
            $$renderer2.push(`<div${attr_class(`p-4 bg-white dark:bg-slate-800 rounded-xl border-l-4 ${stringify(finding.severity === "critical" || finding.severity === "high" ? "border-l-red-500" : "border-l-amber-500")} shadow-sm`)}><div class="flex justify-between items-start mb-1"><h3${attr_class(`text-xs font-bold uppercase ${stringify(finding.severity === "critical" || finding.severity === "high" ? "text-red-600" : "text-amber-600")}`)}>${escape_html(finding.name)}</h3> <span class="text-[9px] bg-slate-100 dark:bg-slate-700 px-1.5 py-0.5 rounded text-slate-500">POS: ${escape_html(finding.pos)}</span></div> <code class="text-sm font-mono break-all text-slate-700 dark:text-slate-300">${escape_html(mask(finding.value))}</code></div>`);
          }
          $$renderer2.push(`<!--]--></div>`);
        } else {
          $$renderer2.push("<!--[!-->");
          if (input) {
            $$renderer2.push("<!--[-->");
            $$renderer2.push(`<div class="flex-1 flex flex-col items-center justify-center text-center space-y-4 opacity-50">`);
            Shield_check($$renderer2, { size: 48, class: "text-emerald-500" });
            $$renderer2.push(`<!----> <p class="text-sm font-medium">No secrets detected</p> <p class="text-xs max-w-[200px]">Keep in mind that pattern matching may not find
                            everything. Always use environment variables!</p></div>`);
          } else {
            $$renderer2.push("<!--[!-->");
            $$renderer2.push(`<div class="flex-1 flex flex-col items-center justify-center text-center space-y-4 opacity-20">`);
            Search($$renderer2, { size: 48 });
            $$renderer2.push(`<!----> <p class="text-sm">Scan results will appear here</p></div>`);
          }
          $$renderer2.push(`<!--]-->`);
        }
        $$renderer2.push(`<!--]--></div></div>`);
      }
    });
  }
  $$renderer.push(`<!----></div>`);
}
export {
  _page as default
};
