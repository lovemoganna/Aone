import { a7 as head, a3 as attr, a4 as ensure_array_like, a0 as attr_class, a1 as stringify } from "../../../chunks/index2.js";
import { B as Button } from "../../../chunks/Button.js";
import { P as Panel } from "../../../chunks/Panel.js";
import "clsx";
import { C as Code_xml } from "../../../chunks/code-xml.js";
import { P as Plus } from "../../../chunks/plus.js";
import { S as Search } from "../../../chunks/search.js";
import { C as Clock } from "../../../chunks/clock.js";
import { T as Tag } from "../../../chunks/tag.js";
import { C as Copy } from "../../../chunks/copy.js";
import { T as Trash_2 } from "../../../chunks/trash-2.js";
import { e as escape_html } from "../../../chunks/context.js";
function createSnippetStore() {
  let snippets = [];
  return {
    get snippets() {
      return snippets;
    },
    addSnippet(snippet) {
      const newSnippet = { ...snippet, id: crypto.randomUUID(), updatedAt: Date.now() };
      snippets = [newSnippet, ...snippets];
      return newSnippet;
    },
    updateSnippet(id, updates) {
      snippets = snippets.map((s) => s.id === id ? { ...s, ...updates, updatedAt: Date.now() } : s);
    },
    deleteSnippet(id) {
      snippets = snippets.filter((s) => s.id !== id);
    },
    getSnippetById(id) {
      return snippets.find((s) => s.id === id);
    }
  };
}
const snippetStore = createSnippetStore();
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let searchQuery = "";
    let selectedId = null;
    let editingSnippet = null;
    let filteredSnippets = snippetStore.snippets.filter((s) => s.title.toLowerCase().includes(searchQuery.toLowerCase()) || s.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase())) || s.language.toLowerCase().includes(searchQuery.toLowerCase()));
    let activeSnippet = selectedId ? snippetStore.getSnippetById(selectedId) : null;
    function createNew() {
      const newSnippet = snippetStore.addSnippet({
        title: "New Snippet",
        code: "",
        language: "javascript",
        description: "",
        tags: ["Draft"]
      });
      selectedId = newSnippet.id;
      startEditing();
    }
    function startEditing() {
      if (activeSnippet) {
        editingSnippet = { ...activeSnippet };
      }
    }
    function saveEdit() {
      if (editingSnippet) {
        snippetStore.updateSnippet(editingSnippet.id, editingSnippet);
        editingSnippet = null;
      }
    }
    function cancelEdit() {
      editingSnippet = null;
    }
    function handleCopy(code) {
      navigator.clipboard.writeText(code);
    }
    const LANGUAGES = [
      "javascript",
      "typescript",
      "html",
      "css",
      "python",
      "java",
      "cpp",
      "go",
      "rust",
      "sql",
      "yaml",
      "json",
      "bash"
    ];
    head("1xcpczn", $$renderer2, ($$renderer3) => {
      $$renderer3.title(($$renderer4) => {
        $$renderer4.push(`<title>Snippet Manager - Aone Toolkit</title>`);
      });
    });
    $$renderer2.push(`<div class="h-[calc(100vh-3rem)] p-4 flex gap-4 overflow-hidden"><div class="w-80 flex flex-col h-full space-y-4">`);
    {
      let header = function($$renderer3) {
        $$renderer3.push(`<div class="flex items-center justify-between w-full"><h2 class="font-semibold text-slate-900 dark:text-white">Snippets</h2> `);
        Button($$renderer3, {
          variant: "ghost",
          size: "sm",
          onclick: createNew,
          children: ($$renderer4) => {
            Plus($$renderer4, { size: 16 });
          },
          $$slots: { default: true }
        });
        $$renderer3.push(`<!----></div>`);
      };
      Panel($$renderer2, {
        class: "flex-1 flex flex-col min-h-0 overflow-hidden",
        header,
        children: ($$renderer3) => {
          $$renderer3.push(`<div class="p-3 border-b border-slate-100 dark:border-slate-800"><div class="relative">`);
          Search($$renderer3, { class: "absolute left-3 top-2.5 text-slate-400", size: 14 });
          $$renderer3.push(`<!----> <input type="search"${attr("value", searchQuery)} placeholder="Search snippets..." class="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 dark:bg-slate-800 border-none rounded-lg focus:ring-1 focus:ring-primary-500 focus:outline-none"/></div></div> <div class="flex-1 overflow-y-auto min-h-0">`);
          if (filteredSnippets.length > 0) {
            $$renderer3.push("<!--[-->");
            $$renderer3.push(`<!--[-->`);
            const each_array = ensure_array_like(filteredSnippets);
            for (let $$index_1 = 0, $$length = each_array.length; $$index_1 < $$length; $$index_1++) {
              let snippet = each_array[$$index_1];
              $$renderer3.push(`<button${attr_class(`w-full p-4 text-left border-b border-slate-50 dark:border-slate-800 transition-colors hover:bg-slate-50 dark:hover:bg-slate-800/50 ${stringify(selectedId === snippet.id ? "bg-indigo-50/50 dark:bg-indigo-900/20 border-l-4 border-l-primary-500" : "border-l-4 border-l-transparent")}`)}><div class="flex justify-between items-start mb-1"><h3 class="text-sm font-semibold truncate flex-1 pr-2">${escape_html(snippet.title)}</h3> <span class="text-[10px] bg-slate-100 dark:bg-slate-700 px-1.5 py-0.5 rounded text-slate-500 font-mono uppercase truncate max-w-[80px]">${escape_html(snippet.language)}</span></div> <p class="text-xs text-slate-500 line-clamp-1">${escape_html(snippet.description || "No description")}</p> <div class="mt-2 flex gap-1 flex-wrap"><!--[-->`);
              const each_array_1 = ensure_array_like(snippet.tags);
              for (let $$index = 0, $$length2 = each_array_1.length; $$index < $$length2; $$index++) {
                let tag = each_array_1[$$index];
                $$renderer3.push(`<span class="text-[9px] text-primary-600 dark:text-primary-400 bg-primary-100/50 dark:bg-primary-900/20 px-1.5 rounded-full">#${escape_html(tag)}</span>`);
              }
              $$renderer3.push(`<!--]--></div></button>`);
            }
            $$renderer3.push(`<!--]-->`);
          } else {
            $$renderer3.push("<!--[!-->");
            $$renderer3.push(`<div class="h-full flex flex-col items-center justify-center p-8 text-center text-slate-400">`);
            Code_xml($$renderer3, { size: 40, class: "mb-2 opacity-20" });
            $$renderer3.push(`<!----> <p class="text-sm italic">No snippets found</p></div>`);
          }
          $$renderer3.push(`<!--]--></div>`);
        }
      });
    }
    $$renderer2.push(`<!----></div> <div class="flex-1 flex flex-col h-full overflow-hidden">`);
    if (editingSnippet) {
      $$renderer2.push("<!--[-->");
      {
        let header = function($$renderer3) {
          $$renderer3.push(`<div class="flex items-center justify-between w-full"><div class="flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-orange-100 dark:bg-orange-900/30 text-orange-600 dark:text-orange-400 flex items-center justify-center">`);
          Plus($$renderer3, { size: 16 });
          $$renderer3.push(`<!----></div> <h2 class="font-semibold text-slate-900 dark:text-white">Editing Snippet</h2></div> <div class="flex gap-2">`);
          Button($$renderer3, {
            variant: "ghost",
            onclick: cancelEdit,
            children: ($$renderer4) => {
              $$renderer4.push(`<!---->Cancel`);
            },
            $$slots: { default: true }
          });
          $$renderer3.push(`<!----> `);
          Button($$renderer3, {
            onclick: saveEdit,
            children: ($$renderer4) => {
              $$renderer4.push(`<!---->Save Snippet`);
            },
            $$slots: { default: true }
          });
          $$renderer3.push(`<!----></div></div>`);
        };
        Panel($$renderer2, {
          class: "flex-1 flex flex-col min-h-0 overflow-hidden",
          header,
          children: ($$renderer3) => {
            $$renderer3.push(`<div class="flex-1 overflow-y-auto p-6 space-y-6"><div class="grid grid-cols-2 gap-4"><div class="space-y-2"><div class="text-xs font-bold text-slate-400 uppercase">Title</div> <input type="text"${attr("value", editingSnippet.title)} class="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-lg focus:ring-1 focus:ring-primary-500 outline-none font-medium"/></div> <div class="space-y-2"><div class="text-xs font-bold text-slate-400 uppercase">Language</div> `);
            $$renderer3.select(
              {
                value: editingSnippet.language,
                class: "w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-lg focus:ring-1 focus:ring-primary-500 outline-none"
              },
              ($$renderer4) => {
                $$renderer4.push(`<!--[-->`);
                const each_array_2 = ensure_array_like(LANGUAGES);
                for (let $$index_2 = 0, $$length = each_array_2.length; $$index_2 < $$length; $$index_2++) {
                  let lang = each_array_2[$$index_2];
                  $$renderer4.option({ value: lang }, ($$renderer5) => {
                    $$renderer5.push(`${escape_html(lang)}`);
                  });
                }
                $$renderer4.push(`<!--]-->`);
              }
            );
            $$renderer3.push(`</div></div> <div class="space-y-2"><div class="text-xs font-bold text-slate-400 uppercase">Description</div> <textarea class="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-lg focus:ring-1 focus:ring-primary-500 outline-none resize-none h-20 text-sm">`);
            const $$body = escape_html(editingSnippet.description);
            if ($$body) {
              $$renderer3.push(`${$$body}`);
            }
            $$renderer3.push(`</textarea></div> <div class="space-y-2 flex-1 flex flex-col min-h-0"><div class="text-xs font-bold text-slate-400 uppercase">Code Content</div> <textarea class="flex-1 w-full p-4 bg-slate-100 dark:bg-black/40 border border-slate-200 dark:border-slate-800 rounded-lg font-mono text-sm focus:ring-1 focus:ring-primary-500 outline-none min-h-[300px]" spellcheck="false">`);
            const $$body_1 = escape_html(editingSnippet.code);
            if ($$body_1) {
              $$renderer3.push(`${$$body_1}`);
            }
            $$renderer3.push(`</textarea></div></div>`);
          }
        });
      }
    } else {
      $$renderer2.push("<!--[!-->");
      if (activeSnippet) {
        $$renderer2.push("<!--[-->");
        {
          let header = function($$renderer3) {
            $$renderer3.push(`<div class="flex items-center justify-between w-full"><div class="flex items-center gap-4"><h2 class="font-semibold text-slate-900 dark:text-white">${escape_html(activeSnippet.title)}</h2> <div class="flex gap-2"><!--[-->`);
            const each_array_3 = ensure_array_like(activeSnippet.tags);
            for (let $$index_3 = 0, $$length = each_array_3.length; $$index_3 < $$length; $$index_3++) {
              let tag = each_array_3[$$index_3];
              $$renderer3.push(`<span class="text-[10px] bg-indigo-50 dark:bg-indigo-900/30 text-primary-600 dark:text-primary-400 px-2 py-0.5 rounded-full border border-primary-100 dark:border-primary-800">#${escape_html(tag)}</span>`);
            }
            $$renderer3.push(`<!--]--></div></div> <div class="flex gap-2">`);
            Button($$renderer3, {
              variant: "ghost",
              size: "sm",
              onclick: () => handleCopy(activeSnippet.code),
              children: ($$renderer4) => {
                Copy($$renderer4, { size: 16, class: "mr-2" });
                $$renderer4.push(`<!----> Copy Code`);
              },
              $$slots: { default: true }
            });
            $$renderer3.push(`<!----> `);
            Button($$renderer3, {
              variant: "ghost",
              size: "sm",
              onclick: startEditing,
              children: ($$renderer4) => {
                $$renderer4.push(`<!---->Edit`);
              },
              $$slots: { default: true }
            });
            $$renderer3.push(`<!----> `);
            Button($$renderer3, {
              variant: "ghost",
              size: "sm",
              class: "text-red-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20",
              onclick: () => {
                if (confirm("Delete snippet?")) {
                  snippetStore.deleteSnippet(activeSnippet.id);
                  selectedId = null;
                }
              },
              children: ($$renderer4) => {
                Trash_2($$renderer4, { size: 16 });
              },
              $$slots: { default: true }
            });
            $$renderer3.push(`<!----></div></div>`);
          };
          Panel($$renderer2, {
            class: "flex-1 flex flex-col min-h-0 overflow-hidden",
            header,
            children: ($$renderer3) => {
              $$renderer3.push(`<div class="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-50/30 dark:bg-black/10"><div class="grid grid-cols-1 md:grid-cols-3 gap-4"><div class="bg-white dark:bg-slate-800 p-3 rounded-xl border shadow-sm flex items-center gap-3"><div class="p-2 bg-indigo-100/50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-lg">`);
              Code_xml($$renderer3, { size: 18 });
              $$renderer3.push(`<!----></div> <div><p class="text-[10px] font-bold text-slate-400 uppercase">Language</p> <p class="text-sm font-semibold capitalize font-mono text-primary-600">${escape_html(activeSnippet.language)}</p></div></div> <div class="bg-white dark:bg-slate-800 p-3 rounded-xl border shadow-sm flex items-center gap-3"><div class="p-2 bg-emerald-100/50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-lg">`);
              Clock($$renderer3, { size: 18 });
              $$renderer3.push(`<!----></div> <div><p class="text-[10px] font-bold text-slate-400 uppercase">Last Updated</p> <p class="text-sm font-semibold">${escape_html(new Date(activeSnippet.updatedAt).toLocaleDateString())}</p></div></div> <div class="bg-white dark:bg-slate-800 p-3 rounded-xl border shadow-sm flex items-center gap-3"><div class="p-2 bg-amber-100/50 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 rounded-lg">`);
              Tag($$renderer3, { size: 18 });
              $$renderer3.push(`<!----></div> <div><p class="text-[10px] font-bold text-slate-400 uppercase">Tags</p> <p class="text-sm font-semibold">${escape_html(activeSnippet.tags.length)} Categorized</p></div></div></div> `);
              if (activeSnippet.description) {
                $$renderer3.push("<!--[-->");
                $$renderer3.push(`<div class="space-y-2"><p class="text-xs font-bold text-slate-400 uppercase px-1">Description</p> <p class="text-sm text-slate-600 dark:text-slate-400 px-1 leading-relaxed">${escape_html(activeSnippet.description)}</p></div>`);
              } else {
                $$renderer3.push("<!--[!-->");
              }
              $$renderer3.push(`<!--]--> <div class="space-y-2 flex-1 flex flex-col min-h-0"><p class="text-xs font-bold text-slate-400 uppercase px-1">Code Content</p> <div class="flex-1 bg-slate-900 text-slate-300 p-6 rounded-2xl border border-slate-800 overflow-auto font-mono text-sm leading-relaxed shadow-xl group relative"><button class="absolute top-4 right-4 p-2 bg-white/10 hover:bg-white/20 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity" title="Copy code">`);
              Copy($$renderer3, { size: 16 });
              $$renderer3.push(`<!----></button> <pre><code>${escape_html(activeSnippet.code || "// Empty snippet")}</code></pre></div></div></div>`);
            }
          });
        }
      } else {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push(`<div class="flex-1 flex flex-col items-center justify-center p-12 text-center text-slate-400 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-3xl m-4 space-y-6"><div class="w-32 h-32 bg-slate-100 dark:bg-slate-800/50 rounded-full flex items-center justify-center">`);
        Code_xml($$renderer2, { size: 64, class: "opacity-10" });
        $$renderer2.push(`<!----></div> <div><h2 class="text-xl font-bold text-slate-600 dark:text-slate-300">Snippet Library</h2> <p class="mt-2 max-w-xs text-sm">Organize your frequently used code fragments,
                        configurations, and templates in one place.</p></div> `);
        Button($$renderer2, {
          onclick: createNew,
          children: ($$renderer3) => {
            Plus($$renderer3, { size: 18, class: "mr-2" });
            $$renderer3.push(`<!----> Create First Snippet`);
          },
          $$slots: { default: true }
        });
        $$renderer2.push(`<!----></div>`);
      }
      $$renderer2.push(`<!--]-->`);
    }
    $$renderer2.push(`<!--]--></div></div>`);
  });
}
export {
  _page as default
};
