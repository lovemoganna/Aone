import { a7 as head, a4 as ensure_array_like } from "../../../chunks/index2.js";
import { B as Button } from "../../../chunks/Button.js";
import { P as Panel } from "../../../chunks/Panel.js";
import { D as Database } from "../../../chunks/database.js";
import { S as Sparkles } from "../../../chunks/sparkles.js";
import { T as Table } from "../../../chunks/table.js";
import { e as escape_html } from "../../../chunks/context.js";
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let sql = "SELECT u.name, o.order_date\nFROM users u\nJOIN orders o ON u.id = o.user_id\nWHERE o.status = 'completed'\nORDER BY o.order_date DESC;";
    let analysis = null;
    function analyzeSQL() {
      if (!sql.toLowerCase().includes("join")) {
        analysis = "💡 Tip: Consider using JOIN instead of subqueries for better performance in most DBs.";
      } else if (sql.toLowerCase().includes("*")) {
        analysis = "⚠️ Warning: Avoid using SELECT *. Specify column names to reduce I/O and network overhead.";
      } else if (!sql.toLowerCase().includes("limit") && sql.toLowerCase().includes("select")) {
        analysis = "ℹ️ Hint: Add a LIMIT clause to prevent large result sets from slowing down the application.";
      } else {
        analysis = "✅ Heuristic checks passed. Queries with JOINs should ensure indexed columns are used in ON clauses.";
      }
    }
    function extractTables() {
      const tableMatches = sql.matchAll(/FROM\s+(\w+)|JOIN\s+(\w+)/gi);
      return [...new Set([...tableMatches].map((m) => m[1] || m[2]))];
    }
    let tables = extractTables();
    head("1g26hot", $$renderer2, ($$renderer3) => {
      $$renderer3.title(($$renderer4) => {
        $$renderer4.push(`<title>SQL Architect - Aone Toolkit</title>`);
      });
    });
    $$renderer2.push(`<div class="h-[calc(100vh-3rem)] p-4 flex flex-col space-y-4"><div class="flex-1 grid grid-cols-1 lg:grid-cols-2 gap-4 min-h-0">`);
    {
      let header = function($$renderer3) {
        $$renderer3.push(`<div class="flex items-center justify-between w-full"><div class="flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 flex items-center justify-center border">`);
        Database($$renderer3, { size: 16 });
        $$renderer3.push(`<!----></div> <h2 class="font-semibold text-slate-900 dark:text-white">Query Editor</h2></div> `);
        Button($$renderer3, {
          size: "sm",
          onclick: analyzeSQL,
          children: ($$renderer4) => {
            Sparkles($$renderer4, { size: 14, class: "mr-2" });
            $$renderer4.push(`<!----> Analyze`);
          },
          $$slots: { default: true }
        });
        $$renderer3.push(`<!----></div>`);
      };
      Panel($$renderer2, {
        class: "flex flex-col min-h-0",
        header,
        children: ($$renderer3) => {
          $$renderer3.push(`<textarea class="flex-1 p-6 font-mono text-sm bg-transparent resize-none focus:outline-none dark:text-slate-300 leading-relaxed" spellcheck="false">`);
          const $$body = escape_html(sql);
          if ($$body) {
            $$renderer3.push(`${$$body}`);
          }
          $$renderer3.push(`</textarea>`);
        }
      });
    }
    $$renderer2.push(`<!----> `);
    {
      let header = function($$renderer3) {
        $$renderer3.push(`<div class="flex items-center justify-between w-full"><div class="flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 flex items-center justify-center border">`);
        Table($$renderer3, { size: 16 });
        $$renderer3.push(`<!----></div> <h2 class="font-semibold text-slate-900 dark:text-white">Analysis &amp; Schema</h2></div></div>`);
      };
      Panel($$renderer2, {
        class: "flex flex-col min-h-0",
        header,
        children: ($$renderer3) => {
          $$renderer3.push(`<div class="flex-1 overflow-y-auto p-6 space-y-8">`);
          if (analysis) {
            $$renderer3.push("<!--[-->");
            $$renderer3.push(`<section class="space-y-2"><div class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Optimized Advice</div> <div class="p-4 bg-indigo-50/50 dark:bg-indigo-900/10 border border-indigo-100 dark:border-indigo-900/20 rounded-2xl text-sm leading-relaxed text-indigo-700 dark:text-indigo-300">${escape_html(analysis)}</div></section>`);
          } else {
            $$renderer3.push("<!--[!-->");
          }
          $$renderer3.push(`<!--]--> <section class="space-y-4"><div class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Inferred Entities (${escape_html(tables.length)})</div> <div class="grid grid-cols-1 gap-2"><!--[-->`);
          const each_array = ensure_array_like(tables);
          for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
            let table = each_array[$$index];
            $$renderer3.push(`<div class="flex items-center gap-3 p-3 bg-white dark:bg-slate-800 rounded-xl border shadow-sm"><div class="w-2 h-2 rounded-full bg-emerald-500"></div> <span class="font-mono text-sm font-bold">${escape_html(table)}</span> <span class="text-[10px] text-slate-400 ml-auto">TABLE</span></div>`);
          }
          $$renderer3.push(`<!--]--></div></section> <section class="pt-6 border-t border-slate-100 dark:border-slate-800"><div class="p-4 bg-slate-900/5 dark:bg-black/20 rounded-2xl border-2 border-dashed border-slate-200 dark:border-slate-800 text-center"><p class="text-xs text-slate-400">AI Schema visualization coming soon...</p></div></section></div>`);
        }
      });
    }
    $$renderer2.push(`<!----></div></div>`);
  });
}
export {
  _page as default
};
