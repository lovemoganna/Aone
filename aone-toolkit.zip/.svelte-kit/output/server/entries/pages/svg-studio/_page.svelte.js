import { a7 as head, a0 as attr_class, a1 as stringify } from "../../../chunks/index2.js";
import { B as Button } from "../../../chunks/Button.js";
import { P as Panel } from "../../../chunks/Panel.js";
import { C as Copy } from "../../../chunks/copy.js";
import { D as Download } from "../../../chunks/download.js";
import { I as Image } from "../../../chunks/image.js";
import { T as Trash_2 } from "../../../chunks/trash-2.js";
import { C as Code_xml } from "../../../chunks/code-xml.js";
import { e as escape_html } from "../../../chunks/context.js";
import { h as html } from "../../../chunks/html.js";
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let svgCode = "";
    let optimizedCode = "";
    function optimizeSVG() {
      if (!svgCode) return;
      let optimized = svgCode.replace(/<!--[\s\S]*?-->/g, "").replace(/<\?xml[\s\S]*?\?>/g, "").replace(/<metadata[\s\S]*?<\/metadata>/g, "").replace(/>\s+</g, "><").trim();
      optimizedCode = optimized;
    }
    function toComponent() {
      if (!optimizedCode) optimizeSVG();
      const body = optimizedCode.replace(/<svg[^>]*>/, "").replace(/<\/svg>/, "");
      const viewbox = optimizedCode.match(/viewBox="([^"]*)"/)?.[1] || "0 0 24 24";
      {
        return [
          "<script>",
          "  export let size = 24;",
          '  export let color = "currentColor";',
          "<\/script>",
          "",
          '<svg width={size} height={size} viewBox="' + viewbox + '" fill={color} {...$$restProps}>',
          "  " + body,
          "</svg>"
        ].join("\n");
      }
    }
    function copyResult(text) {
      navigator.clipboard.writeText(text);
    }
    head("1c0qjxw", $$renderer2, ($$renderer3) => {
      $$renderer3.title(($$renderer4) => {
        $$renderer4.push(`<title>SVG Studio - Aone Toolkit</title>`);
      });
    });
    $$renderer2.push(`<div class="h-[calc(100vh-3rem)] p-4 flex flex-col space-y-4"><div class="flex-1 grid grid-cols-1 lg:grid-cols-2 gap-4 min-h-0">`);
    {
      let header = function($$renderer3) {
        $$renderer3.push(`<div class="flex items-center justify-between w-full"><div class="flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-orange-100 dark:bg-orange-900/30 text-orange-600 dark:text-orange-400 flex items-center justify-center">`);
        Image($$renderer3, { size: 16 });
        $$renderer3.push(`<!----></div> <h2 class="font-semibold text-slate-900 dark:text-white">SVG Input &amp; Preview</h2></div> `);
        Button($$renderer3, {
          variant: "ghost",
          size: "sm",
          onclick: () => svgCode = "",
          children: ($$renderer4) => {
            Trash_2($$renderer4, { size: 14 });
          },
          $$slots: { default: true }
        });
        $$renderer3.push(`<!----></div>`);
      };
      Panel($$renderer2, {
        class: "flex flex-col min-h-0",
        header,
        children: ($$renderer3) => {
          $$renderer3.push(`<div class="flex-1 flex flex-col min-h-0"><textarea class="h-1/2 p-6 font-mono text-xs bg-transparent border-b border-slate-100 dark:border-slate-800 resize-none focus:outline-none dark:text-slate-400" placeholder="Paste SVG code here...">`);
          const $$body = escape_html(svgCode);
          if ($$body) {
            $$renderer3.push(`${$$body}`);
          }
          $$renderer3.push(`</textarea> <div class="flex-1 flex items-center justify-center bg-slate-50/50 dark:bg-black/20 p-8">`);
          if (svgCode) {
            $$renderer3.push("<!--[-->");
            $$renderer3.push(`<div class="scale-150 transform">${html(svgCode)}</div>`);
          } else {
            $$renderer3.push("<!--[!-->");
            $$renderer3.push(`<div class="text-slate-400 text-sm italic">Live preview will appear here</div>`);
          }
          $$renderer3.push(`<!--]--></div></div>`);
        }
      });
    }
    $$renderer2.push(`<!----> `);
    {
      let header = function($$renderer3) {
        $$renderer3.push(`<div class="flex items-center justify-between w-full"><div class="flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 flex items-center justify-center">`);
        Code_xml($$renderer3, { size: 16 });
        $$renderer3.push(`<!----></div> <h2 class="font-semibold text-slate-900 dark:text-white">Assets Studio</h2></div></div>`);
      };
      Panel($$renderer2, {
        class: "flex flex-col min-h-0",
        header,
        children: ($$renderer3) => {
          $$renderer3.push(`<div class="flex-1 overflow-y-auto p-6 space-y-8"><section class="space-y-3"><div class="text-xs font-bold text-slate-400 uppercase tracking-wider">Optimized Source</div> <div class="relative group"><textarea readonly class="w-full h-32 p-4 font-mono text-xs bg-slate-100 dark:bg-slate-900 border rounded-xl resize-none outline-none">`);
          const $$body_1 = escape_html(optimizedCode);
          if ($$body_1) {
            $$renderer3.push(`${$$body_1}`);
          }
          $$renderer3.push(`</textarea> <button class="absolute top-2 right-2 p-1.5 bg-white dark:bg-slate-800 border rounded-lg opacity-0 group-hover:opacity-100 transition-opacity shadow-sm">`);
          Copy($$renderer3, { size: 14 });
          $$renderer3.push(`<!----></button></div></section> <section class="space-y-4"><div class="flex items-center justify-between"><div class="text-xs font-bold text-slate-400 uppercase tracking-wider">Component Template</div> <div class="flex p-1 bg-slate-100 dark:bg-slate-800 rounded-lg"><button${attr_class(`px-3 py-1 text-xs font-medium rounded-md transition-all ${stringify(
            "bg-white dark:bg-slate-700 shadow-sm text-primary-600"
          )}`)}>Svelte</button> <button${attr_class(`px-3 py-1 text-xs font-medium rounded-md transition-all ${stringify("text-slate-500")}`)}>React</button></div></div> <div class="relative group"><textarea readonly class="w-full h-48 p-4 font-mono text-xs bg-slate-100 dark:bg-slate-900 border rounded-xl resize-none outline-none">`);
          const $$body_2 = escape_html(toComponent());
          if ($$body_2) {
            $$renderer3.push(`${$$body_2}`);
          }
          $$renderer3.push(`</textarea> <button class="absolute top-2 right-2 p-1.5 bg-white dark:bg-slate-800 border rounded-lg opacity-0 group-hover:opacity-100 transition-opacity shadow-sm">`);
          Copy($$renderer3, { size: 14 });
          $$renderer3.push(`<!----></button></div></section></div> <div class="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-black/10 flex justify-end">`);
          Button($$renderer3, {
            variant: "secondary",
            onclick: () => copyResult(optimizedCode),
            children: ($$renderer4) => {
              Download($$renderer4, { size: 14, class: "mr-2" });
              $$renderer4.push(`<!----> Download SVG`);
            },
            $$slots: { default: true }
          });
          $$renderer3.push(`<!----></div>`);
        }
      });
    }
    $$renderer2.push(`<!----></div></div>`);
  });
}
export {
  _page as default
};
