import { a0 as attr_class, a1 as stringify, a4 as ensure_array_like, a3 as attr } from "../../../chunks/index2.js";
import { e as escape_html } from "../../../chunks/context.js";
import "clsx";
import { B as Button } from "../../../chunks/Button.js";
import { g as getTableStats, b as toCSV, d as toOrgMode, e as toHTML, t as toMarkdown } from "../../../chunks/converters.js";
import * as XLSX from "xlsx";
function toExcelBlob(data, sheetName = "Sheet1") {
  const workbook = XLSX.utils.book_new();
  const worksheet = XLSX.utils.aoa_to_sheet(data);
  XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);
  const buffer = XLSX.write(workbook, {
    bookType: "xlsx",
    type: "array"
  });
  return new Blob([buffer], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
  });
}
function FileDropZone($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    $$renderer2.push(`<div${attr_class(`file-drop-zone ${stringify("")}`, "svelte-1mtetpt")} role="button" tabindex="0" aria-label="点击或拖拽文件到此处上传"><svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="icon svelte-1mtetpt"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="17 8 12 3 7 8"></polyline><line x1="12" x2="12" y1="3" y2="15"></line></svg> <p class="primary svelte-1mtetpt"><strong>点击选择文件</strong> (支持批量) 或拖拽到此处</p> <p class="secondary svelte-1mtetpt">支持 Excel、HTML、CSV、Markdown、TXT</p></div> <input type="file" id="table-file-input" accept=".html,.htm,.txt,.csv,.md,.markdown,.xlsx,.xls" multiple aria-label="选择要上传的文件" style="display: none;"/>`);
  });
}
function TextInputPane($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      value,
      inputFormat,
      isProcessing,
      onParse,
      onFormatChange
    } = $$props;
    function handleFormatChange(e) {
      const select = e.target;
      onFormatChange(select.value);
    }
    $$renderer2.push(`<div class="pane svelte-pzgcap"><div class="form-group svelte-pzgcap"><label for="inputFormat" class="form-label svelte-pzgcap">输入格式</label> `);
    $$renderer2.select(
      {
        id: "inputFormat",
        value: inputFormat,
        onchange: handleFormatChange,
        "aria-label": "选择输入格式",
        class: ""
      },
      ($$renderer3) => {
        $$renderer3.option({ value: "auto" }, ($$renderer4) => {
          $$renderer4.push(`🔍 自动检测`);
        });
        $$renderer3.option({ value: "html" }, ($$renderer4) => {
          $$renderer4.push(`🌐 HTML表格`);
        });
        $$renderer3.option({ value: "markdown" }, ($$renderer4) => {
          $$renderer4.push(`📋 Markdown表格`);
        });
        $$renderer3.option({ value: "csv" }, ($$renderer4) => {
          $$renderer4.push(`📊 CSV数据`);
        });
        $$renderer3.option({ value: "text" }, ($$renderer4) => {
          $$renderer4.push(`📄 纯文本`);
        });
      },
      "svelte-pzgcap"
    );
    $$renderer2.push(`</div> <div class="form-group svelte-pzgcap"><label for="tableInput" class="form-label svelte-pzgcap">表格数据</label> <textarea id="tableInput" placeholder="粘贴您的表格数据... 支持HTML、Markdown、CSV等格式" rows="8" aria-describedby="input-help" class="svelte-pzgcap">`);
    const $$body = escape_html(value);
    if ($$body) {
      $$renderer2.push(`${$$body}`);
    }
    $$renderer2.push(`</textarea> <div id="input-help" class="help-text svelte-pzgcap">💡 提示：按 Ctrl+V 粘贴，Ctrl+Enter 解析</div></div> `);
    Button($$renderer2, {
      variant: "primary",
      size: "md",
      onclick: onParse,
      disabled: isProcessing || !value.trim(),
      class: "parse-btn",
      children: ($$renderer3) => {
        if (isProcessing) {
          $$renderer3.push("<!--[-->");
          $$renderer3.push(`<svg class="spinner svelte-pzgcap" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 11-6.219-8.56"></path></svg> 解析中...`);
        } else {
          $$renderer3.push("<!--[!-->");
          $$renderer3.push(`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg> 解析表格`);
        }
        $$renderer3.push(`<!--]-->`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----></div>`);
  });
}
function TablePreview($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { data, onFullscreen } = $$props;
    let stats = getTableStats(data);
    let editingCell = null;
    let editValue = "";
    let sortColumn = null;
    $$renderer2.push(`<div class="preview-container svelte-156fvhu"><div class="toolbar svelte-156fvhu"><h3 class="title svelte-156fvhu">✏️ 表格编辑</h3> <div class="toolbar-group svelte-156fvhu"><span class="stats svelte-156fvhu">${escape_html(stats.rows)} 行 × ${escape_html(stats.cols)} 列 (${escape_html(stats.cells)} 单元格)</span> <span class="hint svelte-156fvhu">双击编辑 · 右键菜单</span> `);
    Button($$renderer2, {
      variant: "ghost",
      size: "sm",
      onclick: onFullscreen,
      title: "全屏预览 (F11)",
      children: ($$renderer3) => {
        $$renderer3.push(`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 3H5a2 2 0 0 0-2 2v3"></path><path d="M21 8V5a2 2 0 0 0-2-2h-3"></path><path d="M3 16v3a2 2 0 0 0 2 2h3"></path><path d="M16 21h3a2 2 0 0 0 2-2v-3"></path></svg> 全屏`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----></div></div> <div class="table-container svelte-156fvhu" role="table" aria-label="可编辑表格"><table class="svelte-156fvhu"><thead><tr><!--[-->`);
    const each_array = ensure_array_like(data[0] || []);
    for (let colIndex = 0, $$length = each_array.length; colIndex < $$length; colIndex++) {
      let cell = each_array[colIndex];
      $$renderer2.push(`<th class="svelte-156fvhu">`);
      {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push(`<div class="th-content svelte-156fvhu"><span>${escape_html(cell)}</span> <button class="sort-btn svelte-156fvhu" title="点击排序">`);
        if (sortColumn === colIndex) {
          $$renderer2.push("<!--[-->");
          {
            $$renderer2.push("<!--[-->");
            $$renderer2.push(`<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m18 15-6-6-6 6"></path></svg>`);
          }
          $$renderer2.push(`<!--]-->`);
        } else {
          $$renderer2.push("<!--[!-->");
          $$renderer2.push(`<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" opacity="0.4"><path d="m6 9 6 6 6-6"></path></svg>`);
        }
        $$renderer2.push(`<!--]--></button></div>`);
      }
      $$renderer2.push(`<!--]--></th>`);
    }
    $$renderer2.push(`<!--]--></tr></thead><tbody><!--[-->`);
    const each_array_1 = ensure_array_like(data.slice(1));
    for (let rowOffset = 0, $$length = each_array_1.length; rowOffset < $$length; rowOffset++) {
      let row = each_array_1[rowOffset];
      const rowIndex = rowOffset + 1;
      $$renderer2.push(`<tr class="svelte-156fvhu"><!--[-->`);
      const each_array_2 = ensure_array_like(row);
      for (let colIndex = 0, $$length2 = each_array_2.length; colIndex < $$length2; colIndex++) {
        let cell = each_array_2[colIndex];
        $$renderer2.push(`<td class="svelte-156fvhu">`);
        if (editingCell?.row === rowIndex && editingCell?.col === colIndex) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<input type="text" class="cell-input svelte-156fvhu"${attr("value", editValue)} autofocus/>`);
        } else {
          $$renderer2.push("<!--[!-->");
          $$renderer2.push(`${escape_html(cell)}`);
        }
        $$renderer2.push(`<!--]--></td>`);
      }
      $$renderer2.push(`<!--]--></tr>`);
    }
    $$renderer2.push(`<!--]--></tbody></table></div></div> `);
    {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
  });
}
function FormatConverter($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { disabled, activeFormat, onConvert } = $$props;
    const formats = [
      { id: "markdown", label: "Markdown", icon: "M" },
      { id: "csv", label: "CSV", icon: "," },
      { id: "excel", label: "Excel", icon: "X" },
      { id: "html", label: "HTML", icon: "<>" },
      { id: "orgmode", label: "Org Mode", icon: "◉" },
      { id: "sql-mysql", label: "MySQL", icon: "🐬" },
      { id: "sql-pg", label: "PostgreSQL", icon: "🐘" },
      { id: "sql-duckdb", label: "DuckDB", icon: "🦆" }
    ];
    $$renderer2.push(`<div class="converter-container svelte-1l3w6wb"><h3 class="title svelte-1l3w6wb">🔄 格式转换</h3> <div class="button-grid svelte-1l3w6wb"><!--[-->`);
    const each_array = ensure_array_like(formats);
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      let format = each_array[$$index];
      Button($$renderer2, {
        variant: activeFormat === format.id ? "primary" : "secondary",
        size: "md",
        disabled,
        onclick: () => onConvert(format.id),
        class: "format-btn",
        children: ($$renderer3) => {
          $$renderer3.push(`<span class="icon svelte-1l3w6wb">${escape_html(format.icon)}</span> ${escape_html(format.label)}`);
        },
        $$slots: { default: true }
      });
    }
    $$renderer2.push(`<!--]--></div></div>`);
  });
}
const FORMAT_CONFIG = {
  markdown: { ext: ".md", mime: "text/markdown", label: "Markdown" },
  csv: { ext: ".csv", mime: "text/csv", label: "CSV" },
  excel: { ext: ".xlsx", mime: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", label: "Excel" },
  html: { ext: ".html", mime: "text/html", label: "HTML" },
  orgmode: { ext: ".org", mime: "text/plain", label: "Org Mode" },
  "sql-mysql": { ext: ".sql", mime: "application/x-sql", label: "MySQL" },
  "sql-pg": { ext: ".sql", mime: "application/x-sql", label: "PostgreSQL" },
  "sql-duckdb": { ext: ".sql", mime: "application/x-sql", label: "DuckDB" }
};
function OutputPane($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { content, format, onCopy, onDownload } = $$props;
    let charCount = content.length;
    let lineCount = content.split("\n").length;
    let formatLabel = format ? FORMAT_CONFIG[format].label : "";
    $$renderer2.push(`<div class="output-container svelte-n72x1z"><div class="toolbar svelte-n72x1z"><h3 class="title svelte-n72x1z">📤 转换结果</h3> <div class="toolbar-group svelte-n72x1z"><span class="stats svelte-n72x1z">${escape_html(formatLabel)} · ${escape_html(lineCount)} 行 · ${escape_html(charCount)} 字符</span> `);
    Button($$renderer2, {
      variant: "ghost",
      size: "sm",
      onclick: onCopy,
      title: "复制到剪贴板",
      children: ($$renderer3) => {
        $$renderer3.push(`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"></rect><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"></path></svg> 复制`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> `);
    Button($$renderer2, {
      variant: "primary",
      size: "sm",
      onclick: onDownload,
      title: "下载文件",
      children: ($$renderer3) => {
        $$renderer3.push(`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" x2="12" y1="15" y2="3"></line></svg> 下载`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----></div></div> <div class="output-wrapper svelte-n72x1z"><pre class="output-pre svelte-n72x1z" aria-label="转换后的结果">${escape_html(content)}</pre></div></div>`);
  });
}
function FullscreenPreview($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { open, data, onClose } = $$props;
    if (open) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="fullscreen-overlay svelte-1gfabe1" role="dialog" aria-modal="true" aria-labelledby="fullscreen-title" tabindex="-1"><div class="fullscreen-header svelte-1gfabe1"><h2 id="fullscreen-title" class="svelte-1gfabe1">📊 全屏表格预览</h2> `);
      Button($$renderer2, {
        variant: "ghost",
        size: "sm",
        onclick: onClose,
        title: "关闭全屏 (Esc)",
        children: ($$renderer3) => {
          $$renderer3.push(`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" x2="6" y1="6" y2="18"></line><line x1="6" x2="18" y1="6" y2="18"></line></svg> 关闭`);
        },
        $$slots: { default: true }
      });
      $$renderer2.push(`<!----></div> <div class="fullscreen-content svelte-1gfabe1"><div class="fullscreen-table-container svelte-1gfabe1" role="table" aria-label="全屏表格预览"><table class="svelte-1gfabe1">`);
      if (data.length > 0) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<thead><tr><!--[-->`);
        const each_array = ensure_array_like(data[0]);
        for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
          let cell = each_array[$$index];
          $$renderer2.push(`<th class="svelte-1gfabe1">${escape_html(cell)}</th>`);
        }
        $$renderer2.push(`<!--]--></tr></thead> <tbody><!--[-->`);
        const each_array_1 = ensure_array_like(data.slice(1));
        for (let $$index_2 = 0, $$length = each_array_1.length; $$index_2 < $$length; $$index_2++) {
          let row = each_array_1[$$index_2];
          $$renderer2.push(`<tr class="svelte-1gfabe1"><!--[-->`);
          const each_array_2 = ensure_array_like(row);
          for (let $$index_1 = 0, $$length2 = each_array_2.length; $$index_1 < $$length2; $$index_1++) {
            let cell = each_array_2[$$index_1];
            $$renderer2.push(`<td class="svelte-1gfabe1">${escape_html(cell)}</td>`);
          }
          $$renderer2.push(`<!--]--></tr>`);
        }
        $$renderer2.push(`<!--]--></tbody>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></table></div></div></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
  });
}
function autoDetectAndParse(content) {
  if (isHTMLTable(content)) {
    return { data: parseHTMLTable(content), detectedFormat: "html" };
  }
  if (isSQLCreateTable(content)) {
    return { data: parseSQLCreateTable(content), detectedFormat: "csv", detectedType: "sql-import" };
  }
  if (isMarkdownTable(content)) {
    return { data: parseMarkdownTable(content), detectedFormat: "markdown" };
  }
  if (isCSVData(content)) {
    return { data: parseCSVData(content), detectedFormat: "csv" };
  }
  return { data: parseTextTable(content), detectedFormat: "text" };
}
function parseByFormat(content, format) {
  const parsers = {
    html: () => parseHTMLTable(content),
    markdown: () => parseMarkdownTable(content),
    csv: () => parseCSVData(content),
    text: () => parseTextTable(content)
  };
  if (format === "auto") {
    return autoDetectAndParse(content).data;
  }
  const parser = parsers[format];
  if (!parser) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return parser();
}
function isHTMLTable(content) {
  return /<table[^>]*>[\s\S]*<\/table>/i.test(content) || /<tr[^>]*>[\s\S]*<\/tr>/i.test(content);
}
function isMarkdownTable(content) {
  const lines = content.trim().split("\n");
  if (lines.length < 2) return false;
  const hasSeparator = lines.some((line) => /^\|?[\s\-:]+\|[\s\-:|]+\|?$/.test(line.trim()));
  const hasPipes = lines.some((line) => line.includes("|"));
  return hasSeparator && hasPipes;
}
function isCSVData(content) {
  const lines = content.trim().split("\n");
  if (lines.length < 2) return false;
  const firstLineCommas = (lines[0].match(/,/g) || []).length;
  const secondLineCommas = (lines[1].match(/,/g) || []).length;
  return firstLineCommas > 0 && firstLineCommas === secondLineCommas;
}
function parseHTMLTable(content) {
  const parser = new DOMParser();
  const doc = parser.parseFromString(content, "text/html");
  const tables = doc.querySelectorAll("table");
  if (tables.length === 0) {
    const rows = doc.querySelectorAll("tr");
    if (rows.length === 0) {
      throw new Error("未找到有效的HTML表格");
    }
    return extractRowsData(rows);
  }
  return extractTableData(tables[0]);
}
function extractTableData(table) {
  const rows = [];
  const tableRows = table.querySelectorAll("tr");
  tableRows.forEach((tr) => {
    const cells = [];
    const tableCells = tr.querySelectorAll("td, th");
    tableCells.forEach((cell) => {
      const colspan = parseInt(cell.getAttribute("colspan") || "1");
      const cellText = cell.textContent?.trim() || "";
      for (let i = 0; i < colspan; i++) {
        cells.push(i === 0 ? cellText : "");
      }
    });
    if (cells.length > 0) {
      rows.push(cells);
    }
  });
  return rows;
}
function extractRowsData(rows) {
  const tableData = [];
  rows.forEach((tr) => {
    const cells = [];
    const tableCells = tr.querySelectorAll("td, th");
    tableCells.forEach((cell) => {
      cells.push(cell.textContent?.trim() || "");
    });
    if (cells.length > 0) {
      tableData.push(cells);
    }
  });
  return tableData;
}
function parseMarkdownTable(content) {
  const lines = content.trim().split("\n").filter((line) => line.trim());
  const tableData = [];
  for (const line of lines) {
    if (/^[\s\-:|\+]+$/.test(line.replace(/\|/g, ""))) {
      continue;
    }
    const cells = line.split("|").map((cell) => cell.trim()).filter((_, index, arr) => {
      if (index === 0 && arr[0] === "") return false;
      if (index === arr.length - 1 && arr[arr.length - 1] === "") return false;
      return true;
    });
    if (cells.length > 0) {
      tableData.push(cells);
    }
  }
  return tableData;
}
function parseCSVData(content) {
  const lines = content.trim().split("\n");
  const tableData = [];
  const commaCount = (lines[0].match(/,/g) || []).length;
  const semicolonCount = (lines[0].match(/;/g) || []).length;
  const delimiter = semicolonCount > commaCount ? ";" : ",";
  for (const line of lines) {
    const cells = parseCSVLine(line, delimiter);
    if (cells.length > 0) {
      tableData.push(cells);
    }
  }
  return tableData;
}
function parseCSVLine(line, delimiter) {
  const cells = [];
  let current = "";
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    if (char === '"') {
      if (inQuotes && line[i + 1] === '"') {
        current += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === delimiter && !inQuotes) {
      cells.push(current.trim());
      current = "";
    } else {
      current += char;
    }
  }
  cells.push(current.trim());
  return cells;
}
function parseTextTable(content) {
  const lines = content.trim().split("\n");
  const tableData = [];
  for (const line of lines) {
    if (!line.trim()) continue;
    let cells = line.split("	").map((c) => c.trim());
    if (cells.length === 1) {
      cells = line.split(/\s{2,}/).map((c) => c.trim());
    }
    if (cells.length === 1 && cells[0]) {
      cells = [cells[0]];
    }
    if (cells.length > 0 && cells.some((c) => c)) {
      tableData.push(cells.filter((c) => c));
    }
  }
  return tableData;
}
function isSQLCreateTable(content) {
  return /CREATE\s+TABLE/i.test(content) && /\(/i.test(content) && /\)/i.test(content);
}
function parseSQLCreateTable(content) {
  const cleanContent = content.replace(/--.*$/gm, "").replace(/\/\*[\s\S]*?\*\//g, "").replace(/\s+/g, " ").trim();
  const match = cleanContent.match(/CREATE\s+TABLE\s+(?:["`]?\w+["`]?\.?)?(?:["`]?\w+["`]?)\s*\((.*)\)/i);
  if (!match) {
    throw new Error("Invalid CREATE TABLE syntax");
  }
  const columnBlock = match[1];
  const columns = [];
  let current = "";
  let parenDepth = 0;
  for (const char of columnBlock) {
    if (char === "(") parenDepth++;
    if (char === ")") parenDepth--;
    if (char === "," && parenDepth === 0) {
      columns.push(current.trim());
      current = "";
    } else {
      current += char;
    }
  }
  if (current.trim()) columns.push(current.trim());
  const tableData = [
    ["Field", "Type", "Length", "PK", "NotNull", "Comment"]
  ];
  const pkColumns = /* @__PURE__ */ new Set();
  for (const colDef of columns) {
    if (/PRIMARY\s+KEY/i.test(colDef)) {
      const pkMatch = colDef.match(/PRIMARY\s+KEY\s*\(([^)]+)\)/i);
      if (pkMatch) {
        pkMatch[1].split(",").forEach((c) => pkColumns.add(c.trim().replace(/["`]/g, "")));
      }
      continue;
    }
    if (/KEY|INDEX|CONSTRAINT|FOREIGN/i.test(colDef.split(" ")[0])) {
      continue;
    }
    const parts = colDef.split(/\s+/);
    const name = parts[0].replace(/["`]/g, "");
    let typeRaw = parts[1] || "VARCHAR";
    let length = "";
    const typeMatch = typeRaw.match(/(\w+)\((.+)\)/);
    if (typeMatch) {
      typeRaw = typeMatch[1];
      length = typeMatch[2];
    }
    const isNotNull = /NOT\s+NULL/i.test(colDef) ? "Y" : "";
    const isPK = /PRIMARY\s+KEY/i.test(colDef) ? "Y" : "";
    let comment = "";
    const commentMatch = colDef.match(/COMMENT\s+'([^']+)'/i);
    if (commentMatch) {
      comment = commentMatch[1];
    }
    if (isPK === "Y") pkColumns.add(name);
    tableData.push([
      name,
      typeRaw.toUpperCase(),
      length,
      isPK,
      // This will be updated later with set check
      isNotNull,
      comment
    ]);
  }
  for (let i = 1; i < tableData.length; i++) {
    const name = tableData[i][0];
    if (pkColumns.has(name)) {
      tableData[i][3] = "Y";
    }
  }
  return tableData;
}
function generateSQL(data, dialect, tableName = "new_table") {
  if (data.length <= 1) return `-- No data to generate SQL`;
  const rows = data.slice(1).filter((row) => row.some((cell) => cell.trim() !== ""));
  if (rows.length === 0) return `-- No columns defined`;
  const columns = rows.map((row) => parseRowToColumn(row));
  return buildCreateTable(tableName, columns, dialect);
}
function parseRowToColumn(row) {
  const name = row[0]?.trim() || "unnamed_col";
  const type = row[1]?.trim() || "VARCHAR";
  const length = row[2]?.trim();
  const pkRaw = row[3]?.trim().toLowerCase();
  const notNullRaw = row[4]?.trim().toLowerCase();
  const comment = row[5]?.trim();
  return {
    name,
    type,
    length,
    primaryKey: ["y", "yes", "true", "1", "ok", "pk"].includes(pkRaw || ""),
    notNull: ["y", "yes", "true", "1", "ok"].includes(notNullRaw || ""),
    comment
  };
}
function buildCreateTable(tableName, columns, dialect) {
  const lines = [];
  lines.push(`CREATE TABLE ${escapeId(tableName, dialect)} (`);
  const pkColumns = [];
  const colDefs = columns.map((col, index) => {
    let line = `  ${escapeId(col.name, dialect)} ${mapType(col.type, dialect, col.length)}`;
    if (col.notNull) {
      line += " NOT NULL";
    }
    if (dialect === "mysql" && col.comment) {
      line += ` COMMENT '${escapeString(col.comment)}'`;
    }
    if (col.primaryKey) {
      pkColumns.push(col.name);
    }
    return line;
  }).join(",\n");
  lines.push(colDefs);
  if (pkColumns.length > 0) {
    lines.push(`  ,PRIMARY KEY (${pkColumns.map((c) => escapeId(c, dialect)).join(", ")})`);
  }
  lines.push(`);`);
  if ((dialect === "postgresql" || dialect === "duckdb") && columns.some((c) => c.comment)) {
    lines.push("");
    columns.forEach((col) => {
      if (col.comment) {
        lines.push(`COMMENT ON COLUMN ${escapeId(tableName, dialect)}.${escapeId(col.name, dialect)} IS '${escapeString(col.comment)}';`);
      }
    });
  }
  return lines.join("\n");
}
function escapeId(id, dialect) {
  if (dialect === "mysql") return `\`${id}\``;
  return `"${id}"`;
}
function escapeString(str) {
  return str.replace(/'/g, "''");
}
function mapType(type, dialect, length) {
  const t = type.toLowerCase();
  if (t.includes("bigint")) return "BIGINT";
  if (t.includes("int")) return dialect === "duckdb" ? "INTEGER" : "INT";
  if (t.includes("double") || t.includes("float")) return "DOUBLE";
  if (t.includes("bool")) return "BOOLEAN";
  if (t === "string" || t === "text") return dialect === "mysql" ? "TEXT" : "TEXT";
  if (t === "varchar" || t === "char") {
    return `${t.toUpperCase()}(${length || "255"})`;
  }
  if (dialect === "postgresql" || dialect === "duckdb") {
    if (t === "datetime") return "TIMESTAMP";
    if (t === "blob") return "BYTEA";
  }
  return type.toUpperCase();
}
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let inputValue = "";
    let inputFormat = "auto";
    let tableData = [];
    let currentOutput = "";
    let currentFormat = null;
    let isProcessing = false;
    let fullscreenOpen = false;
    let shortcutsOpen = false;
    let tableName = "abnormal_spot_events";
    let history = [];
    let historyIndex = -1;
    let status = { text: "就绪", type: "success" };
    let hasTable = tableData.length > 0;
    let hasOutput = currentOutput.length > 0;
    let canUndo = historyIndex > 0;
    let canRedo = historyIndex < history.length - 1;
    function handleParse() {
      if (!inputValue.trim()) {
        updateStatus("请输入表格数据或上传文件", "error");
        return;
      }
      isProcessing = true;
      updateStatus("解析中...", "warning");
      try {
        saveHistory();
        let result;
        if (inputFormat === "auto") {
          const parseResult = autoDetectAndParse(inputValue);
          result = parseResult.data;
        } else {
          result = parseByFormat(inputValue, inputFormat);
        }
        if (result.length === 0) {
          throw new Error("未能解析出有效的表格数据");
        }
        tableData = result;
        currentOutput = "";
        currentFormat = null;
        updateStatus("解析成功", "success");
      } catch (e) {
        updateStatus(`解析失败: ${e instanceof Error ? e.message : "未知错误"}`, "error");
      } finally {
        isProcessing = false;
      }
    }
    function handleConvert(format) {
      if (tableData.length === 0) return;
      try {
        let output = "";
        switch (format) {
          case "markdown":
            output = toMarkdown(tableData);
            break;
          case "csv":
            output = toCSV(tableData);
            break;
          case "html":
            output = toHTML(tableData);
            break;
          case "orgmode":
            output = toOrgMode(tableData);
            break;
          case "excel":
            handleDownloadExcel();
            return;
          case "sql-mysql":
            output = generateSQL(tableData, "mysql", tableName);
            break;
          case "sql-pg":
            output = generateSQL(tableData, "postgresql", tableName);
            break;
          case "sql-duckdb":
            output = generateSQL(tableData, "duckdb", tableName);
            break;
        }
        currentOutput = output;
        currentFormat = format;
        updateStatus(`已转换为 ${FORMAT_CONFIG[format].label}`, "success");
      } catch (e) {
        updateStatus(`转换失败: ${e instanceof Error ? e.message : "未知错误"}`, "error");
      }
    }
    function handleCopy() {
      if (!currentOutput) return;
      navigator.clipboard.writeText(currentOutput).then(() => {
        updateStatus("已复制到剪贴板", "success");
      }).catch(() => {
        updateStatus("复制失败", "error");
      });
    }
    function handleDownload() {
      if (!currentOutput || !currentFormat) return;
      const config = FORMAT_CONFIG[currentFormat];
      const blob = new Blob([currentOutput], { type: config.mime });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `table${config.ext}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      updateStatus(`已下载 table${config.ext}`, "success");
    }
    function handleDownloadExcel() {
      try {
        const blob = toExcelBlob(tableData);
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "table.xlsx";
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        currentFormat = "excel";
        updateStatus("已下载 table.xlsx", "success");
      } catch (e) {
        updateStatus(`Excel导出失败: ${e instanceof Error ? e.message : "未知错误"}`, "error");
      }
    }
    function saveHistory() {
      history = [
        ...history.slice(0, historyIndex + 1),
        { input: inputValue, data: [...tableData] }
      ];
      historyIndex = history.length - 1;
    }
    function handleUndo() {
      if (historyIndex > 0) {
        historyIndex--;
        const prev = history[historyIndex];
        inputValue = prev.input;
        tableData = prev.data;
        currentOutput = "";
        currentFormat = null;
        updateStatus("已撤销", "success");
      }
    }
    function handleRedo() {
      if (historyIndex < history.length - 1) {
        historyIndex++;
        const next = history[historyIndex];
        inputValue = next.input;
        tableData = next.data;
        currentOutput = "";
        currentFormat = null;
        updateStatus("已重做", "success");
      }
    }
    function handleDBTemplate() {
      saveHistory();
      tableData = [
        ["Field", "Type", "Length", "PK", "NotNull", "Comment"],
        ["event_id", "BIGINT", "", "Y", "Y", "Primary Event ID"],
        ["symbol", "VARCHAR", "32", "", "Y", "Trading Symbol"],
        ["created_at", "DATETIME", "", "", "Y", "Creation Time"]
      ];
      inputValue = toCSV(tableData);
      inputFormat = "csv";
      tableName = "abnormal_spot_events";
      updateStatus("已应用数据库设计模板 (v2)", "success");
    }
    function handleDeduplicate() {
      if (tableData.length <= 1) return;
      saveHistory();
      const header = tableData[0];
      const body = tableData.slice(1);
      const seen = /* @__PURE__ */ new Set();
      const uniqueBody = [];
      for (const row of body) {
        const rowStr = JSON.stringify(row);
        if (!seen.has(rowStr)) {
          seen.add(rowStr);
          uniqueBody.push(row);
        }
      }
      const removed = body.length - uniqueBody.length;
      if (removed > 0) {
        tableData = [header, ...uniqueBody];
        currentOutput = "";
        inputValue = toCSV(tableData);
        inputFormat = "csv";
        updateStatus(`已移除 ${removed} 行重复数据`, "success");
      } else {
        updateStatus("未发现重复数据", "success");
      }
    }
    function updateStatus(text, type) {
      status = { text, type };
    }
    $$renderer2.push(`<div class="container svelte-1tbjm83"><header class="header svelte-1tbjm83"><h1 class="svelte-1tbjm83">全能表格转换器</h1> <p class="subtitle svelte-1tbjm83">专业级表格格式转换工具 - 支持 HTML、Markdown、CSV、Excel</p></header> <div class="toolbar svelte-1tbjm83"><div${attr_class(`status-indicator status-${stringify(status.type)}`, "svelte-1tbjm83")}>${escape_html(status.text)}</div> <div class="toolbar-group svelte-1tbjm83">`);
    Button($$renderer2, {
      variant: "ghost",
      size: "sm",
      onclick: () => shortcutsOpen = true,
      title: "快捷键帮助 (?)",
      children: ($$renderer3) => {
        $$renderer3.push(`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path><line x1="12" x2="12.01" y1="17" y2="17"></line></svg> 帮助`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> `);
    Button($$renderer2, {
      variant: "ghost",
      size: "sm",
      onclick: handleUndo,
      disabled: !canUndo,
      title: "撤销 (Ctrl+Z)",
      children: ($$renderer3) => {
        $$renderer3.push(`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 7v6h6"></path><path d="M21 17a9 9 0 0 0-9-9 9 9 0 0 0-6 2.3L3 13"></path></svg> 撤销`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> `);
    Button($$renderer2, {
      variant: "ghost",
      size: "sm",
      onclick: handleRedo,
      disabled: !canRedo,
      title: "重做 (Ctrl+Y)",
      children: ($$renderer3) => {
        $$renderer3.push(`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 7v6h-6"></path><path d="M3 17a9 9 0 0 1 9-9 9 9 0 0 1 6 2.3L21 13"></path></svg> 重做`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> <div class="separator svelte-1tbjm83"></div> `);
    Button($$renderer2, {
      variant: "ghost",
      size: "sm",
      onclick: handleDeduplicate,
      disabled: !hasTable,
      title: "移除重复行",
      children: ($$renderer3) => {
        $$renderer3.push(`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18"></path><path d="M19 6v14c0 1.1-.9 2-2 2H7c-1.1 0-2-.9-2-2V6"></path><path d="M8 6V4c0-1.1.9-2 2-2h4c1.1 0 2 .9 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg> 去重`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> `);
    Button($$renderer2, {
      variant: "ghost",
      size: "sm",
      onclick: handleDBTemplate,
      title: "新建数据库设计模板",
      children: ($$renderer3) => {
        $$renderer3.push(`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 6h16"></path><path d="M4 12h16"></path><path d="M4 18h16"></path><circle cx="2" cy="6" r="1" fill="currentColor"></circle><circle cx="2" cy="12" r="1" fill="currentColor"></circle><circle cx="2" cy="18" r="1" fill="currentColor"></circle></svg> DB设计`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> <div class="separator svelte-1tbjm83"></div></div></div> <div class="grid-2 svelte-1tbjm83"><div class="card svelte-1tbjm83"><h2 class="svelte-1tbjm83">📁 文件输入</h2> `);
    FileDropZone($$renderer2);
    $$renderer2.push(`<!----></div> <div class="card svelte-1tbjm83"><h2 class="svelte-1tbjm83">📝 文本输入</h2> `);
    TextInputPane($$renderer2, {
      value: inputValue,
      inputFormat,
      isProcessing,
      onParse: handleParse,
      onFormatChange: (f) => inputFormat = f
    });
    $$renderer2.push(`<!----></div></div> `);
    if (hasTable) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="card svelte-1tbjm83">`);
      TablePreview($$renderer2, {
        data: tableData,
        onFullscreen: () => fullscreenOpen = true
      });
      $$renderer2.push(`<!----></div> <div class="card svelte-1tbjm83"><div style="margin-bottom: 1rem; display: flex; align-items: center; gap: 0.5rem;"><label for="tableName" style="font-weight: 500;">表名 (Table Name):</label> <input id="tableName" type="text"${attr("value", tableName)} style="padding: 0.25rem 0.5rem; border: 1px solid var(--border-color, #d1d5db); border-radius: 0.25rem;" placeholder="Enter table name"/></div> `);
      FormatConverter($$renderer2, {
        disabled: !hasTable,
        activeFormat: currentFormat,
        onConvert: handleConvert
      });
      $$renderer2.push(`<!----></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> `);
    if (hasOutput) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="card svelte-1tbjm83">`);
      OutputPane($$renderer2, {
        content: currentOutput,
        format: currentFormat,
        onCopy: handleCopy,
        onDownload: handleDownload
      });
      $$renderer2.push(`<!----></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> `);
    FullscreenPreview($$renderer2, {
      open: fullscreenOpen,
      data: tableData,
      onClose: () => fullscreenOpen = false
    });
    $$renderer2.push(`<!----> `);
    if (shortcutsOpen) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="modal-overlay svelte-1tbjm83"><div class="shortcuts-panel svelte-1tbjm83"><div class="shortcuts-header svelte-1tbjm83"><h3 class="svelte-1tbjm83">⌨️ 快捷键</h3> `);
      Button($$renderer2, {
        variant: "ghost",
        size: "sm",
        onclick: () => shortcutsOpen = false,
        children: ($$renderer3) => {
          $$renderer3.push(`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" x2="6" y1="6" y2="18"></line><line x1="6" x2="18" y1="6" y2="18"></line></svg>`);
        },
        $$slots: { default: true }
      });
      $$renderer2.push(`<!----></div> <div class="shortcuts-grid svelte-1tbjm83"><div class="shortcut svelte-1tbjm83"><span>粘贴数据</span><kbd class="svelte-1tbjm83">Ctrl+V</kbd></div> <div class="shortcut svelte-1tbjm83"><span>全屏预览</span><kbd class="svelte-1tbjm83">F11</kbd></div> <div class="shortcut svelte-1tbjm83"><span>退出全屏</span><kbd class="svelte-1tbjm83">Esc</kbd></div> <div class="shortcut svelte-1tbjm83"><span>撤销操作</span><kbd class="svelte-1tbjm83">Ctrl+Z</kbd></div> <div class="shortcut svelte-1tbjm83"><span>重做操作</span><kbd class="svelte-1tbjm83">Ctrl+Y</kbd></div> <div class="shortcut svelte-1tbjm83"><span>显示帮助</span><kbd class="svelte-1tbjm83">?</kbd></div> <div class="shortcut svelte-1tbjm83"><span>编辑单元格</span><kbd class="svelte-1tbjm83">双击</kbd></div> <div class="shortcut svelte-1tbjm83"><span>行列操作</span><kbd class="svelte-1tbjm83">右键</kbd></div> <div class="shortcut svelte-1tbjm83"><span>点击表头</span><kbd class="svelte-1tbjm83">排序</kbd></div></div></div></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--></div>`);
  });
}
export {
  _page as default
};
