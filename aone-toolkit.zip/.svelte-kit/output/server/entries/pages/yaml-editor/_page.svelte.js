import { a0 as attr_class, a8 as clsx, a4 as ensure_array_like, a3 as attr, a1 as stringify, a6 as bind_props, a7 as head } from "../../../chunks/index2.js";
import * as jsyaml from "js-yaml";
import "clsx";
import { B as Button } from "../../../chunks/Button.js";
import { I as Input } from "../../../chunks/Input.js";
import { e as escape_html } from "../../../chunks/context.js";
import hljs from "highlight.js/lib/core";
import yaml from "highlight.js/lib/languages/yaml";
import json from "highlight.js/lib/languages/json";
import { h as html } from "../../../chunks/html.js";
import { P as Panel } from "../../../chunks/Panel.js";
import "jsonpath-plus";
function isObject(val) {
  return val !== null && typeof val === "object" && !Array.isArray(val);
}
function isArray(val) {
  return Array.isArray(val);
}
function getValueDisplay(key, val) {
  if (isArray(val)) {
    const hasComplexItems = val.some((item) => isObject(item) || isArray(item));
    if (hasComplexItems || val.length > 5) {
      return `Array[${val.length}]`;
    }
    return `[${val.map((item) => typeof item === "string" ? item : JSON.stringify(item)).join(", ")}]`;
  }
  if (isObject(val)) return "";
  return String(val);
}
function hasExpandableChildren(val) {
  if (isObject(val)) return Object.keys(val).length > 0;
  if (isArray(val)) return val.length > 0 && val.some((item) => isObject(item) || isArray(item));
  return false;
}
function getNodeIcon(val) {
  if (isArray(val)) return "tags";
  if (isObject(val)) {
    if (Object.keys(val).length === 0) return "cube";
    return "sitemap";
  }
  return "key";
}
function TreeView_1($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { data, path = [], level = 0, expandedKeys = void 0, onAction } = $$props;
    function getNodeKey(p) {
      return p.join("\0");
    }
    $$renderer2.push(`<ul${attr_class(clsx(level > 0 ? "pl-4 border-l border-slate-200 dark:border-slate-700 mt-1" : ""))}>`);
    if (data && typeof data === "object") {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<!--[-->`);
      const each_array = ensure_array_like(Object.entries(data));
      for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
        let [key, value] = each_array[$$index];
        const currentPath = [...path, key];
        const nodeKey = getNodeKey(currentPath);
        const hasChildren = hasExpandableChildren(value);
        const isExpanded = expandedKeys.has(nodeKey);
        const icon = getNodeIcon(value);
        $$renderer2.push(`<li class="my-1.5"><div class="group flex items-center hover:bg-primary-50 dark:hover:bg-slate-800 rounded px-2 py-1.5 transition-colors focus:bg-primary-100 dark:focus:bg-slate-700 focus:outline-none focus:ring-1 focus:ring-primary-300" role="treeitem" aria-selected="false" tabindex="0"><button type="button" class="w-6 h-6 flex items-center justify-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors focus:outline-none shrink-0"${attr("disabled", !hasChildren, true)} tabindex="-1">`);
        if (hasChildren) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"${attr_class(`w-4 h-4 transition-transform duration-200 ${stringify(isExpanded ? "rotate-90" : "")}`)}><path fill-rule="evenodd" d="M7.21 14.77a.75.75 0 01.02-1.06L11.168 10 7.23 6.29a.75.75 0 111.04-1.08l4.5 4.25a.75.75 0 010 1.08l-4.5 4.25a.75.75 0 01-1.06-.02z" clip-rule="evenodd"></path></svg>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--></button> <span class="w-6 h-6 flex items-center justify-center mr-1 shrink-0">`);
        if (icon === "tags") {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4 text-purple-500"><path stroke-linecap="round" stroke-linejoin="round" d="M9.568 3H5.25A2.25 2.25 0 0 0 3 5.25v4.318c0 .597.237 1.17.659 1.591l9.581 9.581c.699.699 1.78.872 2.607.33a18.095 18.095 0 0 0 5.223-5.223c.542-.827.369-1.908-.33-2.607L11.16 3.66A2.25 2.25 0 0 0 9.568 3Z"></path><path stroke-linecap="round" stroke-linejoin="round" d="M6 6h.008v.008H6V6Z"></path></svg>`);
        } else {
          $$renderer2.push("<!--[!-->");
          if (icon === "cube") {
            $$renderer2.push("<!--[-->");
            $$renderer2.push(`<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4 text-slate-400"><path stroke-linecap="round" stroke-linejoin="round" d="m21 7.5-9-5.25L3 7.5m18 0-9 5.25m9-5.25v9l-9 5.25M3 7.5l9 5.25M3 7.5v9l9 5.25m0-9v9"></path></svg>`);
          } else {
            $$renderer2.push("<!--[!-->");
            if (icon === "sitemap") {
              $$renderer2.push("<!--[-->");
              $$renderer2.push(`<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4 text-blue-500"><path stroke-linecap="round" stroke-linejoin="round" d="M7.217 10.907a2.25 2.25 0 1 0 0 2.186m0-2.186c.18.324.283.696.283 1.093s-.103.77-.283 1.093m0-2.186 9.566-5.314m-9.566 7.5 9.566 5.314m0 0a2.25 2.25 0 1 0 3.935 2.186 2.25 2.25 0 0 0-3.935-2.186Zm0-12.814a2.25 2.25 0 1 0 3.933-2.185 2.25 2.25 0 0 0-3.933 2.185Z"></path></svg>`);
            } else {
              $$renderer2.push("<!--[!-->");
              $$renderer2.push(`<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4 text-green-500"><path stroke-linecap="round" stroke-linejoin="round" d="M15.75 5.25a3 3 0 0 1 3 3m3 0a6 6 0 0 1-7.029 5.912c-.563-.097-1.159.026-1.563.43L10.5 17.25H8.25v2.25H6v2.25H2.25v-2.818c0-.597.237 1.17.659 1.591l6.499-6.499c.404-.404.527-1 .43-1.563A6 6 0 1 1 21.75 8.25Z"></path></svg>`);
            }
            $$renderer2.push(`<!--]-->`);
          }
          $$renderer2.push(`<!--]-->`);
        }
        $$renderer2.push(`<!--]--></span> <div class="flex-grow font-mono text-sm truncate"><span class="font-medium text-slate-700 dark:text-slate-200">${escape_html(key)}</span> `);
        if (!isObject(value)) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<span class="mx-1 text-slate-400">:</span> <span${attr_class(clsx(isArray(value) ? "text-purple-600 dark:text-purple-400" : "text-blue-600 dark:text-blue-400"))}>${escape_html(getValueDisplay(key, value))}</span>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--></div> <div class="opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1 ml-2"><button type="button" class="w-6 h-6 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-500 dark:text-slate-400 flex items-center justify-center transition-colors" title="Copy Path"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-3.5 h-3.5"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"></rect><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"></path></svg></button> <button type="button" class="w-6 h-6 rounded-full hover:bg-blue-100 dark:hover:bg-blue-900/30 text-blue-600 dark:text-blue-400 flex items-center justify-center transition-colors" title="Add Child"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="w-3.5 h-3.5"><path d="M10.75 4.75a.75.75 0 00-1.5 0v4.5h-4.5a.75.75 0 000 1.5h4.5v4.5a.75.75 0 001.5 0v-4.5h4.5a.75.75 0 000-1.5h-4.5v-4.5z"></path></svg></button> <button type="button" class="w-6 h-6 rounded-full hover:bg-green-100 dark:hover:bg-green-900/30 text-green-600 dark:text-green-400 flex items-center justify-center transition-colors" title="Edit Node"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="w-3.5 h-3.5"><path d="M5.433 13.917l1.262-3.155A4 4 0 017.58 9.42l6.92-6.918a2.121 2.121 0 013 3l-6.92 6.918c-.383.383-.84.685-1.343.886l-3.154 1.262a.5.5 0 01-.65-.65z"></path><path d="M3.5 5.75c0-.69.56-1.25 1.25-1.25H10A.75.75 0 0010 3H4.75A2.75 2.75 0 002 5.75v9.5A2.75 2.75 0 004.75 18h9.5A2.75 2.75 0 0017 15.25V10a.75.75 0 00-1.5 0v5.25c0 .69-.56 1.25-1.25 1.25h-9.5c-.69 0-1.25-.56-1.25-1.25v-9.5z"></path></svg></button> <button type="button" class="w-6 h-6 rounded-full hover:bg-amber-100 dark:hover:bg-amber-900/30 text-amber-600 dark:text-amber-400 flex items-center justify-center transition-colors" title="Duplicate Node"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="w-3.5 h-3.5"><path d="M7 3.5A1.5 1.5 0 018.5 2h3.879a1.5 1.5 0 011.06.44l3.122 3.12A1.5 1.5 0 0117 6.622V12.5a1.5 1.5 0 01-1.5 1.5h-1v-3.379a3 3 0 00-.879-2.121L10.5 5.379A3 3 0 008.379 4.5H7v-1z"></path><path d="M4.5 6A1.5 1.5 0 003 7.5v9A1.5 1.5 0 004.5 18h7a1.5 1.5 0 001.5-1.5v-5.879a1.5 1.5 0 00-.44-1.06L9.44 6.439A1.5 1.5 0 008.378 6H4.5z"></path></svg></button> <button type="button" class="w-6 h-6 rounded-full hover:bg-red-100 dark:hover:bg-red-900/30 text-red-600 dark:text-red-400 flex items-center justify-center transition-colors" title="Delete Node"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="w-3.5 h-3.5"><path fill-rule="evenodd" d="M8.75 1A2.75 2.75 0 006 3.75v.443c-.795.077-1.584.176-2.365.298a.75.75 0 10.23 1.482l.149-.022.841 10.518A2.75 2.75 0 007.596 19h4.807a2.75 2.75 0 002.742-2.53l.841-10.52.149.023a.75.75 0 00.23-1.482A41.03 41.03 0 0014 4.193V3.75A2.75 2.75 0 0011.25 1h-2.5zM10 4c.84 0 1.673.025 2.5.075V3.75c0-.69-.56-1.25-1.25-1.25h-2.5c-.69 0-1.25.56-1.25 1.25v.325C8.327 4.025 9.16 4 10 4zM8.58 7.72a.75.75 0 00-1.5.06l.3 7.5a.75.75 0 101.5-.06l-.3-7.5zm4.34.06a.75.75 0 10-1.5-.06l-.3 7.5a.75.75 0 101.5.06l.3-7.5z" clip-rule="evenodd"></path></svg></button> <button type="button" class="w-6 h-6 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-500 dark:text-slate-400 flex items-center justify-center transition-colors" title="Move Up"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="w-3.5 h-3.5"><path fill-rule="evenodd" d="M10 17a.75.75 0 01-.75-.75V5.612L5.29 9.77a.75.75 0 01-1.08-1.04l5.25-5.5a.75.75 0 011.08 0l5.25 5.5a.75.75 0 11-1.08 1.04l-3.96-4.158V16.25A.75.75 0 0110 17z" clip-rule="evenodd"></path></svg></button> <button type="button" class="w-6 h-6 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-500 dark:text-slate-400 flex items-center justify-center transition-colors" title="Move Down"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="w-3.5 h-3.5"><path fill-rule="evenodd" d="M10 3a.75.75 0 01.75.75v10.638l3.96-4.158a.75.75 0 111.08 1.04l-5.25 5.5a.75.75 0 01-1.08 0l-5.25-5.5a.75.75 0 111.08-1.04l3.96 4.158V3.75A.75.75 0 0110 3z" clip-rule="evenodd"></path></svg></button></div></div> `);
        if (hasChildren && isExpanded) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<div>`);
          TreeView_1($$renderer2, {
            data: value,
            path: currentPath,
            level: level + 1,
            expandedKeys,
            onAction
          });
          $$renderer2.push(`<!----></div>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--></li>`);
      }
      $$renderer2.push(`<!--]-->`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--></ul>`);
    bind_props($$props, { expandedKeys });
  });
}
const SvelteSet = globalThis.Set;
function EditorPane($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { data, onAction } = $$props;
    let searchQuery = "";
    let expandedKeys = new SvelteSet();
    function filterData(obj, query) {
      if (!query) return obj;
      if (typeof obj !== "object" || obj === null) return obj;
      const result = Array.isArray(obj) ? [] : {};
      let hasMatch = false;
      for (const [key, value] of Object.entries(obj)) {
        const valueMatch = String(value).toLowerCase().includes(query.toLowerCase());
        const keyMatch = key.toLowerCase().includes(query.toLowerCase());
        if (keyMatch || valueMatch) {
          if (Array.isArray(result)) result.push(value);
          else result[key] = value;
          hasMatch = true;
        } else if (typeof value === "object" && value !== null) {
          const filteredChild = filterData(value, query);
          const hasContent = Array.isArray(filteredChild) ? filteredChild.length > 0 : Object.keys(filteredChild).length > 0;
          if (hasContent) {
            if (Array.isArray(result)) result.push(filteredChild);
            else result[key] = filteredChild;
            hasMatch = true;
          }
        }
      }
      return hasMatch ? result : Array.isArray(obj) ? [] : {};
    }
    let filteredData = searchQuery ? filterData(data, searchQuery) : data;
    function getAllObjectPaths(obj, path = []) {
      const paths = [];
      if (!obj || typeof obj !== "object") return paths;
      for (const [key, val] of Object.entries(obj)) {
        const currentPath = [...path, key];
        if (hasExpandableChildren(val)) {
          paths.push(currentPath.join("\0"));
          paths.push(...getAllObjectPaths(val, currentPath));
        }
      }
      return paths;
    }
    function handleExpandAll() {
      const allPaths = getAllObjectPaths(filteredData);
      allPaths.forEach((k) => expandedKeys.add(k));
    }
    function handleCollapseAll() {
      expandedKeys.clear();
    }
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      $$renderer3.push(`<div class="flex flex-col h-full bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800"><div class="p-4 border-b border-slate-200 dark:border-slate-800 flex flex-col gap-3"><h2 class="text-xl font-bold text-slate-900 dark:text-white">YAML Editor</h2> <div class="flex items-center gap-2"><div class="flex-1 relative">`);
      Input($$renderer3, {
        placeholder: "Search...",
        class: "pr-8 h-8 text-sm",
        get value() {
          return searchQuery;
        },
        set value($$value) {
          searchQuery = $$value;
          $$settled = false;
        }
      });
      $$renderer3.push(`<!----> `);
      if (searchQuery) {
        $$renderer3.push("<!--[-->");
        $$renderer3.push(`<button class="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600" title="Clear search"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-x-circle shrink-0"><circle cx="12" cy="12" r="10"></circle><path d="m15 9-6 6"></path><path d="m9 9 6 6"></path></svg></button>`);
      } else {
        $$renderer3.push("<!--[!-->");
      }
      $$renderer3.push(`<!--]--></div> <div class="flex gap-1">`);
      Button($$renderer3, {
        variant: "secondary",
        size: "sm",
        class: "px-2 h-8",
        title: "Expand All",
        onclick: handleExpandAll,
        children: ($$renderer4) => {
          $$renderer4.push(`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-chevrons-up-down shrink-0"><path d="m7 15 5 5 5-5"></path><path d="m7 9 5-5 5 5"></path></svg>`);
        },
        $$slots: { default: true }
      });
      $$renderer3.push(`<!----> `);
      Button($$renderer3, {
        variant: "secondary",
        size: "sm",
        class: "px-2 h-8",
        title: "Collapse All",
        onclick: handleCollapseAll,
        children: ($$renderer4) => {
          $$renderer4.push(`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-chevrons-down-up shrink-0"><path d="m7 20 5-5 5 5"></path><path d="m7 4 5 5 5-5"></path></svg>`);
        },
        $$slots: { default: true }
      });
      $$renderer3.push(`<!----></div></div></div> <div class="flex-1 overflow-y-auto p-2 scrollbar-thin">`);
      TreeView_1($$renderer3, {
        data: filteredData,
        onAction,
        get expandedKeys() {
          return expandedKeys;
        },
        set expandedKeys($$value) {
          expandedKeys = $$value;
          $$settled = false;
        }
      });
      $$renderer3.push(`<!----></div> <div class="p-4 border-t border-slate-200 dark:border-slate-800">`);
      Button($$renderer3, {
        variant: "primary",
        size: "sm",
        class: "w-full flex items-center justify-center gap-2",
        onclick: () => onAction({ type: "add", path: [] }),
        children: ($$renderer4) => {
          $$renderer4.push(`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-plus shrink-0"><path d="M5 12h14"></path><path d="M12 5v14"></path></svg> Add Root Node`);
        },
        $$slots: { default: true }
      });
      $$renderer3.push(`<!----></div></div>`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
  });
}
function YamlPreview($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    hljs.registerLanguage("yaml", yaml);
    hljs.registerLanguage("json", json);
    let mode = "yaml";
    let highlightedCode = "";
    $$renderer2.push(`<div class="h-full bg-slate-50 dark:bg-slate-950 overflow-hidden flex flex-col relative group"><div class="absolute right-4 top-4 z-10 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity"><div class="bg-white dark:bg-slate-800 rounded-lg p-1 border border-slate-200 dark:border-slate-700 shadow-sm flex text-xs"><button${attr_class(`px-2 py-1 rounded-md ${stringify(
      "bg-slate-100 dark:bg-slate-700 font-medium text-slate-800 dark:text-slate-200"
    )}`)}>YAML</button> <button${attr_class(`px-2 py-1 rounded-md ${stringify("text-slate-500 hover:text-slate-700 dark:hover:text-slate-300")}`)}>JSON</button></div></div> <div class="flex-1 overflow-auto p-4 custom-scrollbar"><pre class="font-mono text-sm leading-relaxed"><code${attr_class(`language-${stringify(mode)}`)}>${html(highlightedCode)}</code></pre></div></div>`);
  });
}
function Toolbar($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      canUndo,
      canRedo,
      onUndo,
      onRedo,
      onClear,
      onCopy,
      onCopyJSON,
      onImport,
      onBatch,
      onHelp,
      onFormat
    } = $$props;
    let isDark = false;
    let exportDropdownOpen = false;
    function toggleTheme() {
      isDark = !isDark;
      if (isDark) {
        document.documentElement.classList.add("dark");
        localStorage.setItem("theme", "dark");
      } else {
        document.documentElement.classList.remove("dark");
        localStorage.setItem("theme", "light");
      }
    }
    $$renderer2.push(`<div class="flex items-center gap-0.5 text-xs"><div class="flex items-center gap-0.5 bg-slate-100 dark:bg-slate-800 rounded-md p-0.5 mr-1">`);
    Button($$renderer2, {
      variant: "ghost",
      size: "sm",
      onclick: onUndo,
      disabled: !canUndo,
      title: "Undo (Ctrl+Z)",
      class: "h-7 w-7 p-0",
      children: ($$renderer3) => {
        $$renderer3.push(`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-undo-2 shrink-0"><path d="M9 14 4 9l5-5"></path><path d="M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5v0a5.5 5.5 0 0 1-5.5 5.5H11"></path></svg>`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> `);
    Button($$renderer2, {
      variant: "ghost",
      size: "sm",
      onclick: onRedo,
      disabled: !canRedo,
      title: "Redo (Ctrl+Y)",
      class: "h-7 w-7 p-0",
      children: ($$renderer3) => {
        $$renderer3.push(`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-redo-2 shrink-0"><path d="m15 14 5-5-5-5"></path><path d="M20 9H9.5A5.5 5.5 0 0 0 4 14.5v0A5.5 5.5 0 0 0 9.5 20H13"></path></svg>`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----></div> <div class="flex items-center gap-0.5 bg-blue-50 dark:bg-blue-900/20 rounded-md p-0.5 mr-1">`);
    Button($$renderer2, {
      variant: "ghost",
      size: "sm",
      onclick: onBatch,
      title: "Batch Import (Paste YAML)",
      class: "h-7 px-2 text-blue-600 dark:text-blue-400 hover:bg-blue-100 dark:hover:bg-blue-900/40",
      children: ($$renderer3) => {
        $$renderer3.push(`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-clipboard-list mr-1 shrink-0"><rect width="8" height="4" x="8" y="2" rx="1" ry="1"></rect><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"></path><path d="M12 11h4"></path><path d="M12 16h4"></path><path d="M8 11h.01"></path><path d="M8 16h.01"></path></svg> <span>Batch</span>`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> `);
    Button($$renderer2, {
      variant: "ghost",
      size: "sm",
      onclick: onImport,
      title: "Import YAML File",
      class: "h-7 px-2 text-blue-600 dark:text-blue-400 hover:bg-blue-100 dark:hover:bg-blue-900/40",
      children: ($$renderer3) => {
        $$renderer3.push(`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-upload mr-1 shrink-0"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="17 8 12 3 7 8"></polyline><line x1="12" x2="12" y1="3" y2="15"></line></svg> <span>Import</span>`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----></div> <div class="relative flex items-center gap-0.5 bg-green-50 dark:bg-green-900/20 rounded-md p-0.5 mr-1">`);
    Button($$renderer2, {
      variant: "ghost",
      size: "sm",
      onclick: () => exportDropdownOpen = !exportDropdownOpen,
      title: "Download File",
      class: "h-7 px-2 text-green-600 dark:text-green-400 hover:bg-green-100 dark:hover:bg-green-900/40",
      children: ($$renderer3) => {
        $$renderer3.push(`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-download mr-1 shrink-0"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" x2="12" y1="15" y2="3"></line></svg> <span>Export</span> <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"${attr_class(`lucide lucide-chevron-down ml-1 shrink-0 transition-transform ${stringify(exportDropdownOpen ? "rotate-180" : "")}`)}><path d="m6 9 6 6 6-6"></path></svg>`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> `);
    if (exportDropdownOpen) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="absolute top-full left-0 mt-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg shadow-lg z-50 min-w-[120px] py-1"><button class="w-full px-3 py-1.5 text-left text-sm hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center gap-2"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-orange-500"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"></path><path d="M14 2v4a2 2 0 0 0 2 2h4"></path><path d="m10 13-2 2 2 2"></path><path d="m14 17 2-2-2-2"></path></svg> <span>YAML</span></button> <button class="w-full px-3 py-1.5 text-left text-sm hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center gap-2"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-blue-500"><path d="M8 3H7a2 2 0 0 0-2 2v5a2 2 0 0 1-2 2 2 2 0 0 1 2 2v5c0 1.1.9 2 2 2h1"></path><path d="M16 21h1a2 2 0 0 0 2-2v-5c0-1.1.9-2 2-2a2 2 0 0 1-2-2V5a2 2 0 0 0-2-2h-1"></path></svg> <span>JSON</span></button></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--></div> <div class="flex items-center gap-0.5 bg-cyan-50 dark:bg-cyan-900/20 rounded-md p-0.5 mr-1">`);
    Button($$renderer2, {
      variant: "ghost",
      size: "sm",
      onclick: onCopy,
      title: "Copy as YAML",
      class: "h-7 px-2 text-cyan-600 dark:text-cyan-400 hover:bg-cyan-100 dark:hover:bg-cyan-900/40",
      children: ($$renderer3) => {
        $$renderer3.push(`<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="mr-1 shrink-0"><rect width="8" height="4" x="8" y="2" rx="1" ry="1"></rect><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"></path><path d="m9 14 2 2 4-4"></path></svg> <span>YAML</span>`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> `);
    if (onCopyJSON) {
      $$renderer2.push("<!--[-->");
      Button($$renderer2, {
        variant: "ghost",
        size: "sm",
        onclick: onCopyJSON,
        title: "Copy as JSON",
        class: "h-7 px-2 text-cyan-600 dark:text-cyan-400 hover:bg-cyan-100 dark:hover:bg-cyan-900/40",
        children: ($$renderer3) => {
          $$renderer3.push(`<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="mr-1 shrink-0"><rect width="8" height="4" x="8" y="2" rx="1" ry="1"></rect><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"></path><path d="M8 12a1 1 0 0 0-1 1v1a1 1 0 0 1-1 1 1 1 0 0 1 1 1v1a1 1 0 0 0 1 1"></path></svg> <span>JSON</span>`);
        },
        $$slots: { default: true }
      });
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--></div> `);
    if (onFormat) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="flex items-center gap-0.5 bg-purple-50 dark:bg-purple-900/20 rounded-md p-0.5 mr-1">`);
      Button($$renderer2, {
        variant: "ghost",
        size: "sm",
        onclick: onFormat,
        title: "Format / Beautify YAML",
        class: "h-7 px-2 text-purple-600 dark:text-purple-400 hover:bg-purple-100 dark:hover:bg-purple-900/40",
        children: ($$renderer3) => {
          $$renderer3.push(`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-sparkles mr-1 shrink-0"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"></path><path d="M5 3v4"></path><path d="M19 17v4"></path><path d="M3 5h4"></path><path d="M17 19h4"></path></svg> <span>Format</span>`);
        },
        $$slots: { default: true }
      });
      $$renderer2.push(`<!----></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> `);
    Button($$renderer2, {
      variant: "ghost",
      size: "sm",
      onclick: onClear,
      title: "Clear All Data",
      class: "h-7 w-7 p-0 text-red-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/30 mr-1",
      children: ($$renderer3) => {
        $$renderer3.push(`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-trash-2 shrink-0"><path d="M3 6h18"></path><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"></path><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"></path><line x1="10" x2="10" y1="11" y2="17"></line><line x1="14" x2="14" y1="11" y2="17"></line></svg>`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> <div class="flex items-center gap-0.5 bg-slate-100 dark:bg-slate-800 rounded-md p-0.5 mr-1">`);
    Button($$renderer2, {
      variant: "ghost",
      size: "sm",
      onclick: onHelp,
      title: "Keyboard Shortcuts",
      class: "h-7 w-7 p-0 text-slate-600 dark:text-slate-400",
      children: ($$renderer3) => {
        $$renderer3.push(`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-help-circle shrink-0"><circle cx="12" cy="12" r="10"></circle><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path><path d="M12 17h.01"></path></svg>`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----></div> <div class="flex items-center gap-0.5 bg-slate-100 dark:bg-slate-800 rounded-md p-0.5">`);
    Button($$renderer2, {
      variant: "ghost",
      size: "sm",
      onclick: toggleTheme,
      title: isDark ? "Switch to Light Mode" : "Switch to Dark Mode",
      class: "h-7 w-7 p-0",
      children: ($$renderer3) => {
        if (isDark) {
          $$renderer3.push("<!--[-->");
          $$renderer3.push(`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-moon text-yellow-400 shrink-0"><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"></path></svg>`);
        } else {
          $$renderer3.push("<!--[!-->");
          $$renderer3.push(`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-sun text-orange-400 shrink-0"><circle cx="12" cy="12" r="4"></circle><path d="M12 2v2"></path><path d="M12 20v2"></path><path d="m4.93 4.93 1.41 1.41"></path><path d="m17.66 17.66 1.41 1.41"></path><path d="M2 12h2"></path><path d="M20 12h2"></path><path d="m6.34 17.66-1.41 1.41"></path><path d="m19.07 4.93-1.41 1.41"></path></svg>`);
        }
        $$renderer3.push(`<!--]-->`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----></div></div>`);
  });
}
function EditNodeModal($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      open = false,
      title = "Edit Node",
      nodeKey = "",
      nodeValue = "",
      isObject: isObject2 = false,
      isArrayItem = false,
      onSave,
      onClose
    } = $$props;
    let key = "";
    let value = "";
    let isObj = false;
    let explicitType = "Auto";
    function handleSave() {
      onSave?.(key, value, isObj, explicitType);
    }
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      if (open) {
        $$renderer3.push("<!--[-->");
        $$renderer3.push(`<div class="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">`);
        Panel($$renderer3, {
          class: "w-full max-w-sm",
          title,
          children: ($$renderer4) => {
            $$renderer4.push(`<div class="space-y-4">`);
            if (!isArrayItem) {
              $$renderer4.push("<!--[-->");
              Input($$renderer4, {
                label: "Key Name",
                placeholder: "Enter key name",
                get value() {
                  return key;
                },
                set value($$value) {
                  key = $$value;
                  $$settled = false;
                }
              });
            } else {
              $$renderer4.push("<!--[!-->");
            }
            $$renderer4.push(`<!--]--> <div class="flex items-center gap-2"><input type="checkbox" id="is-object-check"${attr("checked", isObj, true)} class="rounded border-slate-300 text-primary-600 focus:ring-primary-500"/> <label for="is-object-check" class="text-sm font-medium text-slate-700 dark:text-slate-300">Is Object/Container</label></div> `);
            {
              $$renderer4.push("<!--[-->");
              $$renderer4.push(`<div class="flex flex-col gap-1.5"><div class="text-sm font-medium text-slate-700 dark:text-slate-200">Type</div> `);
              $$renderer4.select(
                {
                  value: explicitType,
                  class: "w-full rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 dark:text-white"
                },
                ($$renderer5) => {
                  $$renderer5.option({ value: "Auto" }, ($$renderer6) => {
                    $$renderer6.push(`Auto (Infer)`);
                  });
                  $$renderer5.option({ value: "String" }, ($$renderer6) => {
                    $$renderer6.push(`String`);
                  });
                  $$renderer5.option({ value: "Number" }, ($$renderer6) => {
                    $$renderer6.push(`Number`);
                  });
                  $$renderer5.option({ value: "Boolean" }, ($$renderer6) => {
                    $$renderer6.push(`Boolean`);
                  });
                }
              );
              $$renderer4.push(`</div> `);
              Input($$renderer4, {
                label: "Value",
                placeholder: "Enter value",
                get value() {
                  return value;
                },
                set value($$value) {
                  value = $$value;
                  $$settled = false;
                }
              });
              $$renderer4.push(`<!---->`);
            }
            $$renderer4.push(`<!--]--> <div class="flex justify-end gap-2 mt-6">`);
            Button($$renderer4, {
              variant: "ghost",
              onclick: onClose,
              children: ($$renderer5) => {
                $$renderer5.push(`<!---->Cancel`);
              },
              $$slots: { default: true }
            });
            $$renderer4.push(`<!----> `);
            Button($$renderer4, {
              variant: "primary",
              onclick: handleSave,
              children: ($$renderer5) => {
                $$renderer5.push(`<!---->Save`);
              },
              $$slots: { default: true }
            });
            $$renderer4.push(`<!----></div></div>`);
          }
        });
        $$renderer3.push(`<!----></div>`);
      } else {
        $$renderer3.push("<!--[!-->");
      }
      $$renderer3.push(`<!--]-->`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
    bind_props($$props, { open });
  });
}
function BatchImportModal($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { open = false, onImport, onClose } = $$props;
    let content = "";
    function handleImport() {
      onImport?.(content);
      content = "";
    }
    if (open) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">`);
      Panel($$renderer2, {
        class: "w-full max-w-2xl",
        title: "Batch Import YAML",
        children: ($$renderer3) => {
          $$renderer3.push(`<div class="space-y-4"><p class="text-sm text-slate-500 dark:text-slate-400">Paste your YAML content below. Support standard YAML format.</p> <textarea class="w-full h-64 p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 resize-none" placeholder="Paste YAML here...">`);
          const $$body = escape_html(content);
          if ($$body) {
            $$renderer3.push(`${$$body}`);
          }
          $$renderer3.push(`</textarea> <div class="flex justify-end gap-2">`);
          Button($$renderer3, {
            variant: "ghost",
            onclick: onClose,
            children: ($$renderer4) => {
              $$renderer4.push(`<!---->Cancel`);
            },
            $$slots: { default: true }
          });
          $$renderer3.push(`<!----> `);
          Button($$renderer3, {
            variant: "primary",
            onclick: handleImport,
            disabled: !content.trim(),
            children: ($$renderer4) => {
              $$renderer4.push(`<!---->Import`);
            },
            $$slots: { default: true }
          });
          $$renderer3.push(`<!----></div></div>`);
        }
      });
      $$renderer2.push(`<!----></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
    bind_props($$props, { open });
  });
}
function ShortcutsModal($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { open = void 0, onClose } = $$props;
    if (open) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4" role="dialog" aria-modal="true"><div class="w-full max-w-md animate-in fade-in zoom-in-95 duration-200">`);
      Panel($$renderer2, {
        title: "Keyboard Shortcuts",
        class: "shadow-xl",
        children: ($$renderer3) => {
          $$renderer3.push(`<div class="space-y-4 p-4"><div class="grid grid-cols-2 gap-4 text-sm"><div class="flex flex-col gap-2"><span class="font-semibold text-slate-900 dark:text-slate-100">General</span> <div class="flex justify-between text-slate-600 dark:text-slate-400"><span>Undo</span> <kbd class="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-600 font-mono text-xs">Ctrl+Z</kbd></div> <div class="flex justify-between text-slate-600 dark:text-slate-400"><span>Redo</span> <kbd class="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-600 font-mono text-xs">Ctrl+Y</kbd></div> <div class="flex justify-between text-slate-600 dark:text-slate-400"><span>New Root Node</span> <kbd class="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-600 font-mono text-xs">Ctrl+N</kbd></div></div> <div class="flex flex-col gap-2"><span class="font-semibold text-slate-900 dark:text-slate-100">Navigation</span> <div class="flex justify-between text-slate-600 dark:text-slate-400"><span>Move Selection</span> <kbd class="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-600 font-mono text-xs">↑ ↓</kbd></div> <div class="flex justify-between text-slate-600 dark:text-slate-400"><span>Expand/Focus</span> <kbd class="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-600 font-mono text-xs">→</kbd></div> <div class="flex justify-between text-slate-600 dark:text-slate-400"><span>Collapse/Parent</span> <kbd class="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-600 font-mono text-xs">←</kbd></div> <div class="flex justify-between text-slate-600 dark:text-slate-400"><span>Edit Node</span> <kbd class="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-600 font-mono text-xs">Enter</kbd></div></div></div></div> <div class="flex justify-end p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50">`);
          Button($$renderer3, {
            variant: "secondary",
            onclick: onClose,
            children: ($$renderer4) => {
              $$renderer4.push(`<!---->Close`);
            },
            $$slots: { default: true }
          });
          $$renderer3.push(`<!----></div>`);
        }
      });
      $$renderer2.push(`<!----></div></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
    bind_props($$props, { open });
  });
}
function YamlEditor($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const STORAGE_KEY = "yamlEditorState";
    let data = {};
    let historyPast = [];
    let historyFuture = [];
    let yamlString = "";
    let modalOpen = false;
    let batchModalOpen = false;
    let shortcutsModalOpen = false;
    let modalTitle = "Edit Node";
    let modalPath = [];
    let modalKey = "";
    let modalValue = "";
    let modalIsObject = false;
    let isEditing = false;
    let canUndo = historyPast.length > 0;
    let canRedo = historyFuture.length > 0;
    let fileInput;
    function snapshot() {
      return JSON.parse(JSON.stringify(data));
    }
    function processArrays(obj) {
      if (!obj || typeof obj !== "object") return obj;
      Object.keys(obj).forEach((key) => {
        const value = obj[key];
        if (Array.isArray(value)) {
          value.forEach((item) => {
            if (typeof item === "object") processArrays(item);
          });
        } else if (typeof value === "object") {
          processArrays(value);
        }
      });
      return obj;
    }
    function pushHistory() {
      historyPast = [...historyPast, snapshot()].slice(-50);
      historyFuture = [];
    }
    function handleUndo() {
      if (!canUndo) return;
      const prev = historyPast[historyPast.length - 1];
      historyFuture = [snapshot(), ...historyFuture];
      historyPast = historyPast.slice(0, -1);
      data = prev;
      updateYamlString();
    }
    function handleRedo() {
      if (!canRedo) return;
      const next = historyFuture[0];
      historyFuture = historyFuture.slice(1);
      historyPast = [...historyPast, snapshot()];
      data = next;
      updateYamlString();
    }
    function updateYamlString() {
      try {
        const dump = jsyaml.dump(data, {
          indent: 2,
          lineWidth: -1,
          noRefs: true,
          quotingType: '"',
          forceQuotes: false,
          flowLevel: -1,
          styles: { "!!null": "empty", "!!map": "block", "!!seq": "block" }
        });
        yamlString = dump.replace(/^---\n/, "").replace(/\n---$/, "").replace(/\n\n+/g, "\n");
        localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
      } catch (e) {
        console.error("YAML Dump error", e);
        yamlString = "Error generating YAML";
      }
    }
    function getNode(obj, path) {
      let current = obj;
      for (const k of path) {
        if (current && typeof current === "object" && k in current) {
          current = current[k];
        } else {
          return void 0;
        }
      }
      return current;
    }
    function handleAction(event) {
      const { type, path } = event;
      const parentPath = path.slice(0, -1);
      const key = path[path.length - 1];
      if (type === "add") {
        openModal("Add Node", path, false);
        return;
      }
      const parent = parentPath.length === 0 ? data : getNode(data, parentPath);
      if (type === "edit") {
        const val = getNode(data, path);
        openModal("Edit Node", path, true, key, val);
      } else if (type === "delete") {
        if (confirm("Delete this node?")) {
          pushHistory();
          if (Array.isArray(parent)) {
            parent.splice(Number(key), 1);
          } else {
            delete parent[key];
          }
          data = { ...data };
          updateYamlString();
        }
      } else if (type === "copyPath") {
        const jsonPath = "$." + path.map((p) => {
          if (typeof p === "number" || /^\d+$/.test(String(p))) {
            return `[${p}]`;
          }
          return p;
        }).join(".");
        navigator.clipboard.writeText(jsonPath).then(() => {
          console.log("Copied path:", jsonPath);
        }).catch((err) => {
          console.error("Failed to copy path:", err);
        });
      } else if (type === "up" || type === "down") {
        pushHistory();
        if (Array.isArray(parent)) {
          const idx = Number(key);
          const newIdx = type === "up" ? idx - 1 : idx + 1;
          if (newIdx >= 0 && newIdx < parent.length) {
            const item = parent[idx];
            parent.splice(idx, 1);
            parent.splice(newIdx, 0, item);
            data = { ...data };
            updateYamlString();
          }
        } else {
          const keys = Object.keys(parent);
          const idx = keys.indexOf(key);
          if (idx === -1) return;
          const newIdx = type === "up" ? idx - 1 : idx + 1;
          if (newIdx >= 0 && newIdx < keys.length) {
            keys.splice(idx, 1);
            keys.splice(newIdx, 0, key);
            const newObj = {};
            keys.forEach((k) => newObj[k] = parent[k]);
            if (parentPath.length === 0) data = newObj;
            else {
              const grandParent = getNode(data, parentPath.slice(0, -1));
              const parentKey = parentPath[parentPath.length - 1];
              grandParent[parentKey] = newObj;
              data = { ...data };
            }
            updateYamlString();
          }
        }
      } else if (type === "duplicate") {
        pushHistory();
        const val = getNode(data, path);
        if (Array.isArray(parent)) {
          const newVal = JSON.parse(JSON.stringify(val));
          parent.splice(Number(key) + 1, 0, newVal);
          data = { ...data };
          updateYamlString();
        } else {
          let newKey = `${key}_copy`;
          let counter = 1;
          while (newKey in parent) {
            newKey = `${key}_copy_${counter++}`;
          }
          const newVal = JSON.parse(JSON.stringify(val));
          const keys = Object.keys(parent);
          const idx = keys.indexOf(key);
          if (idx !== -1) {
            const newObj = {};
            keys.forEach((k) => {
              newObj[k] = parent[k];
              if (k === key) newObj[newKey] = newVal;
            });
            if (parentPath.length === 0) data = newObj;
            else {
              const grandParent = getNode(data, parentPath.slice(0, -1));
              const parentKey = parentPath[parentPath.length - 1];
              grandParent[parentKey] = newObj;
              data = { ...data };
            }
          } else {
            parent[newKey] = newVal;
            data = { ...data };
          }
          updateYamlString();
        }
      }
    }
    function openModal(title, path, editMode, key = "", val = "") {
      modalTitle = title;
      modalPath = path;
      isEditing = editMode;
      modalKey = editMode ? key : "";
      if (editMode) {
        if (val !== null && typeof val === "object" && !Array.isArray(val)) {
          modalIsObject = true;
          modalValue = "";
        } else if (Array.isArray(val)) {
          modalIsObject = false;
          modalValue = val.join(", ");
        } else {
          modalIsObject = false;
          modalValue = val;
        }
      } else {
        modalIsObject = false;
        modalValue = "";
      }
      modalOpen = true;
    }
    function handleSaveNode(newKey, newValue, isObj, explicitType = "Auto") {
      pushHistory();
      const targetPath = isEditing ? modalPath.slice(0, -1) : modalPath;
      let parent = targetPath.length === 0 ? data : getNode(data, targetPath);
      if (!parent) parent = data;
      const isArrayParent = Array.isArray(parent);
      if (!isArrayParent && !newKey.trim()) return alert("Key is required");
      if (!isArrayParent && (!isEditing || newKey !== modalKey) && newKey in parent) {
        return alert("Key already exists");
      }
      let finalValue = newValue;
      if (isObj) {
        finalValue = {};
        if (isEditing && typeof parent[modalKey] === "object" && !Array.isArray(parent[modalKey])) {
          finalValue = parent[modalKey];
        }
      } else {
        if (explicitType === "String") finalValue = String(newValue);
        else if (explicitType === "Number") finalValue = Number(newValue);
        else if (explicitType === "Boolean") finalValue = String(newValue).toLowerCase() === "true";
        else {
          if (!isNaN(Number(newValue)) && newValue !== "") finalValue = Number(newValue);
          else if (String(newValue).toLowerCase() === "true") finalValue = true;
          else if (String(newValue).includes(",")) finalValue = String(newValue).split(",").map((s) => s.trim());
          else finalValue = String(newValue);
        }
      }
      if (isEditing && newKey !== modalKey) delete parent[modalKey];
      if (isEditing && newKey !== modalKey && !isArrayParent) {
        const keys = Object.keys(parent);
        const idx = keys.indexOf(modalKey);
        if (idx !== -1) {
          const newObj = {};
          keys.forEach((k) => {
            if (k === modalKey) newObj[newKey] = finalValue;
            else newObj[k] = parent[k];
          });
          if (targetPath.length === 0) data = newObj;
          else {
            const grandParent = getNode(data, targetPath.slice(0, -1));
            const pKey = targetPath[targetPath.length - 1];
            grandParent[pKey] = newObj;
          }
        } else {
          parent[newKey] = finalValue;
        }
      } else {
        if (isArrayParent) {
          if (isEditing) parent[Number(modalKey)] = finalValue;
          else
            parent.push(finalValue);
        } else {
          parent[newKey] = finalValue;
        }
      }
      data = { ...data };
      updateYamlString();
      modalOpen = false;
    }
    function handleClear() {
      if (confirm("Clear all data?")) {
        pushHistory();
        data = {};
        localStorage.removeItem(STORAGE_KEY);
        updateYamlString();
      }
    }
    function handleCopy() {
      navigator.clipboard.writeText(yamlString);
      alert("Copied YAML to clipboard!");
    }
    function handleImport() {
      fileInput.click();
    }
    function handleBatchImportOpen() {
      batchModalOpen = true;
    }
    function performBatchImport(content) {
      try {
        const clean = content.replace(/^---\n/, "").replace(/\n---$/, "");
        const parsed = jsyaml.load(clean);
        pushHistory();
        data = processArrays(parsed) || {};
        updateYamlString();
        batchModalOpen = false;
      } catch (err) {
        alert("YAML Parse Error: " + err);
      }
    }
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      $$renderer3.push(`<div class="h-[calc(100vh-2rem)] flex flex-col pt-2 max-w-[1600px] mx-auto"><div class="flex items-center space-x-1 border-b border-slate-200 dark:border-slate-800 mb-0 px-2"><button${attr_class(`px-4 py-2 text-sm font-medium rounded-t-lg transition-colors border-t border-l border-r border-transparent ${stringify(
        "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-primary-600 dark:text-primary-400 -mb-px"
      )}`)}><span class="flex items-center gap-2"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-network"><rect x="16" y="16" width="6" height="6" rx="1"></rect><rect x="2" y="16" width="6" height="6" rx="1"></rect><rect x="9" y="2" width="6" height="6" rx="1"></rect><path d="M5 16v-3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3"></path><path d="M12 12V8"></path></svg> Visual Editor</span></button> <button${attr_class(`px-4 py-2 text-sm font-medium rounded-t-lg transition-colors border-t border-l border-r border-transparent ${stringify("text-slate-500 hover:text-slate-700 dark:hover:text-slate-300")}`)}><span class="flex items-center gap-2"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-code-2"><path d="m18 16 4-4-4-4"></path><path d="m6 8-4 4 4 4"></path><path d="m14.5 4-5 16"></path></svg> Code Editor</span></button></div> <div class="flex-1 flex overflow-hidden rounded-b-lg rounded-tr-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm relative">`);
      {
        $$renderer3.push("<!--[-->");
        $$renderer3.push(`<div class="w-1/2 min-w-[300px] flex flex-col resize-x overflow-hidden border-r border-slate-200 dark:border-slate-800">`);
        EditorPane($$renderer3, { data, onAction: handleAction });
        $$renderer3.push(`<!----></div> <div class="flex-1 flex flex-col bg-slate-50 dark:bg-slate-950"><div class="h-12 flex items-center justify-between px-4 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shrink-0"><h3 class="font-semibold text-slate-700 dark:text-slate-200">Preview</h3> `);
        Toolbar($$renderer3, {
          canUndo,
          canRedo,
          onUndo: handleUndo,
          onRedo: handleRedo,
          onClear: handleClear,
          onCopy: handleCopy,
          onImport: handleImport,
          onBatch: handleBatchImportOpen,
          onHelp: () => shortcutsModalOpen = true
        });
        $$renderer3.push(`<!----></div> <div class="flex-1 overflow-hidden relative">`);
        YamlPreview($$renderer3);
        $$renderer3.push(`<!----></div></div>`);
      }
      $$renderer3.push(`<!--]--></div></div> <input type="file" class="hidden" accept=".yaml,.yml"/> `);
      EditNodeModal($$renderer3, {
        title: modalTitle,
        nodeKey: modalKey,
        nodeValue: modalValue,
        isObject: modalIsObject,
        isArrayItem: Array.isArray(getNode(data, isEditing ? modalPath.slice(0, -1) : modalPath)),
        onSave: handleSaveNode,
        onClose: () => modalOpen = false,
        get open() {
          return modalOpen;
        },
        set open($$value) {
          modalOpen = $$value;
          $$settled = false;
        }
      });
      $$renderer3.push(`<!----> `);
      BatchImportModal($$renderer3, {
        onImport: performBatchImport,
        onClose: () => batchModalOpen = false,
        get open() {
          return batchModalOpen;
        },
        set open($$value) {
          batchModalOpen = $$value;
          $$settled = false;
        }
      });
      $$renderer3.push(`<!----> `);
      ShortcutsModal($$renderer3, {
        onClose: () => shortcutsModalOpen = false,
        get open() {
          return shortcutsModalOpen;
        },
        set open($$value) {
          shortcutsModalOpen = $$value;
          $$settled = false;
        }
      });
      $$renderer3.push(`<!---->`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
  });
}
function _page($$renderer) {
  head("rbsu28", $$renderer, ($$renderer2) => {
    $$renderer2.title(($$renderer3) => {
      $$renderer3.push(`<title>YAML Editor - Aone Toolkit</title>`);
    });
  });
  $$renderer.push(`<div class="h-[calc(100vh-5rem)]">`);
  YamlEditor($$renderer);
  $$renderer.push(`<!----></div>`);
}
export {
  _page as default
};
