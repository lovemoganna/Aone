

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.D6UDMgYL.js","_app/immutable/chunks/CxxMvMXs.js","_app/immutable/chunks/DODkVri7.js","_app/immutable/chunks/8niHbIwR.js","_app/immutable/chunks/KjoeKUGH.js","_app/immutable/chunks/tNHjmJhK.js","_app/immutable/chunks/CtuzLfAz.js"];
export const stylesheets = [];
export const fonts = [];
