

export const index = 11;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/diff-viewer/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/11.BgDKKtbQ.js","_app/immutable/chunks/CxxMvMXs.js","_app/immutable/chunks/DODkVri7.js","_app/immutable/chunks/Bo1sWiaW.js","_app/immutable/chunks/DE51p1_m.js","_app/immutable/chunks/BMyo6jhZ.js","_app/immutable/chunks/oEXq7tlP.js","_app/immutable/chunks/8niHbIwR.js","_app/immutable/chunks/Do0r2jOo.js","_app/immutable/chunks/KjoeKUGH.js","_app/immutable/chunks/BfwGllh_.js","_app/immutable/chunks/D1hJUxTs.js"];
export const stylesheets = [];
export const fonts = [];
