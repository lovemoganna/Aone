

export const index = 12;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/json-editor/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/12.C_lNEjnK.js","_app/immutable/chunks/CxxMvMXs.js","_app/immutable/chunks/DODkVri7.js","_app/immutable/chunks/Bo1sWiaW.js","_app/immutable/chunks/BMyo6jhZ.js","_app/immutable/chunks/C-TMUErV.js","_app/immutable/chunks/7DIJ8hBu.js","_app/immutable/chunks/DE51p1_m.js","_app/immutable/chunks/CtuzLfAz.js","_app/immutable/chunks/BUXQspxu.js","_app/immutable/chunks/DbHVMXRi.js","_app/immutable/chunks/oEXq7tlP.js","_app/immutable/chunks/DSU0f4am.js","_app/immutable/chunks/CG3DMfXe.js","_app/immutable/chunks/rr9MwC8N.js","_app/immutable/chunks/k-o2Qe0C.js","_app/immutable/chunks/VBzSrYJL.js"];
export const stylesheets = ["_app/immutable/assets/12.BiwEAakK.css"];
export const fonts = [];
