

export const index = 18;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/snippets/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/18.CfXB-7sd.js","_app/immutable/chunks/CxxMvMXs.js","_app/immutable/chunks/DODkVri7.js","_app/immutable/chunks/CtuzLfAz.js","_app/immutable/chunks/Bo1sWiaW.js","_app/immutable/chunks/DE51p1_m.js","_app/immutable/chunks/BMyo6jhZ.js","_app/immutable/chunks/oEXq7tlP.js","_app/immutable/chunks/C-TMUErV.js","_app/immutable/chunks/7DIJ8hBu.js","_app/immutable/chunks/ZerNIWep.js","_app/immutable/chunks/HwLw55SC.js","_app/immutable/chunks/8niHbIwR.js","_app/immutable/chunks/Do0r2jOo.js","_app/immutable/chunks/KjoeKUGH.js","_app/immutable/chunks/D698AB1N.js","_app/immutable/chunks/225iinXO.js","_app/immutable/chunks/Bkz-fm_G.js","_app/immutable/chunks/CEej-f5a.js","_app/immutable/chunks/Dmfjm5wc.js","_app/immutable/chunks/D1hJUxTs.js"];
export const stylesheets = [];
export const fonts = [];
