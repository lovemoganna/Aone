

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.UQrV7f3e.js","_app/immutable/chunks/CxxMvMXs.js","_app/immutable/chunks/DODkVri7.js","_app/immutable/chunks/8niHbIwR.js","_app/immutable/chunks/Bo1sWiaW.js","_app/immutable/chunks/DE51p1_m.js","_app/immutable/chunks/BMyo6jhZ.js","_app/immutable/chunks/ZerNIWep.js","_app/immutable/chunks/7DIJ8hBu.js","_app/immutable/chunks/CtuzLfAz.js","_app/immutable/chunks/Bv2-bEtw.js","_app/immutable/chunks/Do0r2jOo.js","_app/immutable/chunks/KjoeKUGH.js","_app/immutable/chunks/Bkz-fm_G.js","_app/immutable/chunks/DThnwr9a.js","_app/immutable/chunks/AfmkgMrh.js","_app/immutable/chunks/Bfg6_yye.js","_app/immutable/chunks/Dx501IjD.js"];
export const stylesheets = [];
export const fonts = [];
