

export const index = 20;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/svg-studio/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/20.C7bwFWTv.js","_app/immutable/chunks/CxxMvMXs.js","_app/immutable/chunks/DODkVri7.js","_app/immutable/chunks/Bo1sWiaW.js","_app/immutable/chunks/KUsn9fRk.js","_app/immutable/chunks/BMyo6jhZ.js","_app/immutable/chunks/DE51p1_m.js","_app/immutable/chunks/oEXq7tlP.js","_app/immutable/chunks/C-TMUErV.js","_app/immutable/chunks/7DIJ8hBu.js","_app/immutable/chunks/ZerNIWep.js","_app/immutable/chunks/Dmfjm5wc.js","_app/immutable/chunks/8niHbIwR.js","_app/immutable/chunks/Do0r2jOo.js","_app/immutable/chunks/KjoeKUGH.js","_app/immutable/chunks/DpbCvCGd.js","_app/immutable/chunks/CVn24WGb.js","_app/immutable/chunks/D1hJUxTs.js","_app/immutable/chunks/225iinXO.js"];
export const stylesheets = [];
export const fonts = [];
