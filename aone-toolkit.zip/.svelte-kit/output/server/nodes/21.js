

export const index = 21;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/table-editor/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/21.Cwj1P1fD.js","_app/immutable/chunks/CxxMvMXs.js","_app/immutable/chunks/DODkVri7.js","_app/immutable/chunks/Bo1sWiaW.js","_app/immutable/chunks/DE51p1_m.js","_app/immutable/chunks/oEXq7tlP.js","_app/immutable/chunks/BUXQspxu.js","_app/immutable/chunks/C-rDf_mw.js","_app/immutable/chunks/C-TMUErV.js","_app/immutable/chunks/7DIJ8hBu.js"];
export const stylesheets = ["_app/immutable/assets/21.CBU2AQHt.css"];
export const fonts = [];
