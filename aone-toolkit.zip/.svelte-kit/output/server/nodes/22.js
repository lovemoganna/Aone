

export const index = 22;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/yaml-editor/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/22.3PtsqfFi.js","_app/immutable/chunks/CxxMvMXs.js","_app/immutable/chunks/DODkVri7.js","_app/immutable/chunks/8niHbIwR.js","_app/immutable/chunks/BMyo6jhZ.js","_app/immutable/chunks/CtuzLfAz.js","_app/immutable/chunks/Bo1sWiaW.js","_app/immutable/chunks/DE51p1_m.js","_app/immutable/chunks/BUXQspxu.js","_app/immutable/chunks/DbHVMXRi.js","_app/immutable/chunks/oEXq7tlP.js","_app/immutable/chunks/DSU0f4am.js","_app/immutable/chunks/C-TMUErV.js","_app/immutable/chunks/7DIJ8hBu.js","_app/immutable/chunks/rr9MwC8N.js","_app/immutable/chunks/KUsn9fRk.js","_app/immutable/chunks/CqkleIqs.js","_app/immutable/chunks/ZerNIWep.js","_app/immutable/chunks/k-o2Qe0C.js"];
export const stylesheets = ["_app/immutable/assets/22.BVGtQuoP.css"];
export const fonts = [];
