

export const index = 3;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/api-spec/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/3.CPBmw9x8.js","_app/immutable/chunks/CxxMvMXs.js","_app/immutable/chunks/DODkVri7.js","_app/immutable/chunks/Bo1sWiaW.js","_app/immutable/chunks/DE51p1_m.js","_app/immutable/chunks/BMyo6jhZ.js","_app/immutable/chunks/oEXq7tlP.js","_app/immutable/chunks/C-TMUErV.js","_app/immutable/chunks/7DIJ8hBu.js","_app/immutable/chunks/ZerNIWep.js","_app/immutable/chunks/HwLw55SC.js","_app/immutable/chunks/8niHbIwR.js","_app/immutable/chunks/Do0r2jOo.js","_app/immutable/chunks/KjoeKUGH.js","_app/immutable/chunks/B8wbLPXS.js","_app/immutable/chunks/CSuj0dfl.js","_app/immutable/chunks/vRFD2lkt.js","_app/immutable/chunks/M9U_2C0E.js"];
export const stylesheets = [];
export const fonts = [];
