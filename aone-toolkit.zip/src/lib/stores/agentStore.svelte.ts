export interface Agent {
    id: string;
    name: string;
    role: string;
    systemPrompt: string;
    color: string;
    avatar: string; // Icon name
}

export interface Message {
    id: string;
    role: "user" | "assistant" | "system";
    content: string;
    agentId?: string; // If from an agent
    timestamp: number;
}

export interface Session {
    id: string;
    title: string;
    messages: Message[];
    activeAgentIds: string[];
}

class AgentStore {
    agents = $state<Agent[]>([
        {
            id: "1",
            name: "Architect",
            role: "System Designer",
            systemPrompt: "You are a software architect. Focus on high-level design, patterns, and trade-offs.",
            color: "bg-blue-500",
            avatar: "sitemap"
        },
        {
            id: "2",
            name: "Coder",
            role: "Developer",
            systemPrompt: "You are a senior developer. Write clean, efficient code.",
            color: "bg-green-500",
            avatar: "code"
        },
        {
            id: "3",
            name: "Reviewer",
            role: "QA & Audit",
            systemPrompt: "You are a code reviewer. Find bugs, security issues, and style violations.",
            color: "bg-red-500",
            avatar: "shield-check"
        }
    ]);

    currentSession = $state<Session>({
        id: "default",
        title: "New Session",
        messages: [],
        activeAgentIds: ["1", "2"] // Default active
    });

    isThinking = $state(false);

    constructor() {
        // Load from local storage if needed in future
    }

    addMessage(role: Message["role"], content: string, agentId?: string) {
        this.currentSession.messages.push({
            id: crypto.randomUUID(),
            role,
            content,
            agentId,
            timestamp: Date.now()
        });
    }

    toggleAgentActive(agentId: string) {
        if (this.currentSession.activeAgentIds.includes(agentId)) {
            this.currentSession.activeAgentIds = this.currentSession.activeAgentIds.filter(id => id !== agentId);
        } else {
            this.currentSession.activeAgentIds.push(agentId);
        }
    }

    getActiveAgents() {
        return this.agents.filter(a => this.currentSession.activeAgentIds.includes(a.id));
    }

    getAgent(id: string) {
        return this.agents.find(a => a.id === id);
    }
}

export const agentStore = new AgentStore();
