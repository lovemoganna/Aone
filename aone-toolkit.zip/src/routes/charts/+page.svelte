<script lang="ts">
    import { Panel, Button } from "$lib/components/ui";
    import { BarChart, LineChart, PieChart, Trash2, Copy } from "lucide-svelte";

    let dataInput = $state(
        '[\n  {"label": "Jan", "value": 45},\n  {"label": "Feb", "value": 52},\n  {"label": "Mar", "value": 38},\n  {"label": "Apr", "value": 65},\n  {"label": "May", "value": 48}\n]',
    );
    let chartType = $state<"bar" | "line">("bar");
    let chartData = $state<any[]>([]);

    function parseData() {
        try {
            chartData = JSON.parse(dataInput);
        } catch (e) {
            alert("Invalid JSON data");
        }
    }

    $effect(() => {
        parseData();
    });

    let maxVal = $derived(Math.max(...chartData.map((d) => d.value), 1));
</script>

<svelte:head>
    <title>Data Insights - Aone Toolkit</title>
</svelte:head>

<div class="h-[calc(100vh-3rem)] p-4 flex flex-col space-y-4">
    <div class="flex-1 grid grid-cols-1 lg:grid-cols-2 gap-4 min-h-0">
        <Panel class="flex flex-col min-h-0">
            {#snippet header()}
                <div class="flex items-center justify-between w-full">
                    <h2 class="font-semibold">Data Source (JSON)</h2>
                    <Button
                        variant="ghost"
                        size="sm"
                        onclick={() => (dataInput = "")}
                    >
                        <Trash2 size={14} />
                    </Button>
                </div>
            {/snippet}
            <textarea
                bind:value={dataInput}
                class="flex-1 p-6 font-mono text-xs bg-transparent resize-none focus:outline-none dark:text-slate-300"
                placeholder="Paste JSON array of objects here..."
            ></textarea>
        </Panel>

        <Panel class="flex flex-col min-h-0">
            {#snippet header()}
                <div class="flex items-center justify-between w-full">
                    <h2 class="font-semibold">Visual Insight</h2>
                    <div
                        class="flex p-1 bg-slate-100 dark:bg-slate-800 rounded-lg"
                    >
                        <button
                            class="px-3 py-1 text-xs font-medium rounded-md {chartType ===
                            'bar'
                                ? 'bg-white shadow text-primary-600'
                                : 'text-slate-500'}"
                            onclick={() => (chartType = "bar")}>Bar</button
                        >
                        <button
                            class="px-3 py-1 text-xs font-medium rounded-md {chartType ===
                            'line'
                                ? 'bg-white shadow text-primary-600'
                                : 'text-slate-500'}"
                            onclick={() => (chartType = "line")}>Line</button
                        >
                    </div>
                </div>
            {/snippet}

            <div
                class="flex-1 flex items-center justify-center p-12 bg-slate-50/30 dark:bg-black/10"
            >
                {#if chartData.length > 0}
                    <svg viewBox="0 0 400 200" class="w-full h-full">
                        <line
                            x1="40"
                            y1="20"
                            x2="40"
                            y2="180"
                            stroke="currentColor"
                            stroke-width="1"
                            class="text-slate-300 dark:text-slate-700"
                        />
                        <line
                            x1="40"
                            y1="180"
                            x2="380"
                            y2="180"
                            stroke="currentColor"
                            stroke-width="1"
                            class="text-slate-300 dark:text-slate-700"
                        />

                        {#if chartType === "bar"}
                            {#each chartData as d, i}
                                {@const barWidth = 300 / chartData.length}
                                {@const h = (d.value / maxVal) * 150}
                                <rect
                                    x={50 + i * barWidth}
                                    y={180 - h}
                                    width={barWidth * 0.7}
                                    height={h}
                                    fill="url(#grad)"
                                    rx="4"
                                    class="transition-all duration-500"
                                />
                                <text
                                    x={50 + i * barWidth + barWidth * 0.35}
                                    y="195"
                                    text-anchor="middle"
                                    class="text-[8px] fill-slate-400 font-mono"
                                    >{d.label}</text
                                >
                            {/each}
                        {:else}
                            {@const barWidth = 300 / (chartData.length - 1)}
                            <path
                                d={chartData
                                    .map(
                                        (d, i) =>
                                            `${i === 0 ? "M" : "L"} ${50 + i * barWidth} ${180 - (d.value / maxVal) * 150}`,
                                    )
                                    .join(" ")}
                                fill="none"
                                stroke="rgb(79, 70, 229)"
                                stroke-width="3"
                                stroke-linecap="round"
                                stroke-linejoin="round"
                            />
                            {#each chartData as d, i}
                                <circle
                                    cx={50 + i * barWidth}
                                    cy={180 - (d.value / maxVal) * 150}
                                    r="4"
                                    class="fill-indigo-500 stroke-white dark:stroke-slate-900 border"
                                />
                            {/each}
                        {/if}

                        <defs>
                            <linearGradient
                                id="grad"
                                x1="0%"
                                y1="0%"
                                x2="0%"
                                y2="100%"
                            >
                                <stop
                                    offset="0%"
                                    style="stop-color:rgb(79, 70, 229);stop-opacity:1"
                                />
                                <stop
                                    offset="100%"
                                    style="stop-color:rgb(139, 92, 246);stop-opacity:1"
                                />
                            </linearGradient>
                        </defs>
                    </svg>
                {:else}
                    <div class="text-center opacity-20">
                        <BarChart size={64} />
                        <p class="mt-4">Paste array of objects to visualize</p>
                    </div>
                {/if}
            </div>
        </Panel>
    </div>
</div>
