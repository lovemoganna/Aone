<script lang="ts">
    import { Panel, Button } from "$lib/components/ui";
    import { Palette, Copy, Sparkles, Box } from "lucide-svelte";

    // State for Box Shadow
    let x = $state(0);
    let y = $state(10);
    let blur = $state(25);
    let spread = $state(-5);
    let shadowColor = $state("rgba(0,0,0,0.1)");
    let shadowOpacity = $state(0.1);

    // State for Glassmorphism
    let blurAmt = $state(10);
    let transparency = $state(0.5);
    let glassColor = $state("#ffffff");

    let activeEffect = $state<"shadow" | "glass">("shadow");

    let shadowStyle = $derived(
        `box-shadow: ${x}px ${y}px ${blur}px ${spread}px ${shadowColor.replace("0.1", shadowOpacity.toString())};`,
    );
    let glassStyle = $derived(
        `background: ${glassColor}${Math.floor(transparency * 255)
            .toString(16)
            .padStart(
                2,
                "0",
            )};\nbackdrop-filter: blur(${blurAmt}px);\n-webkit-backdrop-filter: blur(${blurAmt}px);\nborder: 1px solid rgba(255, 255, 255, 0.3);`,
    );

    function copyStyle() {
        const text = activeEffect === "shadow" ? shadowStyle : glassStyle;
        navigator.clipboard.writeText(text);
    }
</script>

<svelte:head>
    <title>CSS Design Lab - Aone Toolkit</title>
</svelte:head>

<div class="h-[calc(100vh-3rem)] p-4 flex flex-col space-y-4">
    <div class="flex-1 grid grid-cols-1 lg:grid-cols-2 gap-4 min-h-0">
        <!-- Preview Area -->
        <Panel
            class="flex flex-col min-h-0 overflow-hidden bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] dark:bg-[radial-gradient(#1f2937_1px,transparent_1px)] [background-size:20px_20px]"
        >
            {#snippet header()}
                <div class="flex items-center justify-between w-full">
                    <div class="flex items-center gap-2">
                        <div
                            class="w-7 h-7 rounded-lg bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400 flex items-center justify-center"
                        >
                            <Box size={16} />
                        </div>
                        <h2
                            class="font-semibold text-slate-900 dark:text-white"
                        >
                            Live Preview
                        </h2>
                    </div>
                    <div
                        class="flex p-1 bg-slate-100 dark:bg-slate-800 rounded-lg"
                    >
                        <button
                            class="px-3 py-1 text-xs font-medium rounded-md {activeEffect ===
                            'shadow'
                                ? 'bg-white shadow text-primary-600'
                                : 'text-slate-500'}"
                            onclick={() => (activeEffect = "shadow")}
                            >Shadow</button
                        >
                        <button
                            class="px-3 py-1 text-xs font-medium rounded-md {activeEffect ===
                            'glass'
                                ? 'bg-white shadow text-primary-600'
                                : 'text-slate-500'}"
                            onclick={() => (activeEffect = "glass")}
                            >Glass</button
                        >
                    </div>
                </div>
            {/snippet}

            <div class="flex-1 flex items-center justify-center p-12">
                <div
                    class="w-64 h-64 rounded-3xl bg-white dark:bg-slate-800 transition-all duration-300 flex items-center justify-center text-center p-8"
                    style={activeEffect === "shadow" ? shadowStyle : glassStyle}
                >
                    <div>
                        <Sparkles
                            class="mx-auto mb-4 text-primary-500"
                            size={32}
                        />
                        <p class="font-bold text-slate-800 dark:text-white">
                            Design Token
                        </p>
                        <p class="text-xs text-slate-500 mt-2">
                            Preview your visual constraints in real-time.
                        </p>
                    </div>
                </div>
            </div>
        </Panel>

        <!-- Controls -->
        <Panel class="flex flex-col min-h-0">
            {#snippet header()}
                <div class="flex items-center justify-between w-full">
                    <div class="flex items-center gap-2">
                        <div
                            class="w-7 h-7 rounded-lg bg-pink-100 dark:bg-pink-900/30 text-pink-600 dark:text-pink-400 flex items-center justify-center"
                        >
                            <Palette size={16} />
                        </div>
                        <h2
                            class="font-semibold text-slate-900 dark:text-white"
                        >
                            Style Parameters
                        </h2>
                    </div>
                    <Button size="sm" onclick={copyStyle}>
                        <Copy size={14} class="mr-2" /> Copy CSS
                    </Button>
                </div>
            {/snippet}

            <div class="flex-1 overflow-y-auto p-6 space-y-8">
                {#if activeEffect === "shadow"}
                    <div class="space-y-6">
                        <div class="space-y-4">
                            <div
                                class="flex justify-between text-xs font-bold text-slate-400 uppercase"
                            >
                                <span>Offset X & Y</span>
                                <span>{x}px / {y}px</span>
                            </div>
                            <input
                                type="range"
                                min="-50"
                                max="50"
                                bind:value={x}
                                class="w-full"
                            />
                            <input
                                type="range"
                                min="-50"
                                max="50"
                                bind:value={y}
                                class="w-full"
                            />
                        </div>
                        <div class="space-y-4">
                            <div
                                class="flex justify-between text-xs font-bold text-slate-400 uppercase"
                            >
                                <span>Blur & Spread</span>
                                <span>{blur}px / {spread}px</span>
                            </div>
                            <input
                                type="range"
                                min="0"
                                max="100"
                                bind:value={blur}
                                class="w-full"
                            />
                            <input
                                type="range"
                                min="-50"
                                max="50"
                                bind:value={spread}
                                class="w-full"
                            />
                        </div>
                        <div class="space-y-4">
                            <div
                                class="flex justify-between text-xs font-bold text-slate-400 uppercase"
                            >
                                <span>Shadow Opacity</span>
                                <span>{(shadowOpacity * 100).toFixed(0)}%</span>
                            </div>
                            <input
                                type="range"
                                min="0"
                                max="1"
                                step="0.01"
                                bind:value={shadowOpacity}
                                class="w-full"
                            />
                        </div>
                    </div>
                {:else}
                    <div class="space-y-6">
                        <div class="space-y-4">
                            <div
                                class="flex justify-between text-xs font-bold text-slate-400 uppercase"
                            >
                                <span>Backdrop Blur</span>
                                <span>{blurAmt}px</span>
                            </div>
                            <input
                                type="range"
                                min="0"
                                max="40"
                                bind:value={blurAmt}
                                class="w-full"
                            />
                        </div>
                        <div class="space-y-4">
                            <div
                                class="flex justify-between text-xs font-bold text-slate-400 uppercase"
                            >
                                <span>Transparency</span>
                                <span>{(transparency * 100).toFixed(0)}%</span>
                            </div>
                            <input
                                type="range"
                                min="0"
                                max="1"
                                step="0.01"
                                bind:value={transparency}
                                class="w-full"
                            />
                        </div>
                        <div class="space-y-4">
                            <label
                                for="glass-color-input"
                                class="text-xs font-bold text-slate-400 uppercase block mb-2"
                                >Glass Color</label
                            >
                            <input
                                id="glass-color-input"
                                type="color"
                                bind:value={glassColor}
                                class="w-full h-12 rounded-xl cursor-pointer border-none bg-transparent"
                            />
                        </div>
                    </div>
                {/if}

                <section
                    class="pt-6 border-t border-slate-100 dark:border-slate-800"
                >
                    <div
                        class="text-xs font-bold text-slate-400 uppercase mb-3"
                    >
                        Generated Code
                    </div>
                    <pre
                        class="p-4 bg-slate-900 text-slate-300 rounded-2xl text-[10px] font-mono leading-relaxed"><code
                            >{activeEffect === "shadow"
                                ? shadowStyle
                                : glassStyle}</code
                        ></pre>
                </section>
            </div>
        </Panel>
    </div>
</div>
