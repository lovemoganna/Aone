<script lang="ts">
    import { fade, fly } from "svelte/transition";
    import { Search, Zap, Code } from "lucide-svelte";

    let { isOpen, onClose, onAction } = $props();

    let query = $state("");
    let selectedIndex = $state(0);
    let inputRef = $state<HTMLInputElement | null>(null);

    const items = [
        {
            id: "render",
            label: "Force Render",
            section: "Actions",
            shortcut: "Cmd+Enter",
        },
        {
            id: "new",
            label: "New Diagram",
            section: "Actions",
            shortcut: "Cmd+N",
        },
        {
            id: "export",
            label: "Export Diagram",
            section: "Actions",
            shortcut: "Cmd+E",
        },
        {
            id: "theme",
            label: "Theme Engine",
            section: "Actions",
        },
        { id: "reset", label: "Reset View", section: "Navigation" },
        {
            id: "toggle-sidebar",
            label: "Toggle Sidebar",
            section: "Navigation",
            shortcut: "Cmd+\\",
        },
        {
            id: "toggle-minimap",
            label: "Toggle Minimap",
            section: "Navigation",
            shortcut: "Cmd+M",
        },
        {
            id: "focus-mode",
            label: "Zen Mode",
            section: "Navigation",
            shortcut: "Esc",
        },
        {
            id: "mode-plantuml",
            label: "Switch to PlantUML",
            section: "Language",
        },
        {
            id: "mode-graphviz",
            label: "Switch to Graphviz",
            section: "Language",
        },
        { id: "settings", label: "Settings", section: "System" },
        {
            id: "shortcuts",
            label: "Keyboard Shortcuts",
            section: "System",
            shortcut: "Cmd+/",
        },
    ];

    let filteredItems = $derived.by(() => {
        if (!query) return items;
        const q = query.toLowerCase();
        return items.filter(
            (i) =>
                i.label.toLowerCase().includes(q) ||
                i.section.toLowerCase().includes(q),
        );
    });

    let groupedItems = $derived.by(() => {
        const groups: Record<string, typeof items> = {};
        filteredItems.forEach((item) => {
            if (!groups[item.section]) groups[item.section] = [];
            groups[item.section].push(item);
        });
        return groups;
    });

    // Flattened items for keyboard navigation index
    let flatItems = $derived(Object.values(groupedItems).flat());

    $effect(() => {
        if (isOpen) {
            selectedIndex = 0;
            inputRef?.focus();
        }
    });

    function handleKeydown(e: KeyboardEvent) {
        if (e.key === "ArrowDown") {
            e.preventDefault();
            selectedIndex = (selectedIndex + 1) % flatItems.length;
        } else if (e.key === "ArrowUp") {
            e.preventDefault();
            selectedIndex =
                (selectedIndex - 1 + flatItems.length) % flatItems.length;
        } else if (e.key === "Enter") {
            e.preventDefault();
            const action = flatItems[selectedIndex];
            if (action) {
                onAction(action.id);
                onClose();
            }
        } else if (e.key === "Escape") {
            onClose();
        }
    }
</script>

{#if isOpen}
    <div
        class="fixed inset-0 bg-black/40 z-[1000] flex items-start justify-center pt-[15vh]"
        onclick={onClose}
        transition:fade
    >
        <div
            class="w-full max-w-lg bg-gray-900 text-white rounded-lg shadow-xl overflow-hidden"
            onclick={(e) => e.stopPropagation()}
            onkeydown={handleKeydown}
            transition:fly={{ y: 20 }}
        >
            <div class="p-4 border-b border-white/10 flex items-center gap-2">
                <Search size={18} />
                <input
                    bind:this={inputRef}
                    bind:value={query}
                    placeholder="Search..."
                    class="bg-transparent border-none outline-none flex-1"
                />
            </div>

            <div class="max-h-96 overflow-y-auto">
                {#each Object.entries(groupedItems) as [section, group]}
                    <div
                        class="px-4 py-2 text-[10px] font-bold text-white/30 uppercase tracking-wider bg-white/5"
                    >
                        {section}
                    </div>
                    {#each group as item}
                        {@const isSelected =
                            flatItems[selectedIndex]?.id === item.id}
                        <!-- svelte-ignore a11y_click_events_have_key_events -->
                        <!-- svelte-ignore a11y_no_static_element_interactions -->
                        <div
                            class="px-4 py-2.5 cursor-pointer flex items-center justify-between group {isSelected
                                ? 'bg-indigo-600'
                                : 'hover:bg-white/5'}"
                            onclick={() => {
                                onAction(item.id);
                                onClose();
                            }}
                            onmouseenter={() => {
                                selectedIndex = flatItems.findIndex(
                                    (f) => f.id === item.id,
                                );
                            }}
                        >
                            <div class="flex items-center gap-3">
                                <Zap
                                    size={14}
                                    class={isSelected
                                        ? "text-white"
                                        : "text-indigo-400"}
                                />
                                <span
                                    class="text-sm {isSelected
                                        ? 'text-white'
                                        : 'text-gray-200'}">{item.label}</span
                                >
                            </div>
                            {#if item.shortcut}
                                <span
                                    class="text-[10px] {isSelected
                                        ? 'text-white/60'
                                        : 'text-white/20'} font-mono"
                                    >{item.shortcut}</span
                                >
                            {/if}
                        </div>
                    {/each}
                {/each}
            </div>
        </div>
    </div>
{/if}
