export interface AutoFix {
    label: string;
    apply: (code: string) => string;
}

export function getAutoFixes(message: string, code: string, mode: 'plantuml' | 'graphviz'): AutoFix[] {
    const fixes: AutoFix[] = [];
    const lowerMessage = message.toLowerCase();

    // 1. Missing @startuml / @enduml
    if (mode === 'plantuml') {
        if (lowerMessage.includes('missing @startuml')) {
            fixes.push({
                label: 'Add @startuml',
                apply: (c) => `@startuml\n${c}`
            });
        }
        if (lowerMessage.includes('missing @enduml')) {
            fixes.push({
                label: 'Add @enduml',
                apply: (c) => `${c.trim()}\n@enduml`
            });
        }
    }

    // 2. Missing graph / digraph
    if (mode === 'graphviz') {
        if (lowerMessage.includes('missing graph or digraph')) {
            fixes.push({
                label: 'Add digraph { }',
                apply: (c) => `digraph G {\n${c}\n}`
            });
        }
    }

    // 3. Edge Operator Mismatch (Graphviz)
    if (mode === 'graphviz') {
        if (lowerMessage.includes("use '--' for undirected edges")) {
            fixes.push({
                label: "Convert -> to --",
                apply: (c) => c.replace(/->/g, '--')
            });
        }
        if (lowerMessage.includes("use '->' for directed edges")) {
            fixes.push({
                label: "Convert -- to ->",
                apply: (c) => c.replace(/--/g, '->')
            });
        }
    }

    // 4. Unbalanced Braces
    if (lowerMessage.includes('unclosed braces') || lowerMessage.includes('unbalanced braces')) {
        const open = (code.match(/{/g) || []).length;
        const close = (code.match(/}/g) || []).length;
        if (open > close) {
            fixes.push({
                label: `Add ${open - close} closing braces`,
                apply: (c) => c.trim() + '\n' + '}'.repeat(open - close)
            });
        }
    }

    return fixes;
}
