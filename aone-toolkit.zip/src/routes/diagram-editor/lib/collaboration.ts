import type Peer from 'peerjs';
import { diagramStore } from './store.svelte';

export class CollaborationService {
    private peer: any = null;
    private connection: any = null;
    private isHost: boolean = false;

    // State is managed in the store for reactivity
    async init() {
        if (typeof window === 'undefined') return;

        // Dynamic import for PeerJS to avoid SSR issues
        const { Peer } = await import('peerjs');
        this.peer = new Peer();

        this.peer.on('open', (id: string) => {
            console.log('Peer ID:', id);
            // We'll store the session ID in the store
        });

        this.peer.on('connection', (conn: any) => {
            // Hosting: Someone joined us
            this.handleIncomingConnection(conn);
        });

        this.peer.on('error', (err: any) => {
            console.error('Peer error:', err);
        });
    }

    async host() {
        if (!this.peer) await this.init();
        this.isHost = true;
        return this.peer.id;
    }

    async join(hostId: string) {
        if (!this.peer) await this.init();
        this.isHost = false;

        this.connection = this.peer.connect(hostId);
        this.setupConnectionHooks(this.connection);
    }

    private handleIncomingConnection(conn: any) {
        this.connection = conn;
        this.setupConnectionHooks(this.connection);

        // If we are host, send current code immediately
        if (this.isHost) {
            this.broadcast({ type: 'init', code: diagramStore.code, mode: diagramStore.mode });
        }
    }

    private setupConnectionHooks(conn: any) {
        conn.on('open', () => {
            console.log('Connection established');
        });

        conn.on('data', (data: any) => {
            this.handleData(data);
        });

        conn.on('close', () => {
            console.log('Connection closed');
        });
    }

    broadcast(data: any) {
        if (this.connection && this.connection.open) {
            this.connection.send(data);
        }
    }

    private handleData(data: any) {
        if (data.type === 'update') {
            // Apply remote update
            // To avoid feedback loops, we should have a flag
            diagramStore.applyRemoteUpdate(data.code);
        } else if (data.type === 'init') {
            diagramStore.code = data.code;
            diagramStore.mode = data.mode;
        }
    }

    destroy() {
        if (this.connection) this.connection.close();
        if (this.peer) this.peer.destroy();
    }
}

export const collabService = new CollaborationService();
