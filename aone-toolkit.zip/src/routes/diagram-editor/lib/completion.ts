import {
    snippetCompletion,
    type CompletionContext,
    type CompletionResult,
} from "@codemirror/autocomplete";

const plantUmlSnippets = [
    snippetCompletion("class ${Name} {\n\t${// properties}\n}", {
        label: "class",
        detail: "Define a class",
        type: "class",
    }),
    snippetCompletion("interface ${Name} {\n\t${// methods}\n}", {
        label: "interface",
        detail: "Define an interface",
        type: "interface",
    }),
    snippetCompletion('folder "${Name}" {\n\t${// content}\n}', {
        label: "folder",
        detail: "Group items in a folder",
        type: "namespace",
    }),
    snippetCompletion('package "${Name}" {\n\t${// content}\n}', {
        label: "package",
        detail: "Group items in a package",
        type: "namespace",
    }),
    snippetCompletion('node "${Name}" {\n\t${// content}\n}', {
        label: "node",
        detail: "Deployment node",
        type: "class",
    }),
    snippetCompletion('database "${Name}" {\n\t${// content}\n}', {
        label: "database",
        detail: "Database element",
        type: "class",
    }),
    snippetCompletion("note ${right} of ${Target} : ${text}", {
        label: "note",
        detail: "Attach a note",
        type: "text",
    }),
    snippetCompletion("@startuml\n${}\n@enduml", {
        label: "startuml",
        detail: "Start PlantUML block",
        type: "keyword",
    }),
    snippetCompletion("skinparam ${param} ${value}", {
        label: "skinparam",
        detail: "Style parameter",
        type: "variable",
    }),
];

const graphvizSnippets = [
    snippetCompletion('digraph "${Name}" {\n\t${// nodes and edges}\n}', {
        label: "digraph",
        detail: "Directed graph",
        type: "keyword",
    }),
    snippetCompletion('subgraph "cluster_${Name}" {\n\tlabel = "${Label}";\n\t${// items}\n}', {
        label: "subgraph",
        detail: "Cluster subgraph",
        type: "namespace",
    }),
    snippetCompletion('${node} [shape=${box}, label="${text}"];', {
        label: "node_attr",
        detail: "Node with attributes",
        type: "class",
    }),
    snippetCompletion('rankdir=${LR};', {
        label: "rankdir",
        detail: "Rank direction (LR, TB, etc.)",
        type: "variable",
    }),
];

export function diagramCompletion(mode: 'plantuml' | 'graphviz') {
    return (context: CompletionContext): CompletionResult | null => {
        const word = context.matchBefore(/\w*/);
        if (!word || (word.from === word.to && !context.explicit)) return null;

        return {
            from: word.from,
            options: mode === 'plantuml' ? plantUmlSnippets : graphvizSnippets,
        };
    };
}
