export async function generateDiagramFromAI(prompt: string, currentCode: string, mode: 'plantuml' | 'graphviz') {
    const response = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, currentCode, mode })
    });

    if (!response.ok) {
        throw new Error('Failed to generate diagram from AI');
    }

    const data = await response.json();
    return data.code;
}
