
import { findDefinitions, type DiagramMode } from './parser';

/**
 * Updates the color of a specific element in the code.
 */
export function injectColor(code: string, id: string, color: string, mode: DiagramMode): string {
    const definitions = findDefinitions(code, mode);
    const def = definitions.get(id);

    if (!def) {
        // Fallback: Append new definition if implicit
        if (mode === 'plantuml') {
            return appendNewDefinition(code, mode, `${id} ${color}`);
        } else {
            // Graphviz default: assumption it's a node
            return appendNewDefinition(code, mode, `${id} [fillcolor="${color}", style="filled"];`);
        }
    }

    const lines = code.split('\n');
    let line = lines[def.line];

    if (mode === 'plantuml') {
        // Regex to find existing color: #current
        // We match # followed by word or hex.
        // Be careful not to replace random words, look for #
        const existingColorRegex = /#(\w+|[0-9a-fA-F]{3,6})/;
        const match = line.match(existingColorRegex);

        if (match) {
            // Replace existing color
            line = line.replace(match[0], color ? `${color}` : '');
        } else if (color) {
            // Add new color
            const splitRegex = /(\s*)(\{|$|<<)/;
            const splitMatch = line.match(splitRegex);

            if (splitMatch && splitMatch.index !== undefined) {
                line = line.slice(0, splitMatch.index) + ' ' + color + line.slice(splitMatch.index);
            } else {
                line += ' ' + color;
            }
        }
    } else {
        // Graphviz
        const attrBlockRegex = /\[(.*?)\]/;
        const blockMatch = line.match(attrBlockRegex);

        if (blockMatch) {
            let content = blockMatch[1];
            const colorPropRegex = /(color|fillcolor)\s*=\s*(?:"[^"]*"|[^,\s\]]+)/;

            if (colorPropRegex.test(content)) {
                if (color) {
                    content = content.replace(colorPropRegex, `fillcolor="${color}"`);
                } else {
                    // removing logic simplified
                    content = content.replace(colorPropRegex, `fillcolor="${color}"`);
                }
            } else if (color) {
                if (content.trim().length > 0) {
                    content += `, fillcolor="${color}", style="filled"`;
                } else {
                    content = `fillcolor="${color}", style="filled"`;
                }
            }
            line = line.replace(attrBlockRegex, `[${content}]`);
        } else if (color) {
            const splitRegex = /(\s*)(;|$)/;
            const splitMatch = line.match(splitRegex);

            if (splitMatch && splitMatch.index !== undefined) {
                line = line.slice(0, splitMatch.index) + ` [fillcolor="${color}", style="filled"]` + line.slice(splitMatch.index);
            }
        }
    }

    lines[def.line] = line;
    return lines.join('\n');
}

function appendNewDefinition(code: string, mode: DiagramMode, newLine: string): string {
    const lines = code.split('\n');
    let insertIdx = lines.length;

    if (mode === 'plantuml') {
        // Find @enduml
        // Search from end
        for (let i = lines.length - 1; i >= 0; i--) {
            if (lines[i].trim() === '@enduml') {
                insertIdx = i;
                break;
            }
        }
    } else {
        // Find closing brace '}'
        for (let i = lines.length - 1; i >= 0; i--) {
            if (lines[i].trim() === '}') {
                insertIdx = i;
                break;
            }
        }
    }

    // Indent?
    const indent = '    '; // 4 spaces
    lines.splice(insertIdx, 0, indent + newLine);
    return lines.join('\n');
}

/**
 * Updates the label of a specific element.
 */
/**
 * Updates the label of a specific element.
 */
export function injectLabel(code: string, id: string, label: string, mode: DiagramMode): string {
    const definitions = findDefinitions(code, mode);
    const def = definitions.get(id);
    if (!def) {
        if (mode === 'plantuml') {
            // Assume it is a class/component if not defined? 
            // Or just `ID : "Label"` (valid for objects/actors often)
            // Safest fallback: `component ${id} [${label}]`
            return appendNewDefinition(code, mode, `${id} : "${label}"`);
        } else {
            return appendNewDefinition(code, mode, `${id} [label="${label}"];`);
        }
    }

    const lines = code.split('\n');
    let line = lines[def.line];

    if (mode === 'plantuml') {
        const quotedLabelRegex = /"([^"]+)"/;
        const bracketLabelRegex = /\[([^\]]+)\]/;

        if (quotedLabelRegex.test(line)) {
            line = line.replace(quotedLabelRegex, `"${label}"`);
        } else if (bracketLabelRegex.test(line)) {
            line = line.replace(bracketLabelRegex, `[${label}]`);
        } else {
            const splitRegex = /(\s*)(\{|$|<<|#)/;
            const splitMatch = line.match(splitRegex);

            if (splitMatch && splitMatch.index !== undefined) {
                line = line.slice(0, splitMatch.index) + ` "${label}"` + line.slice(splitMatch.index);
            }
        }
    } else {
        const labelRegex = /label\s*=\s*"([^"]+)"/;
        if (labelRegex.test(line)) {
            line = line.replace(labelRegex, `label="${label}"`);
        } else {
            const attrBlockRegex = /\[(.*?)\]/;
            const blockMatch = line.match(attrBlockRegex);

            if (blockMatch) {
                let content = blockMatch[1];
                if (content.trim().length > 0) {
                    content += `, label="${label}"`;
                } else {
                    content = `label="${label}"`;
                }
                line = line.replace(attrBlockRegex, `[${content}]`);
            } else {
                const splitRegex = /(\s*)(;|$)/;
                const splitMatch = line.match(splitRegex);
                if (splitMatch && splitMatch.index !== undefined) {
                    line = line.slice(0, splitMatch.index) + ` [label="${label}"]` + line.slice(splitMatch.index);
                }
            }
        }
    }

    lines[def.line] = line;
    return lines.join('\n');
}

/**
 * Updates the Shape (type) of a specific element.
 * Only works well for PlantUML where type is explicit (rectangle vs database).
 */
export function injectShape(code: string, id: string, shape: string, mode: DiagramMode): string {
    const definitions = findDefinitions(code, mode);
    const def = definitions.get(id);
    if (!def) {
        if (mode === 'plantuml') {
            return appendNewDefinition(code, mode, `${shape} ${id}`);
        } else {
            return appendNewDefinition(code, mode, `${id} [shape=${shape}];`);
        }
    }

    const lines = code.split('\n');
    let line = lines[def.line];

    if (mode === 'plantuml') {
        // Type is at the start usually: "class Foo ..."
        const typeRegex = new RegExp(`^(\\s*)${def.type}\\b`);

        if (typeRegex.test(line)) {
            line = line.replace(typeRegex, `$1${shape}`);
        }
    } else {
        // Graphviz
        const shapeRegex = /shape\s*=\s*([a-zA-Z0-9]+)/;
        if (shapeRegex.test(line)) {
            line = line.replace(shapeRegex, `shape=${shape}`);
        } else {
            const attrBlockRegex = /\[(.*?)\]/;
            const blockMatch = line.match(attrBlockRegex);

            if (blockMatch) {
                let content = blockMatch[1];
                content += `, shape=${shape}`;
                line = line.replace(attrBlockRegex, `[${content}]`);
            } else {
                const splitRegex = /(\s*)(;|$)/;
                const splitMatch = line.match(splitRegex);
                if (splitMatch && splitMatch.index !== undefined) {
                    line = line.slice(0, splitMatch.index) + ` [shape=${shape}]` + line.slice(splitMatch.index);
                }
            }
        }
    }

    lines[def.line] = line;
    return lines.join('\n');
}

/**
 * Updates the Position of a specific element (Graphviz only).
 * Injects pos="x,y!" attribute.
 */
export function injectPosition(code: string, id: string, x: number, y: number, mode: DiagramMode): string {
    // Only Graphviz supports pos nicely
    if (mode !== 'graphviz') return code;

    const definitions = findDefinitions(code, mode);
    const def = definitions.get(id);
    const posStr = `${x.toFixed(2)},${y.toFixed(2)}!`;

    if (!def) {
        return appendNewDefinition(code, mode, `${id} [pos="${posStr}"];`);
    }

    const lines = code.split('\n');
    let line = lines[def.line];

    // Graphviz pos regex
    const posRegex = /pos\s*=\s*(?:"[^"]*"|[^,\s\]]+)/;

    // Check if attributes exist
    const attrBlockRegex = /\[(.*?)\]/;
    const blockMatch = line.match(attrBlockRegex);

    if (blockMatch) {
        let content = blockMatch[1];
        if (posRegex.test(content)) {
            content = content.replace(posRegex, `pos="${posStr}"`);
        } else {
            if (content.trim().length > 0) {
                content += `, pos="${posStr}"`;
            } else {
                content = `pos="${posStr}"`;
            }
        }
        line = line.replace(attrBlockRegex, `[${content}]`);
    } else {
        const splitRegex = /(\s*)(;|$)/;
        const splitMatch = line.match(splitRegex);
        if (splitMatch && splitMatch.index !== undefined) {
            line = line.slice(0, splitMatch.index) + ` [pos="${posStr}"]` + line.slice(splitMatch.index);
        }
    }

    lines[def.line] = line;
    return lines.join('\n');
}
