import { renderPlantUML } from './plantuml';
import { renderGraphviz } from './graphviz';
import { generateHeuristicDiagram } from '../lib/ai/heuristics';
import { findDefinitions, extractProperties, type Definition } from './parser';
import { injectColor, injectLabel, injectShape, injectPosition } from './modifier';
import { getAutoFixes } from './autofix';
import { collabService } from './collaboration';


export type DiagramMode = 'plantuml' | 'graphviz';

export interface Snippet {
    id: string;
    name: string;
    code: string;
    mode: DiagramMode;
    timestamp: number;
}

export interface HistoryItem {
    code: string;
    timestamp: number;
}

export interface DiagramDocument {
    id: string;
    name: string;
    code: string;
    mode: DiagramMode;
    engine: string;
    overrides: Record<string, any>;
    history: HistoryItem[];
}

export class DiagramStore {
    // Core State (Proxied to Active Document)
    get code() {
        return this.documents.find(d => d.id === this.activeDocumentId)?.code || '';
    }
    set code(v: string) {
        const doc = this.documents.find(d => d.id === this.activeDocumentId);
        if (doc) {
            doc.code = v;
            // Broadcast if collaborating and this is a local change
            if (this.isCollaborating && !this.#isRemoteUpdate) {
                collabService.broadcast({ type: 'update', code: v });
            }
        }
    }

    get mode() {
        return this.documents.find(d => d.id === this.activeDocumentId)?.mode || 'plantuml';
    }
    set mode(v: DiagramMode) {
        const doc = this.documents.find(d => d.id === this.activeDocumentId);
        if (doc) doc.mode = v;
    }

    get engine() {
        return this.documents.find(d => d.id === this.activeDocumentId)?.engine || 'dot';
    }
    set engine(v: string) {
        const doc = this.documents.find(d => d.id === this.activeDocumentId);
        if (doc) doc.engine = v;
    }

    // View State (Per-session, not per-document strictly, but let's keep it global for now or strictly per doc? 
    // Let's keep View State global for simplicity of switching, OR per doc if we want to remember scroll pos.
    // For now, SVG is derived from render, so it's transient.)
    svg = $state('');
    isRendering = $state(false);
    error = $state<string | null>(null);
    lintResults = $state<any[]>([]);
    scale = $state(1);
    pan = $state({ x: 0, y: 0 });
    snippets = $state<Snippet[]>([]);

    autoRender = $state(true);
    previewTheme = $state<'light' | 'dark'>('light');

    // Collaboration State
    sessionID = $state<string | null>(null);
    isCollaborating = $state(false);
    #isRemoteUpdate = false;

    // Performance Tiering
    qualityLevel = $state<'performance' | 'balanced' | 'high'>('high');

    // Advanced Interactions
    selectedElementId = $state<string | null>(null);
    selectedElementType = $state<'node' | 'edge' | null>(null);

    get overrides() {
        return this.documents.find(d => d.id === this.activeDocumentId)?.overrides || {};
    }
    set overrides(v: Record<string, any>) {
        const doc = this.documents.find(d => d.id === this.activeDocumentId);
        if (doc) doc.overrides = v;
    }

    // UI Panels
    isInspectorOpen = $state(false);
    isSidebarPinned = $state(true);
    isMinimapOpen = $state(true);
    focusMode = $state(false);

    multiSelection = $state<string[]>([]);

    // Layer Management
    activeLayers = $state<string[]>([]); // Using array for easier serialization
    availableLayers = $state<string[]>([]);

    toggleLayer(layer: string) {
        if (this.activeLayers.includes(layer)) {
            this.activeLayers = this.activeLayers.filter(l => l !== layer);
        } else {
            this.activeLayers = [...this.activeLayers, layer];
        }
    }

    setAvailableLayers(layers: string[]) {
        this.availableLayers = layers;
        // logic to auto-activate new layers? or keep existing selections?
        // Let's keep existing active layers that are still available
        this.activeLayers = this.activeLayers.filter(l => layers.includes(l));
    }

    // Layout Parameters (Reactive & Per-engine)
    layoutParams = $state({
        nodesep: 0.5,
        ranksep: 0.5,
        rankdir: 'TB', // TB, LR, BT, RL
        overlap: 'false',
        splines: 'true'
    });

    // Multi-Doc State
    documents = $state<DiagramDocument[]>([]);
    activeDocumentId = $state<string>('');

    #renderTimeout: any = null;

    // Settings
    fontSize = $state(14);
    fontFamily = $state("'JetBrains Mono', monospace");
    plantumlServerUrl = $state('https://www.plantuml.com/plantuml');

    constructor(initialCode = '', initialMode: DiagramMode = 'plantuml') {
        // Initialize with one empty doc if none loaded later
        const defaultDoc: DiagramDocument = {
            id: crypto.randomUUID(),
            name: 'Untitled',
            code: initialCode,
            mode: initialMode,
            engine: 'dot',
            overrides: {},
            history: []
        };
        this.documents = [defaultDoc];
        this.activeDocumentId = defaultDoc.id;

        this.loadAll(); // Load all docs & state
        this.loadSnippets();
    }

    loadAll() {
        if (typeof localStorage === 'undefined') return;

        // 1. Try to load multi-doc structure
        const savedDocs = localStorage.getItem('aone_diagram_documents');
        const activeId = localStorage.getItem('aone_diagram_active_id');

        if (savedDocs && activeId) {
            try {
                this.documents = JSON.parse(savedDocs);
                this.activeDocumentId = activeId;

                // Set current values from active doc
                const active = this.documents.find(d => d.id === this.activeDocumentId);
                if (active) {
                    this.code = active.code;
                    this.mode = active.mode;
                    this.engine = active.engine;
                    this.overrides = active.overrides || {};

                    // Restore scale and pan
                    if ((active as any).scale) this.scale = (active as any).scale;
                    if ((active as any).pan) this.pan = { ...this.pan, ...(active as any).pan };

                    // Restore layout params if they exist in active doc
                    if ((active as any).layoutParams) {
                        this.layoutParams = { ...this.layoutParams, ...(active as any).layoutParams };
                    }
                }
            } catch (e) {
                console.error('Failed to load documents', e);
            }
        } else {
            // Migration from Phase 1/2
            this.handleMigration();
        }

        // Global settings
        this.loadSettings();
    }

    loadSettings() {
        if (typeof localStorage === 'undefined') return;
        const settings = localStorage.getItem('aone_diagram_settings');
        if (settings) {
            try {
                const parsed = JSON.parse(settings);
                if (parsed.fontSize) this.fontSize = parsed.fontSize;
                if (parsed.fontFamily) this.fontFamily = parsed.fontFamily;
                if (parsed.plantumlServerUrl) this.plantumlServerUrl = parsed.plantumlServerUrl;
                if (parsed.previewTheme) this.previewTheme = parsed.previewTheme;
                if (parsed.qualityLevel) this.qualityLevel = parsed.qualityLevel;
            } catch (e) {
                console.error('Failed to load settings', e);
            }
        }
    }

    saveSettings() {
        if (typeof localStorage === 'undefined') return;
        const settings = {
            fontSize: this.fontSize,
            fontFamily: this.fontFamily,
            plantumlServerUrl: this.plantumlServerUrl,
            previewTheme: this.previewTheme,
            qualityLevel: this.qualityLevel
        };
        localStorage.setItem('aone_diagram_settings', JSON.stringify(settings));
    }

    handleMigration() {
        const draftStr = localStorage.getItem('aone_diagram_draft');

        // If we have legacy draft, convert to first doc
        if (draftStr) {
            const draft = JSON.parse(draftStr);
            const savedOverrides = localStorage.getItem('diagram_overrides');
            this.documents[0].code = draft.code || '';
            this.documents[0].mode = draft.mode || 'plantuml';
            this.documents[0].engine = draft.engine || 'dot';
            this.documents[0].overrides = savedOverrides ? JSON.parse(savedOverrides) : {};
        }

        this.saveAll();
    }

    saveAll() {
        if (typeof localStorage === 'undefined') return;

        // Persist view state into the current active document object before saving the whole array
        const active = this.documents.find(d => d.id === this.activeDocumentId);
        if (active) {
            (active as any).scale = this.scale;
            (active as any).pan = this.pan;
        }

        localStorage.setItem('aone_diagram_documents', JSON.stringify(this.documents));
        localStorage.setItem('aone_diagram_active_id', this.activeDocumentId);
    }

    // Tab Management
    createDocument(name = 'New Diagram') {
        const newDoc: DiagramDocument = {
            id: crypto.randomUUID(),
            name,
            code: '',
            mode: 'plantuml',
            engine: 'dot',
            overrides: {},
            history: []
        };
        this.documents = [...this.documents, newDoc];
        this.switchDocument(newDoc.id);
    }

    switchDocument(id: string) {
        this.saveAll(); // Save current state of *previous* active doc

        const doc = this.documents.find(d => d.id === id);
        if (doc) {
            this.activeDocumentId = id;
            // No need to set this.code = doc.code manually because this.code is a getter!
            this.svg = ''; // Clear preview for new doc
            this.render();
        }
    }

    closeDocument(id: string) {
        if (this.documents.length <= 1) return; // Keep at least one

        const index = this.documents.findIndex(d => d.id === id);
        this.documents = this.documents.filter(d => d.id !== id);

        if (this.activeDocumentId === id) {
            const nextDoc = this.documents[Math.max(0, index - 1)];
            this.switchDocument(nextDoc.id);
        } else {
            this.saveAll();
        }
    }

    // History Logic
    takeSnapshot() {
        const active = this.documents.find(d => d.id === this.activeDocumentId);
        if (!active || !this.code) return;

        const lastSnapshot = active.history[active.history.length - 1];
        if (lastSnapshot?.code === this.code) return; // No change

        active.history = [...active.history, {
            code: this.code,
            timestamp: Date.now()
        }].slice(-50); // Keep last 50

        this.saveAll();
    }

    // Simplified override logic (syncs with active doc)
    setOverride(id: string, adjustment: Partial<{ scale: number; color: string; x: number; y: number; shape?: string }>) {
        // Legacy support - keep it for things parser can't handle yet (like temporary drags)
        if (!this.overrides[id]) {
            this.overrides[id] = {};
        }
        this.overrides[id] = { ...this.overrides[id], ...adjustment };
        this.saveAll();
    }

    clearOverride(id: string) {
        delete this.overrides[id];
        this.saveAll();
    }

    // --- Bi-directional Binding Logic ---

    // 1. Parse definitions from code (Reactive)
    definitions = $derived(findDefinitions(this.code, this.mode));

    // 2. Get properties of selected element (Reactive)
    selectedElementProperties = $derived.by(() => {
        if (!this.selectedElementId) return {};

        // Try getting from code first
        const def = this.definitions.get(this.selectedElementId);
        if (def) {
            const props = extractProperties(def.raw, this.mode);
            // Merge with local overrides (overrides take precedence for non-persisted UI state like drag position)
            const override = this.overrides[this.selectedElementId] || {};
            return {
                ...props,
                ...override
            };
        }

        // Fallback to just overrides
        return this.overrides[this.selectedElementId] || {};
    });

    // 3. Update element property (Writes to Code)
    updateElementProperty(prop: string, value: any) {
        if (!this.selectedElementId) return;

        if (prop === 'color') {
            this.code = injectColor(this.code, this.selectedElementId, value, this.mode);
            if (this.overrides[this.selectedElementId]?.color) {
                delete this.overrides[this.selectedElementId].color;
            }
        } else if (prop === 'label') {
            this.code = injectLabel(this.code, this.selectedElementId, value, this.mode);
            // Labels are purely code-based now, no override fallback needed typically
        } else if (prop === 'shape') {
            this.code = injectShape(this.code, this.selectedElementId, value, this.mode);
            // Shapes are purely code-based
        } else {
            // Fallback to override for non-bound props (like scale for now)
            this.setOverride(this.selectedElementId, { [prop]: value });
        }
    }

    updateNodePosition(id: string, x: number, y: number) {
        if (this.mode === 'graphviz') {
            // In graphviz mode, commit to code
            this.code = injectPosition(this.code, id, x, y, this.mode);

            // Clear transient override if any
            if (this.overrides[id]) {
                delete this.overrides[id].x;
                delete this.overrides[id].y;
            }
        } else {
            // PlantUML or other: Fallback to override
            this.setOverride(id, { x, y });
        }
    }

    persistDraft = $derived.by(() => {
        this.saveAll();
    });

    loadSnippets() {
        if (typeof localStorage === 'undefined') return;
        const data = localStorage.getItem('aone_diagram_snippets');
        if (data) {
            try {
                this.snippets = JSON.parse(data);
            } catch (e) { console.error('Failed to load snippets', e); }
        }
    }

    saveSnippet(name: string) {
        const newSnippet: Snippet = {
            id: crypto.randomUUID(),
            name,
            code: this.code,
            mode: this.mode,
            timestamp: Date.now()
        };
        this.snippets = [newSnippet, ...this.snippets];
        this.persistSnippets();
    }

    deleteSnippet(id: string) {
        this.snippets = this.snippets.filter(s => s.id !== id);
        this.persistSnippets();
    }

    loadSnippet(id: string) {
        const snippet = this.snippets.find(s => s.id === id);
        if (snippet) {
            this.code = snippet.code;
            this.mode = snippet.mode;
            this.render(); // Auto render
        }
    }

    persistSnippets() {
        if (typeof localStorage === 'undefined') return;
        localStorage.setItem('aone_diagram_snippets', JSON.stringify(this.snippets));
    }

    async render() {
        // ... (existing render code)
    }

    focusOnNode(nodeId: string) {
        if (this.mode !== 'plantuml') {
            console.warn('Focus mode is currently optimized for PlantUML');
            return;
        }

        // Simple approach: Use PlantUML 'hide' command for everything then 'show' the node and its neighbors
        // A more advanced approach would be to parse the code and filter it.
        // For now, let's toggle a 'focus' state in overrides or similar.

        const isFocused = this.overrides[nodeId]?.focused;

        if (isFocused) {
            // Unfocus
            delete this.overrides[nodeId].focused;
            this.code = this.code.replace(/\nshow\s+[^\n]+\n/g, "");
            this.code = this.code.replace(/\nhide\s+[^\n]+\n/g, "");
        } else {
            // Focus
            if (!this.overrides[nodeId]) this.overrides[nodeId] = {};
            this.overrides[nodeId].focused = true;

            // Inject focus commands: hide everything, then show this node
            const focusCommands = `\nhide @unlinked\nhide members\nshow ${nodeId}\n`;

            const endMatch = this.code.match(/@enduml/);
            if (endMatch) {
                this.code = this.code.slice(0, endMatch.index) + focusCommands + this.code.slice(endMatch.index);
            } else {
                this.code += focusCommands;
            }
        }

        this.render();
    }

    resetView() {
        this.scale = 1;
        this.pan = { x: 0, y: 0 };
    }

    async generateFromPrompt(prompt: string) {
        if (!prompt.trim()) return;

        this.isRendering = true;
        this.error = null;

        try {
            // Use Heuristic Engine (Offline AI)
            const result = generateHeuristicDiagram(prompt);

            // Artificial delay for "thinking" effect
            await new Promise(resolve => setTimeout(resolve, 800));

            this.code = result.code;
            this.mode = result.mode;

            await this.render();
        } catch (e: any) {
            this.error = "AI Generation failed: " + e.message;
        } finally {
            this.isRendering = false;
        }
    }

    restoreHistory(item: HistoryItem) {
        this.code = item.code;
        this.render();
    }

    async triggerLinting() {
        if (!this.code.trim()) {
            this.lintResults = [];
            return;
        }

        try {
            const response = await fetch('/api/lint', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ code: this.code, mode: this.mode })
            });
            const data = await response.json();
            if (data.results) {
                this.lintResults = data.results.map((r: any) => ({
                    ...r,
                    actions: getAutoFixes(r.message, this.code, this.mode)
                }));
            } else {
                this.lintResults = [];
            }
        } catch (e) {
            console.error('Linting error:', e);
        }
    }

    autoRenderEffect = $effect.root(() => {
        // ... (existing effect)
    });

    // Collaboration Methods
    async startCollaboration() {
        const id = await collabService.host();
        this.sessionID = id;
        this.isCollaborating = true;
        return id;
    }

    async joinCollaboration(id: string) {
        await collabService.join(id);
        this.sessionID = id;
        this.isCollaborating = true;
    }

    stopCollaboration() {
        collabService.destroy();
        this.sessionID = null;
        this.isCollaborating = false;
    }

    applyRemoteUpdate(code: string) {
        this.#isRemoteUpdate = true;
        this.code = code;
        this.#isRemoteUpdate = false;
        this.render();
    }

    get useSpatialEffects() {
        return this.qualityLevel !== 'performance';
    }

    get useAnimations() {
        return this.qualityLevel === 'high';
    }
}

export const diagramStore = new DiagramStore('');
