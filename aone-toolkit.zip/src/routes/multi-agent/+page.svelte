<script lang="ts">
    import { Panel, Button } from "$lib/components/ui";
    import AgentSidebar from "./components/AgentSidebar.svelte";
    import ChatArea from "./components/ChatArea.svelte";
</script>

<svelte:head>
    <title>Multi-Agent - Aone Toolkit</title>
</svelte:head>

<div class="h-[calc(100vh-3rem)]">
    <Panel class="h-full flex flex-col">
        {#snippet header()}
            <div class="flex items-center justify-between">
                <div class="flex items-center gap-3">
                    <div
                        class="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-violet-500 flex items-center justify-center"
                    >
                        <svg
                            xmlns="http://www.w3.org/2000/svg"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke-width="1.5"
                            stroke="currentColor"
                            class="w-4 h-4 text-white"
                        >
                            <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                d="M9.813 15.904 9 18.75l-.813-2.846a4.5 4.5 0 0 0-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 0 0 3.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 0 0 3.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 0 0-3.09 3.09ZM18.259 8.715 18 9.75l-.259-1.035a3.375 3.375 0 0 0-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 0 0 2.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 0 0 2.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 0 0-2.456 2.456ZM16.894 20.567 16.5 21.75l-.394-1.183a2.25 2.25 0 0 0-1.423-1.423L13.5 18.75l1.183-.394a2.25 2.25 0 0 0 1.423-1.423l.394-1.183.394 1.183a2.25 2.25 0 0 0 1.423 1.423l1.183.394-1.183.394a2.25 2.25 0 0 0-1.423 1.423Z"
                            />
                        </svg>
                    </div>
                    <div class="flex flex-col">
                        <h1
                            class="text-lg font-semibold text-slate-900 dark:text-white"
                        >
                            Multi-Agent Orchestration
                        </h1>
                        <span class="text-xs text-slate-500"
                            >Collaborative Chat Environment</span
                        >
                    </div>
                </div>
                <div class="flex items-center gap-2">
                    <Button variant="secondary" size="sm">Manage Agents</Button>
                    <Button variant="primary" size="sm">New Session</Button>
                </div>
            </div>
        {/snippet}

        <div class="flex-1 flex overflow-hidden">
            <!-- Left Sidebar: Agent Roster -->
            <AgentSidebar />

            <!-- Main Chat Area -->
            <ChatArea />
        </div>
    </Panel>
</div>
