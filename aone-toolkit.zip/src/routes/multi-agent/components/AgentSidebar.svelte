<script lang="ts">
    import { agentStore } from "$lib/stores/agentStore.svelte";
    import { Button } from "$lib/components/ui";
    import {
        Code,
        Map as Sitemap, // Fix: Sitemap not exported, using Map alias
        ShieldCheck,
        Bot,
        Plus,
        Check,
    } from "lucide-svelte";
    import type { ComponentType } from "svelte";

    // Icon mapping
    const iconMap: Record<string, ComponentType> = {
        code: Code,
        sitemap: Sitemap,
        "shield-check": ShieldCheck,
        default: Bot,
    };

    function getIcon(name: string) {
        return iconMap[name] || iconMap.default;
    }

    // Derived state for easy access
    let agents = $derived(agentStore.agents);
    let activeIds = $derived(agentStore.currentSession.activeAgentIds);

    function isActive(id: string) {
        return activeIds.includes(id);
    }
</script>

<div
    class="w-64 border-r border-slate-200 dark:border-slate-800 flex flex-col bg-slate-50 dark:bg-slate-900/50"
>
    <div
        class="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between"
    >
        <h2 class="font-semibold text-slate-800 dark:text-slate-200">Agents</h2>
        <Button variant="ghost" size="sm" class="h-8 w-8 p-0">
            <Plus class="w-4 h-4" />
        </Button>
    </div>

    <div class="flex-1 overflow-y-auto p-3 space-y-2">
        {#each agents as agent}
            {@const Icon = getIcon(agent.avatar)}
            {@const active = isActive(agent.id)}

            <button
                class="w-full text-left p-2 rounded-lg border transition-all duration-200 flex items-center gap-3 group relative
                {active
                    ? 'bg-white dark:bg-slate-800 border-primary-200 dark:border-primary-800 shadow-sm'
                    : 'border-transparent hover:bg-slate-100 dark:hover:bg-slate-800/50 opacity-70 hover:opacity-100'}"
                onclick={() => agentStore.toggleAgentActive(agent.id)}
            >
                <!-- Avatar -->
                <div
                    class="w-10 h-10 rounded-full flex items-center justify-center shrink-0 {agent.color} text-white shadow-sm"
                >
                    <Icon class="w-5 h-5" />
                </div>

                <!-- Info -->
                <div class="flex-1 min-w-0">
                    <div
                        class="font-medium text-sm text-slate-900 dark:text-slate-100 truncate"
                    >
                        {agent.name}
                    </div>
                    <div class="text-xs text-slate-500 truncate">
                        {agent.role}
                    </div>
                </div>

                <!-- Toggle Indicator -->
                <div
                    class="w-5 h-5 rounded-full border flex items-center justify-center transition-colors
                    {active
                        ? 'bg-primary-500 border-primary-500'
                        : 'border-slate-300 dark:border-slate-600'}"
                >
                    {#if active}
                        <Check class="w-3 h-3 text-white" />
                    {/if}
                </div>
            </button>
        {/each}
    </div>

    <!-- Session Info -->
    <div
        class="p-4 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900"
    >
        <div class="text-xs text-slate-500">Current Session</div>
        <div class="font-medium text-sm truncate">
            {agentStore.currentSession.title}
        </div>
    </div>
</div>
