<script lang="ts">
    import { agentStore } from "$lib/stores/agentStore.svelte";
    import { Button, Input } from "$lib/components/ui";
    import MessageBubble from "./MessageBubble.svelte";
    import { Send, Loader2 } from "lucide-svelte";
    import { tick } from "svelte";

    let input = $state("");
    let chatContainer = $state<HTMLElement>();
    let messages = $derived(agentStore.currentSession.messages);
    let isThinking = $derived(agentStore.isThinking);

    // Auto-scroll
    $effect(() => {
        if (messages.length && chatContainer) {
            scrollToBottom();
        }
    });

    async function scrollToBottom() {
        await tick();
        if (chatContainer) {
            chatContainer.scrollTop = chatContainer.scrollHeight;
        }
    }

    async function handleSend() {
        if (!input.trim() || isThinking) return;

        const text = input;
        input = "";

        // 1. User Message
        agentStore.addMessage("user", text);

        // 2. Mock Orchestration
        const activeAgents = agentStore.getActiveAgents();
        if (activeAgents.length === 0) {
            // Fallback if no agents selected
            setTimeout(() => {
                agentStore.addMessage(
                    "system",
                    "No active agents selected. Please select agents from the sidebar.",
                );
            }, 500);
            return;
        }

        agentStore.isThinking = true;

        // Process sequentially for V1
        for (const agent of activeAgents) {
            // Simulate variable thinking time based on role
            const delay = 1000 + Math.random() * 1500;
            await new Promise((r) => setTimeout(r, delay));

            // Mock Response Generation
            const response = generateMockResponse(agent, text);
            agentStore.addMessage("assistant", response, agent.id);
        }

        agentStore.isThinking = false;
    }

    function generateMockResponse(agent: any, input: string) {
        const prefixes = [
            `As a **${agent.role}**, I believe...`,
            `From my perspective...`,
            `Evaluating this request...`,
        ];
        const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];

        return `${prefix}\n\nI have analyzed your input: "${input}".\n\n**My Analysis:**\n- Point 1 specific to ${agent.name}\n- Point 2 regarding ${agent.role}\n\nRecommending next steps based on my system prompt.`;
    }

    function handleKeydown(e: KeyboardEvent) {
        if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            handleSend();
        }
    }
</script>

<div class="flex flex-col h-full bg-slate-50 dark:bg-slate-950">
    <!-- Messages Area -->
    <div
        bind:this={chatContainer}
        class="flex-1 overflow-y-auto p-4 space-y-4 scroll-smooth"
    >
        {#if messages.length === 0}
            <div
                class="h-full flex flex-col items-center justify-center text-slate-400 space-y-4"
            >
                <div
                    class="w-16 h-16 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center"
                >
                    <svg
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke-width="1.5"
                        stroke="currentColor"
                        class="w-8 h-8"
                    >
                        <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            d="M20.25 8.511c.884.284 1.5 1.128 1.5 2.097v4.286c0 1.136-.847 2.1-1.98 2.193-.34.027-.68.052-1.02.072v3.091l-3-3c-1.354 0-2.694-.055-4.02-.163a2.115 2.115 0 0 1-.825-.242m9.345-8.334a2.126 2.126 0 0 0-.476-.095 48.64 48.64 0 0 0-8.048 0c-1.131.094-1.976 1.057-1.976 2.192v4.286c0 .837.46 1.58 1.155 1.951m9.345-8.334V6.637c0-1.621-1.152-3.026-2.76-3.235A48.455 48.455 0 0 0 11.25 3c-2.115 0-4.198.137-6.24.402-1.608.209-2.76 1.614-2.76 3.235v6.226c0 1.621 1.152 3.026 2.76 3.235.577.075 1.157.14 1.74.194V21l4.155-4.155"
                        />
                    </svg>
                </div>
                <div class="text-center">
                    <h3 class="font-medium text-slate-900 dark:text-slate-100">
                        Start a new conversation
                    </h3>
                    <p class="text-sm mt-1">
                        Select agents from the sidebar and say hello.
                    </p>
                </div>
            </div>
        {:else}
            {#each messages as msg (msg.id)}
                <MessageBubble message={msg} />
            {/each}

            {#if isThinking}
                <div class="flex gap-4 p-4 animate-pulse">
                    <div
                        class="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-800"
                    ></div>
                    <div class="space-y-2 flex-1 max-w-sm">
                        <div
                            class="h-4 bg-gray-200 dark:bg-gray-800 rounded w-3/4"
                        ></div>
                        <div
                            class="h-4 bg-gray-200 dark:bg-gray-800 rounded w-1/2"
                        ></div>
                    </div>
                </div>
            {/if}
        {/if}
    </div>

    <!-- Input Area -->
    <div
        class="p-4 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800"
    >
        <div class="relative max-w-4xl mx-auto flex items-end gap-2">
            <div class="flex-1 relative">
                <textarea
                    bind:value={input}
                    onkeydown={handleKeydown}
                    placeholder="Message the active agents..."
                    class="w-full min-h-[50px] max-h-[200px] p-3 pr-10 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-primary-500 resize-none scrollbar-hide text-sm"
                    rows="1"
                ></textarea>
            </div>
            <Button
                onclick={handleSend}
                disabled={!input.trim() || isThinking}
                size="md"
                class="h-[50px] w-[50px] shrink-0 rounded-xl p-0"
            >
                {#if isThinking}
                    <Loader2 class="w-5 h-5 animate-spin" />
                {:else}
                    <Send class="w-5 h-5" />
                {/if}
            </Button>
        </div>
        <div class="text-xs text-center text-slate-400 mt-2">
            <strong>Enter</strong> to send, <strong>Shift + Enter</strong> for new
            line
        </div>
    </div>
</div>
