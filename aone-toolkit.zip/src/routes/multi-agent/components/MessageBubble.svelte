<script lang="ts">
    import { marked } from "marked";
    import type { Message, Agent } from "$lib/stores/agentStore.svelte";
    import { agentStore } from "$lib/stores/agentStore.svelte";
    import {
        Code,
        Map as Sitemap,
        ShieldCheck,
        Bot,
        User,
    } from "lucide-svelte";
    import type { ComponentType } from "svelte";

    let { message }: { message: Message } = $props();

    const iconMap: Record<string, ComponentType> = {
        code: Code,
        sitemap: Sitemap,
        "shield-check": ShieldCheck,
        default: Bot,
    };

    function getAgent(id?: string) {
        if (!id) return null;
        return agentStore.getAgent(id);
    }

    function getIcon(name: string) {
        return iconMap[name] || iconMap.default;
    }

    let agent = $derived(getAgent(message.agentId));
    let isUser = $derived(message.role === "user");
    let htmlContent = $derived(marked.parse(message.content));
</script>

<div
    class="flex gap-4 p-4 {isUser
        ? 'flex-row-reverse'
        : ''} group hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors"
>
    <!-- Avatar -->
    <div class="shrink-0">
        {#if isUser}
            <div
                class="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center text-slate-500"
            >
                <User class="w-5 h-5" />
            </div>
        {:else if agent}
            {@const Icon = getIcon(agent.avatar)}
            <div
                class="w-8 h-8 rounded-full flex items-center justify-center text-white {agent.color}"
            >
                <Icon class="w-5 h-5" />
            </div>
        {:else}
            <div
                class="w-8 h-8 rounded-full bg-gray-500 flex items-center justify-center text-white"
            >
                <Bot class="w-5 h-5" />
            </div>
        {/if}
    </div>

    <!-- Content -->
    <div class="flex-1 max-w-3xl space-y-1">
        <div class="flex items-center gap-2 {isUser ? 'justify-end' : ''}">
            <span
                class="text-sm font-semibold text-slate-900 dark:text-slate-100"
            >
                {isUser ? "You" : agent?.name || "System"}
            </span>
            {#if agent}
                <span
                    class="text-xs text-slate-400 bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded"
                >
                    {agent.role}
                </span>
            {/if}
            <span class="text-xs text-slate-400">
                {new Date(message.timestamp).toLocaleTimeString([], {
                    hour: "2-digit",
                    minute: "2-digit",
                })}
            </span>
        </div>

        <div
            class="prose prose-sm dark:prose-invert max-w-none
            {isUser
                ? 'bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg rounded-tr-none'
                : ''}"
        >
            {@html htmlContent}
        </div>
    </div>
</div>
